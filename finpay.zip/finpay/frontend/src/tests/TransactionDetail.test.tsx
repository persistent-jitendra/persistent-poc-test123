// FinPay — Frontend Tests
// Covers: refund button disabled state, double-submit prevention,
//         error state display, sensitive data masking
// Tool: React Testing Library + Jest

import React from 'react';
import { render, screen, fireEvent, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { TransactionDetail } from '../components/TransactionDetail';
import { RefundModal }        from '../components/RefundModal';
import { RefundHistory }      from '../components/RefundHistory';
import * as api               from '../api/refundApi';

// ─── API mock ─────────────────────────────────────────────────────────────────
jest.mock('../api/refundApi');
const mockGetTransaction = api.getTransaction as jest.MockedFunction<typeof api.getTransaction>;
const mockListRefunds    = api.listRefunds    as jest.MockedFunction<typeof api.listRefunds>;
const mockCreateRefund   = api.createRefund   as jest.MockedFunction<typeof api.createRefund>;

// ─── Fixtures ─────────────────────────────────────────────────────────────────

const refundableTransaction = {
  id: 'TXN-10001',
  user_id: 'USER-501',
  merchant_id: 'MER-900',
  amount: 500000,                    // ₹5,000 in paise
  currency: 'INR',
  status: 'SUCCESS' as const,
  payment_method: 'UPI' as const,
  payment_ref_masked: 'ab****@okaxis',  // already masked by backend
  created_at: '2026-06-10T10:30:00Z',
  is_refundable: true,
  total_refunded: 0,
  remaining_refundable_amount: 500000,
};

const ineligibleTransaction = {
  ...refundableTransaction,
  status: 'FAILED' as const,
  is_refundable: false,
  remaining_refundable_amount: 0,
};

const fullyRefundedTransaction = {
  ...refundableTransaction,
  is_refundable: false,
  total_refunded: 500000,
  remaining_refundable_amount: 0,
};

const sampleRefund = {
  id: 'RFD-001',
  transaction_id: 'TXN-10001',
  amount: 100000,
  currency: 'INR',
  status: 'SUCCESS' as const,
  reason: 'Customer request',
  initiated_by: 'ADMIN-001',
  created_at: '2026-06-10T11:00:00Z',
};

beforeEach(() => jest.clearAllMocks());

// ─────────────────────────────────────────────────────────────────────────────
// 15. FRONTEND — Refund button disabled when not eligible
// ─────────────────────────────────────────────────────────────────────────────

describe('Frontend — refund button disabled when not eligible', () => {

  test('button is ENABLED when is_refundable = true', async () => {
    mockGetTransaction.mockResolvedValue({ data: refundableTransaction });
    mockListRefunds.mockResolvedValue({ data: [] });

    render(<TransactionDetail transactionId="TXN-10001" canCreateRefund={true} />);

    const button = await screen.findByRole('button', { name: /initiate refund/i });
    expect(button).not.toBeDisabled();
    expect(button).not.toHaveAttribute('aria-disabled', 'true');
  });

  test('button is DISABLED when is_refundable = false (FAILED transaction)', async () => {
    mockGetTransaction.mockResolvedValue({ data: ineligibleTransaction });
    mockListRefunds.mockResolvedValue({ data: [] });

    render(<TransactionDetail transactionId="TXN-10001" canCreateRefund={true} />);

    const button = await screen.findByRole('button', { name: /initiate refund/i });
    expect(button).toBeDisabled();
    expect(button).toHaveAttribute('aria-disabled', 'true');
  });

  test('button is DISABLED when transaction is fully refunded', async () => {
    mockGetTransaction.mockResolvedValue({ data: fullyRefundedTransaction });
    mockListRefunds.mockResolvedValue({ data: [] });

    render(<TransactionDetail transactionId="TXN-10001" canCreateRefund={true} />);

    const button = await screen.findByRole('button', { name: /initiate refund/i });
    expect(button).toBeDisabled();
  });

  test('button is NOT RENDERED when canCreateRefund = false (missing permission)', async () => {
    mockGetTransaction.mockResolvedValue({ data: refundableTransaction });
    mockListRefunds.mockResolvedValue({ data: [] });

    render(<TransactionDetail transactionId="TXN-10001" canCreateRefund={false} />);

    await screen.findByText('TXN-10001');
    const button = screen.queryByRole('button', { name: /initiate refund/i });
    expect(button).not.toBeInTheDocument();
  });

  test('ineligible reason message shown when button is disabled', async () => {
    mockGetTransaction.mockResolvedValue({ data: ineligibleTransaction });
    mockListRefunds.mockResolvedValue({ data: [] });

    render(<TransactionDetail transactionId="TXN-10001" canCreateRefund={true} />);

    await screen.findByRole('button', { name: /initiate refund/i });
    expect(screen.getByRole('status')).toHaveTextContent(/FAILED/i);
  });

  test('title attribute explains why button is disabled', async () => {
    mockGetTransaction.mockResolvedValue({ data: ineligibleTransaction });
    mockListRefunds.mockResolvedValue({ data: [] });

    render(<TransactionDetail transactionId="TXN-10001" canCreateRefund={true} />);

    const button = await screen.findByRole('button', { name: /initiate refund/i });
    expect(button).toHaveAttribute('title', expect.stringMatching(/not eligible/i));
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 16. FRONTEND — Double-submit is prevented
// ─────────────────────────────────────────────────────────────────────────────

describe('Frontend — double-submit prevention', () => {

  test('submit button is disabled while request is in-flight', async () => {
    // createRefund never resolves during this test — simulates slow network
    mockCreateRefund.mockReturnValue(new Promise(() => {}));

    render(
      <RefundModal
        transaction={refundableTransaction}
        onSuccess={jest.fn()}
        onClose={jest.fn()}
      />
    );

    const submitBtn = screen.getByRole('button', { name: /confirm refund/i });
    await userEvent.click(submitBtn);

    // Button must be disabled while the request is in-flight
    await waitFor(() => {
      expect(submitBtn).toBeDisabled();
    });
  });

  test('second click while submitting does not trigger a second API call', async () => {
    let resolveFirst!: (v: unknown) => void;
    mockCreateRefund.mockReturnValueOnce(
      new Promise((res) => { resolveFirst = res; })
    );

    render(
      <RefundModal
        transaction={refundableTransaction}
        onSuccess={jest.fn()}
        onClose={jest.fn()}
      />
    );

    const submitBtn = screen.getByRole('button', { name: /confirm refund/i });
    await userEvent.click(submitBtn);
    await userEvent.click(submitBtn); // second click while in-flight
    await userEvent.click(submitBtn); // third click

    // createRefund must only have been called once
    expect(mockCreateRefund).toHaveBeenCalledTimes(1);

    resolveFirst({ data: { ...sampleRefund } });
  });

  test('close button is disabled while request is in-flight', async () => {
    mockCreateRefund.mockReturnValue(new Promise(() => {}));

    render(
      <RefundModal
        transaction={refundableTransaction}
        onSuccess={jest.fn()}
        onClose={jest.fn()}
      />
    );

    const submitBtn = screen.getByRole('button', { name: /confirm refund/i });
    await userEvent.click(submitBtn);

    const closeBtn = screen.getByRole('button', { name: /close/i });
    await waitFor(() => expect(closeBtn).toBeDisabled());
  });

  test('submit button shows loading indicator while in-flight', async () => {
    mockCreateRefund.mockReturnValue(new Promise(() => {}));

    render(
      <RefundModal
        transaction={refundableTransaction}
        onSuccess={jest.fn()}
        onClose={jest.fn()}
      />
    );

    await userEvent.click(screen.getByRole('button', { name: /confirm refund/i }));

    await waitFor(() => {
      expect(screen.getByRole('button', { name: /processing/i })).toBeInTheDocument();
    });
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 17. FRONTEND — Error state is shown clearly
// ─────────────────────────────────────────────────────────────────────────────

describe('Frontend — error state shown clearly', () => {

  test('API error code and message displayed after failed submission', async () => {
    mockCreateRefund.mockResolvedValue({
      error: { code: 'OVER_REFUND', message: 'Refund would exceed original amount.' },
    });

    render(
      <RefundModal
        transaction={refundableTransaction}
        onSuccess={jest.fn()}
        onClose={jest.fn()}
      />
    );

    await userEvent.click(screen.getByRole('button', { name: /confirm refund/i }));

    await waitFor(() => {
      expect(screen.getByRole('alert')).toBeInTheDocument();
      expect(screen.getByRole('alert')).toHaveTextContent('OVER_REFUND');
      expect(screen.getByRole('alert')).toHaveTextContent('Refund would exceed original amount.');
    });
  });

  test('network error produces a user-friendly error message', async () => {
    mockCreateRefund.mockRejectedValue(new Error('Network Error'));

    render(
      <RefundModal
        transaction={refundableTransaction}
        onSuccess={jest.fn()}
        onClose={jest.fn()}
      />
    );

    await userEvent.click(screen.getByRole('button', { name: /confirm refund/i }));

    await waitFor(() => {
      expect(screen.getByRole('alert')).toBeInTheDocument();
      expect(screen.getByRole('alert')).toHaveTextContent(/failed|error|connection/i);
    });
  });

  test('page-level error shown when transaction fetch fails', async () => {
    mockGetTransaction.mockResolvedValue({
      error: { code: 'TRANSACTION_NOT_FOUND', message: "Transaction 'TXN-BAD' was not found." },
    });
    mockListRefunds.mockResolvedValue({ data: [] });

    render(<TransactionDetail transactionId="TXN-BAD" canCreateRefund={true} />);

    await waitFor(() => {
      expect(screen.getByRole('alert')).toHaveTextContent('TRANSACTION_NOT_FOUND');
    });
  });

  test('error alert has role="alert" for screen-reader accessibility', async () => {
    mockCreateRefund.mockResolvedValue({
      error: { code: 'FORBIDDEN', message: 'You do not have permission.' },
    });

    render(
      <RefundModal
        transaction={refundableTransaction}
        onSuccess={jest.fn()}
        onClose={jest.fn()}
      />
    );

    await userEvent.click(screen.getByRole('button', { name: /confirm refund/i }));

    await waitFor(() => {
      const alert = screen.getByRole('alert');
      expect(alert).toBeInTheDocument();
    });
  });

  test('UX validation error shown for zero amount (before API call)', async () => {
    render(
      <RefundModal
        transaction={refundableTransaction}
        onSuccess={jest.fn()}
        onClose={jest.fn()}
      />
    );

    const input = screen.getByLabelText(/refund amount/i);
    await userEvent.clear(input);
    await userEvent.type(input, '0');
    await userEvent.click(screen.getByRole('button', { name: /confirm refund/i }));

    await waitFor(() => {
      expect(screen.getByRole('alert')).toHaveTextContent(/valid amount/i);
    });

    // API must not have been called — UX guard fires first
    expect(mockCreateRefund).not.toHaveBeenCalled();
  });

  test('success state shown after successful refund', async () => {
    mockCreateRefund.mockResolvedValue({ data: sampleRefund });

    render(
      <RefundModal
        transaction={refundableTransaction}
        onSuccess={jest.fn()}
        onClose={jest.fn()}
      />
    );

    await userEvent.click(screen.getByRole('button', { name: /confirm refund/i }));

    await waitFor(() => {
      expect(screen.getByText(/refund initiated/i)).toBeInTheDocument();
      expect(screen.getByText('RFD-001')).toBeInTheDocument();
    });
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 18. FRONTEND — Sensitive data is masked
// ─────────────────────────────────────────────────────────────────────────────

describe('Frontend — sensitive data is masked', () => {

  test('payment_ref_masked is rendered as-is (masked value from backend)', async () => {
    mockGetTransaction.mockResolvedValue({ data: refundableTransaction });
    mockListRefunds.mockResolvedValue({ data: [] });

    render(<TransactionDetail transactionId="TXN-10001" canCreateRefund={true} />);

    await screen.findByText('TXN-10001');

    // Masked value from backend is displayed
    expect(screen.getByText('ab****@okaxis')).toBeInTheDocument();
  });

  test('raw payment_ref is never present in the DOM', async () => {
    // Backend returns ONLY the masked field — raw value never reaches the frontend
    mockGetTransaction.mockResolvedValue({ data: refundableTransaction });
    mockListRefunds.mockResolvedValue({ data: [] });

    const { container } = render(
      <TransactionDetail transactionId="TXN-10001" canCreateRefund={true} />
    );

    await screen.findByText('TXN-10001');

    // Raw UPI VPA that would appear if masking were skipped
    expect(container.innerHTML).not.toContain('abcdef@okaxis');
    expect(container.innerHTML).not.toContain('payment_ref');
  });

  test('refund history table does not display any raw payment data', async () => {
    const refunds = [sampleRefund];

    render(<RefundHistory refunds={refunds} currency="INR" />);

    const table = screen.getByRole('table');
    // Refund history shows id, amount, status, reason, initiated_by, date
    // It must not contain any field that could be a raw payment reference
    expect(within(table).queryByText(/abcdef/i)).not.toBeInTheDocument();
    expect(within(table).queryByText(/\d{16}/)).not.toBeInTheDocument(); // card number pattern
  });

  test('masked value has masked-value CSS class for consistent display', async () => {
    mockGetTransaction.mockResolvedValue({ data: refundableTransaction });
    mockListRefunds.mockResolvedValue({ data: [] });

    const { container } = render(
      <TransactionDetail transactionId="TXN-10001" canCreateRefund={true} />
    );

    await screen.findByText('ab****@okaxis');

    const maskedEl = container.querySelector('.masked-value');
    expect(maskedEl).toBeInTheDocument();
    expect(maskedEl?.textContent).toBe('ab****@okaxis');
  });

  test('loading state shown while transaction is being fetched', async () => {
    // Never resolves — simulates slow network
    mockGetTransaction.mockReturnValue(new Promise(() => {}));
    mockListRefunds.mockReturnValue(new Promise(() => {}));

    render(<TransactionDetail transactionId="TXN-10001" canCreateRefund={true} />);

    expect(screen.getByText(/loading transaction/i)).toBeInTheDocument();
  });
});
