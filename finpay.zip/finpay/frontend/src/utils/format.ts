// FinPay Frontend — Formatting Utilities
// Rule RA-005: amounts are in paise — always divide by 100 for display.

import { TransactionStatus, RefundStatus } from '../types';

export function formatPaise(paise: number, currency = 'INR'): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
  }).format(paise / 100);
}

export function formatDate(iso: string): string {
  return new Intl.DateTimeFormat('en-IN', {
    dateStyle: 'medium',
    timeStyle: 'short',
    timeZone: 'Asia/Kolkata',
  }).format(new Date(iso));
}

export function statusBadgeClass(status: TransactionStatus | RefundStatus): string {
  const map: Record<string, string> = {
    SUCCESS:  'badge--success',
    PENDING:  'badge--warning',
    FAILED:   'badge--error',
    REVERSED: 'badge--neutral',
  };
  return map[status] ?? 'badge--neutral';
}
