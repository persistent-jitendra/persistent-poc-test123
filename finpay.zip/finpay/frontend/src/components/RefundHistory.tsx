// FinPay — Refund History Component
// Rule FE-005: displayed in reverse chronological order (backend returns DESC).
// Renders masked data only — never fetches raw fields.

import React from 'react';
import { RefundResponse } from '../types';
import { Badge } from './ui/Badge';
import { formatPaise, formatDate } from '../utils/format';

interface Props {
  refunds: RefundResponse[];
  currency: string;
}

export const RefundHistory: React.FC<Props> = ({ refunds, currency }) => {
  if (refunds.length === 0) {
    return (
      <section className="card" aria-label="Refund history">
        <h3>Refund History</h3>
        <p className="empty-state">No refunds have been issued for this transaction.</p>
      </section>
    );
  }

  return (
    <section className="card" aria-label="Refund history">
      <h3>Refund History</h3>
      <table className="refund-table">
        <thead>
          <tr>
            <th scope="col">Refund ID</th>
            <th scope="col">Amount</th>
            <th scope="col">Status</th>
            <th scope="col">Reason</th>
            <th scope="col">Initiated By</th>
            <th scope="col">Date</th>
          </tr>
        </thead>
        <tbody>
          {refunds.map((r) => (
            <tr key={r.id}>
              <td>{r.id}</td>
              <td>{formatPaise(r.amount, currency)}</td>
              <td><Badge status={r.status} /></td>
              <td>{r.reason ?? '—'}</td>
              <td>{r.initiated_by}</td>
              <td>{formatDate(r.created_at)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
};
