// FinPay — Spinner primitive
import React from 'react';

interface Props { label?: string; }

export const Spinner: React.FC<Props> = ({ label = 'Loading…' }) => (
  <div className="loading-container" role="status" aria-live="polite">
    <span className="spinner" aria-hidden="true" />
    <span>{label}</span>
  </div>
);
