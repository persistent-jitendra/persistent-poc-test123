// FinPay — Alert primitive
import React from 'react';

type Variant = 'error' | 'success' | 'warning';

interface Props {
  variant: Variant;
  title?: string;
  message: string;
}

export const Alert: React.FC<Props> = ({ variant, title, message }) => (
  <div className={`alert alert--${variant}`} role="alert" aria-live="assertive">
    <div>
      {title && <strong>{title}: </strong>}
      {message}
    </div>
  </div>
);
