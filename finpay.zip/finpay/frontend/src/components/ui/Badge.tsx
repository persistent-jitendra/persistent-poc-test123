// FinPay — Badge primitive
import React from 'react';
import { TransactionStatus, RefundStatus } from '../../types';

type Status = TransactionStatus | RefundStatus;

interface Props { status: Status; }

const variantMap: Record<string, string> = {
  SUCCESS:  'badge--success',
  PENDING:  'badge--warning',
  FAILED:   'badge--error',
  REVERSED: 'badge--neutral',
};

export const Badge: React.FC<Props> = ({ status }) => (
  <span className={`badge ${variantMap[status] ?? 'badge--neutral'}`}>
    {status}
  </span>
);
