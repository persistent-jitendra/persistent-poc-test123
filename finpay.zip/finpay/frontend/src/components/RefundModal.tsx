// FinPay — Refund Modal Component
// Covers: refund amount input, reason input, remaining amount, loading state,
// error state, success state, double-submit prevention.
//
// Rule FE-002: No eligibility logic here — backend is authoritative.
// Rule FE-004: max input capped at remaining_refundable_amount (UX only — backend validates too).
// Rule ID-001: Idempotency-Key generated once per modal open via useRefund hook.

import React, { useState } from 'react';
import { TransactionResponse } from '../types';
import { useRefund } from '../hooks/useRefund';
import { Alert } from './ui/Alert';
import { Spinner } from './ui/Spinner';
import { formatPaise } from '../utils/format';

interface Props {
  transaction: TransactionResponse;
  onSuccess: () => void;
  onClose: () => void;
}

export const RefundModal: React.FC<Props> = ({ transaction, onSuccess, onClose }) => {
  const maxPaise = transaction.remaining_refundable_amount;
  const { state, submit, reset } = useRefund();

  // Local form state (UX only — backend validates all values authoritatively)
  const [amountRupees, setAmountRupees] = useState<string>((maxPaise / 100).toFixed(2));
  const [reason,       setReason]       = useState('');
  const [localError,   setLocalError]   = useState<string | null>(null);

  const isSubmitting = state.status === 'submitting';
  const isSuccess    = state.status === 'success';

  // ── Success state ─────────────────────────────────────────────────────────
  if (isSuccess && state.status === 'success') {
    return (
      <div className="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="refund-modal-title">
        <div className="modal">
          <div className="success-state">
            <div className="success-icon" aria-hidden="true">✅</div>
            <h4 id="refund-modal-title">Refund Initiated</h4>
            <p>
              {formatPaise(state.refund.amount, state.refund.currency)} refund for{' '}
              <strong>{transaction.id}</strong> has been processed.
            </p>
            <p style={{ marginTop: 4 }}>Refund ID: <strong>{state.refund.id}</strong></p>
          </div>
          <div className="modal-actions">
            <button className="btn btn-primary" onClick={onSuccess}>
              Done
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── UX-only pre-submit validation (Rule FE-004) ───────────────────────────
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);

    const amountPaise = Math.round(parseFloat(amountRupees) * 100);

    // Frontend UX guards only — backend will re-validate all of these
    if (isNaN(amountPaise) || amountPaise <= 0) {
      setLocalError('Please enter a valid amount greater than ₹0.');
      return;
    }
    if (amountPaise > maxPaise) {
      setLocalError(`Amount cannot exceed ${formatPaise(maxPaise, transaction.currency)}.`);
      return;
    }

    // useRefund handles: idempotency key, double-submit lock, API call
    await submit(transaction.id, {
      amount:   amountPaise,
      currency: transaction.currency,
      reason:   reason.trim() || undefined,
    });
  };

  const handleClose = () => {
    if (isSubmitting) return;  // block close while request is in-flight
    reset();
    onClose();
  };

  return (
    <div
      className="modal-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="refund-modal-title"
    >
      <div className="modal">

        {/* ── Header ───────────────────────────────────────────────────── */}
        <div className="modal-header">
          <h3 id="refund-modal-title">Initiate Refund</h3>
          <button
            className="modal-close"
            onClick={handleClose}
            disabled={isSubmitting}
            aria-label="Close"
          >
            ×
          </button>
        </div>

        {/* ── Transaction summary ───────────────────────────────────────── */}
        <div className="modal-meta">
          Transaction: <strong>{transaction.id}</strong><br />
          Original amount:{' '}
          <strong>{formatPaise(transaction.amount, transaction.currency)}</strong><br />
          Already refunded:{' '}
          <strong className="amount-refunded">
            {formatPaise(transaction.total_refunded, transaction.currency)}
          </strong><br />
          Remaining refundable:{' '}
          <strong className="amount-remaining">
            {formatPaise(maxPaise, transaction.currency)}
          </strong>
        </div>

        {/* ── Backend error ─────────────────────────────────────────────── */}
        {state.status === 'error' && (
          <Alert
            variant="error"
            title={state.error.code}
            message={state.error.message}
          />
        )}

        {/* ── UX-only local error ────────────────────────────────────────── */}
        {localError && (
          <Alert variant="warning" message={localError} />
        )}

        {/* ── Form ─────────────────────────────────────────────────────────── */}
        <form onSubmit={handleSubmit} noValidate>

          {/* Amount input (Rule FE-004: max capped at remaining — UX only) */}
          <div className="form-group">
            <label htmlFor="refund-amount">
              Refund Amount ({transaction.currency})
            </label>
            <input
              id="refund-amount"
              type="number"
              step="0.01"
              min="0.01"
              max={(maxPaise / 100).toFixed(2)}
              value={amountRupees}
              onChange={(e) => { setAmountRupees(e.target.value); setLocalError(null); }}
              required
              disabled={isSubmitting}
              aria-describedby="amount-hint"
            />
            <p className="hint" id="amount-hint">
              Maximum: {formatPaise(maxPaise, transaction.currency)}
            </p>
          </div>

          {/* Reason input */}
          <div className="form-group">
            <label htmlFor="refund-reason">Reason (optional)</label>
            <textarea
              id="refund-reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              maxLength={500}
              rows={3}
              disabled={isSubmitting}
              placeholder="e.g. Customer requested cancellation"
            />
            <p className="hint">{reason.length}/500</p>
          </div>

          {/* ── Actions ───────────────────────────────────────────────── */}
          <div className="modal-actions">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={handleClose}
              disabled={isSubmitting}
            >
              Cancel
            </button>

            {/* Double-submit prevention: disabled while isSubmitting (useRefund lock) */}
            <button
              type="submit"
              className="btn btn-primary"
              disabled={isSubmitting}
              aria-busy={isSubmitting}
            >
              {isSubmitting
                ? <><span className="spinner" aria-hidden="true" /> Processing…</>
                : 'Confirm Refund'
              }
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
