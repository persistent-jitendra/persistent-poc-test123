// FinPay — Transaction Detail Page Component
// Covers: transaction details, refund button, remaining amount,
// loading state, error state, permission-based disabled, data masking.
//
// Rule FE-001: refund button disabled state driven exclusively by is_refundable from backend.
// Rule FE-002: eligibility is never computed here — backend is authoritative.
// Rule FE-003: payment_ref_masked rendered as-is — raw value never fetched or shown.

import React, { useState } from 'react';
import { useTransaction } from '../hooks/useTransaction';
import { RefundModal } from './RefundModal';
import { RefundHistory } from './RefundHistory';
import { Badge } from './ui/Badge';
import { Spinner } from './ui/Spinner';
import { Alert } from './ui/Alert';
import { formatPaise, formatDate } from '../utils/format';

interface Props {
  transactionId: string;
  /** Injected from auth context — gates whether the refund button is rendered */
  canCreateRefund: boolean;
}

export const TransactionDetail: React.FC<Props> = ({ transactionId, canCreateRefund }) => {
  const { transaction, refunds, loading, error, refetch } = useTransaction(transactionId);
  const [showModal, setShowModal] = useState(false);

  // ── Loading ──────────────────────────────────────────────────────────────
  if (loading) return <Spinner label="Loading transaction…" />;

  // ── Error ────────────────────────────────────────────────────────────────
  if (error) {
    return <Alert variant="error" title={error.code} message={error.message} />;
  }

  if (!transaction) return null;

  const handleRefundSuccess = () => {
    setShowModal(false);
    refetch();
  };

  // Rule FE-001: disabled when backend says is_refundable=false
  const buttonDisabled = !transaction.is_refundable;
  const buttonTitle = !canCreateRefund
    ? 'You do not have permission to initiate refunds.'
    : !transaction.is_refundable
    ? 'This transaction is not eligible for a refund.'
    : 'Initiate a refund for this transaction.';

  return (
    <div className="transaction-detail">

      {/* ── Transaction Summary Card ─────────────────────────────── */}
      <section className="card" aria-label="Transaction details">
        <h2>Transaction {transaction.id}</h2>

        <dl className="detail-grid">
          <dt>Status</dt>
          <dd><Badge status={transaction.status} /></dd>

          <dt>Amount</dt>
          <dd>
            <span className="amount-large">
              {formatPaise(transaction.amount, transaction.currency)}
            </span>
          </dd>

          <dt>Payment Method</dt>
          <dd>{transaction.payment_method}</dd>

          {/* Rule FE-003 — masked value from backend, rendered as-is */}
          {transaction.payment_ref_masked && (
            <>
              <dt>Payment Reference</dt>
              <dd><span className="masked-value">{transaction.payment_ref_masked}</span></dd>
            </>
          )}

          <dt>Merchant ID</dt>
          <dd>{transaction.merchant_id}</dd>

          <dt>User ID</dt>
          <dd>{transaction.user_id}</dd>

          <dt>Date</dt>
          <dd>{formatDate(transaction.created_at)}</dd>

          <dt>Total Refunded</dt>
          <dd>
            <span className="amount-refunded">
              {formatPaise(transaction.total_refunded, transaction.currency)}
            </span>
          </dd>

          <dt>Remaining Refundable</dt>
          <dd>
            <span className="amount-remaining">
              {formatPaise(transaction.remaining_refundable_amount, transaction.currency)}
            </span>
          </dd>
        </dl>

        {/* Rule AZ-002 — button hidden entirely if user lacks refund:create */}
        {canCreateRefund && (
          <>
            <button
              className="btn btn-primary"
              onClick={() => setShowModal(true)}
              disabled={buttonDisabled}
              aria-disabled={buttonDisabled}
              title={buttonTitle}
            >
              Initiate Refund
            </button>

            {/* Rule FE-001 — explain why button is disabled */}
            {!transaction.is_refundable && (
              <p className="ineligible-note" role="status" aria-live="polite">
                {transaction.status !== 'SUCCESS'
                  ? `Refunds are only available for SUCCESS transactions. Status: ${transaction.status}.`
                  : 'This transaction has been fully refunded.'}
              </p>
            )}
          </>
        )}
      </section>

      {/* ── Refund History ────────────────────────────────────────── */}
      <RefundHistory refunds={refunds} currency={transaction.currency} />

      {/* ── Refund Modal ──────────────────────────────────────────── */}
      {showModal && (
        <RefundModal
          transaction={transaction}
          onSuccess={handleRefundSuccess}
          onClose={() => setShowModal(false)}
        />
      )}
    </div>
  );
};
