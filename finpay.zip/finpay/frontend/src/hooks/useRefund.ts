// FinPay — useRefund Hook
// Manages the full refund submission lifecycle:
//   idle → submitting → success | error
// Generates the idempotency key once on mount so retries reuse the same key.
// Double-submit prevention: submitting flag blocks concurrent calls.

import { useState, useRef, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { RefundResponse, ApiError, CreateRefundRequest } from '../types';
import { createRefund } from '../api/refundApi';

type RefundState =
  | { status: 'idle' }
  | { status: 'submitting' }
  | { status: 'success'; refund: RefundResponse }
  | { status: 'error';   error: ApiError };

interface UseRefundResult {
  state:       RefundState;
  submit:      (transactionId: string, payload: CreateRefundRequest) => Promise<void>;
  reset:       () => void;
}

export function useRefund(): UseRefundResult {
  const [state, setState] = useState<RefundState>({ status: 'idle' });

  // Rule ID-001: key is generated once per hook mount (i.e. once per modal open).
  // Retrying the same form submission reuses this key — safe by ID-003.
  const idempotencyKey = useRef<string>(uuidv4());

  const submit = useCallback(async (
    transactionId: string,
    payload: CreateRefundRequest
  ) => {
    // Double-submit prevention — if already in flight, do nothing
    if (state.status === 'submitting') return;

    setState({ status: 'submitting' });
    try {
      const res = await createRefund(transactionId, payload, idempotencyKey.current);

      if (res.error) {
        setState({ status: 'error', error: res.error });
        return;
      }
      setState({ status: 'success', refund: res.data! });
    } catch {
      setState({
        status: 'error',
        error: { code: 'NETWORK_ERROR', message: 'Request failed. Check your connection and try again.' },
      });
    }
  }, [state.status]);

  const reset = useCallback(() => {
    // Rotate the idempotency key so a new submission after reset gets a fresh key
    idempotencyKey.current = uuidv4();
    setState({ status: 'idle' });
  }, []);

  return { state, submit, reset };
}
