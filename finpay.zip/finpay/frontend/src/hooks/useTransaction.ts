// FinPay — useTransaction Hook
// Fetches a single transaction and its refund list together.
// Re-fetch is exposed so callers can refresh after a successful refund.

import { useState, useEffect, useCallback } from 'react';
import { TransactionResponse, RefundResponse, ApiError } from '../types';
import { getTransaction, listRefunds } from '../api/refundApi';

interface UseTransactionResult {
  transaction:  TransactionResponse | null;
  refunds:      RefundResponse[];
  loading:      boolean;
  error:        ApiError | null;
  refetch:      () => void;
}

export function useTransaction(transactionId: string): UseTransactionResult {
  const [transaction, setTransaction] = useState<TransactionResponse | null>(null);
  const [refunds,     setRefunds]     = useState<RefundResponse[]>([]);
  const [loading,     setLoading]     = useState(true);
  const [error,       setError]       = useState<ApiError | null>(null);
  const [tick,        setTick]        = useState(0);   // increment to trigger re-fetch

  const refetch = useCallback(() => setTick((t) => t + 1), []);

  useEffect(() => {
    if (!transactionId) return;
    let cancelled = false;

    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const [txnRes, refundsRes] = await Promise.all([
          getTransaction(transactionId),
          listRefunds(transactionId),
        ]);

        if (cancelled) return;

        if (txnRes.error)     { setError(txnRes.error);     return; }
        if (refundsRes.error) { setError(refundsRes.error); return; }

        setTransaction(txnRes.data     ?? null);
        setRefunds(refundsRes.data     ?? []);
      } catch {
        if (!cancelled) {
          setError({ code: 'NETWORK_ERROR', message: 'Failed to load transaction. Please try again.' });
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    load();
    return () => { cancelled = true; };
  }, [transactionId, tick]);

  return { transaction, refunds, loading, error, refetch };
}
