// FinPay Frontend — Shared Types
// Mirror of backend response shapes only — no business logic lives here.
// Rule FE-002: eligibility is computed by the backend; frontend consumes is_refundable.

export type TransactionStatus = 'PENDING' | 'SUCCESS' | 'FAILED' | 'REVERSED';
export type PaymentMethod     = 'UPI' | 'CARD' | 'NETBANKING' | 'WALLET';
export type RefundStatus      = 'PENDING' | 'SUCCESS' | 'FAILED';

export interface TransactionResponse {
  id: string;
  user_id: string;
  merchant_id: string;
  amount: number;                    // paise
  currency: string;
  status: TransactionStatus;
  payment_method: PaymentMethod;
  payment_ref_masked: string | null; // already masked by backend — render as-is (Rule FE-003)
  created_at: string;
  is_refundable: boolean;            // Rule FE-001: drives button disabled state
  total_refunded: number;
  remaining_refundable_amount: number;
}

export interface RefundResponse {
  id: string;
  transaction_id: string;
  amount: number;
  currency: string;
  status: RefundStatus;
  reason: string | null;
  initiated_by: string;
  created_at: string;
}

export interface CreateRefundRequest {
  amount: number;
  currency: string;
  reason?: string;
}

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}

export interface ApiResponse<T> {
  data?: T;
  error?: ApiError;
}
