// FinPay Frontend — API Service Layer
// All backend calls go through this file — never fetch() inline in components.
// Idempotency-Key is generated here for every refund creation request (Rule ID-001).

import { v4 as uuidv4 } from 'uuid';
import {
  TransactionResponse,
  RefundResponse,
  CreateRefundRequest,
  ApiResponse,
} from '../types';

const BASE_URL = process.env.REACT_APP_API_BASE_URL ?? '/api/v1';

// ─── Auth token helper ────────────────────────────────────────────────────────
// Token is stored in memory only — never localStorage (XSS risk)
let _token: string | null = null;
export function setAuthToken(token: string): void { _token = token; }

function authHeaders(): HeadersInit {
  if (!_token) throw new Error('Not authenticated.');
  return {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${_token}`,
  };
}

// ─── Generic fetch wrapper ────────────────────────────────────────────────────

async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  const res = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers: { ...authHeaders(), ...(options.headers ?? {}) },
  });
  const json: ApiResponse<T> = await res.json();
  return json;
}

// ─── Transaction API ──────────────────────────────────────────────────────────

export async function getTransaction(
  transactionId: string
): Promise<ApiResponse<TransactionResponse>> {
  return request<TransactionResponse>(`/transactions/${transactionId}`);
}

// ─── Refund API ───────────────────────────────────────────────────────────────

// Rule ID-001: Idempotency-Key is a UUID v4 generated fresh per submission.
// The caller is responsible for storing it if they need to retry.
export async function createRefund(
  transactionId: string,
  payload: CreateRefundRequest,
  idempotencyKey: string = uuidv4()
): Promise<ApiResponse<RefundResponse>> {
  return request<RefundResponse>(`/transactions/${transactionId}/refunds`, {
    method: 'POST',
    headers: { 'Idempotency-Key': idempotencyKey },
    body: JSON.stringify(payload),
  });
}

export async function listRefunds(
  transactionId: string
): Promise<ApiResponse<RefundResponse[]>> {
  return request<RefundResponse[]>(`/transactions/${transactionId}/refunds`);
}

export async function getRefund(
  refundId: string
): Promise<ApiResponse<RefundResponse>> {
  return request<RefundResponse>(`/refunds/${refundId}`);
}
