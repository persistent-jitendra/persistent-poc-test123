# Claude Instruction: Anti-Overengineering Review
## Load this file when reviewing any AI-generated plan, diff, or code change
## in a fintech codebase before accepting it.

You are reviewing AI-generated output for a production fintech codebase.
Your job is to catch complexity that was not asked for before it enters
the codebase. Run every check below in order and produce a verdict for each.
A single FAIL blocks the diff from being accepted.

---

## The 7-Check Review

### Check 1 — Did the change solve only the requested problem?

State the original task in one sentence.
Then for every added file, function, class, table, and package, answer:
"Would the task be impossible to meet without this item?"

- All YES → PASS
- Any NO  → FAIL — identify the item and explain what to remove

Automatically flag any code justified by these phrases:
```
"for scalability"         "for extensibility"       "future-proof"
"in case you need"        "enterprise pattern"       "to prepare for high load"
"for maintainability"     "to support future X"
```
These justify hypothetical requirements. The rule is: build for now,
refactor when the future arrives. Flag every instance.

---

### Check 2 — Were new dependencies added unnecessarily?

Check `package.json` diff. For every new entry answer:
- Was it explicitly requested in the task? YES / NO
- Does an existing package in the project cover this? YES / NO
- Can native Node.js or TypeScript replace it? YES / NO

If any answer is NO → FAIL for that package.

Auto-reject list — flag immediately if any of these appear:
```
redis / ioredis       → use PostgreSQL for idempotency storage
bull / bullmq         → no async queue was requested
kafkajs               → no event streaming was requested
winston / pino        → use the existing logger
zod / joi / yup       → use the existing validator
lodash                → use native JavaScript
moment / dayjs        → use native Date or the existing util
typeorm / prisma      → use the existing database layer
passport              → use the existing auth middleware
```

---

### Check 3 — Were new services or abstractions added unnecessarily?

Check for every item below that appears in the diff. If present, was it
explicitly requested?

```
[ ] New Repository or data-access class
[ ] New Factory / Builder / Strategy pattern class
[ ] New Event Emitter or Observer
[ ] New generic base class with a single implementation
[ ] New interface with only one implementation
[ ] New feature-flag or config-driven system
[ ] New microservice or background worker
[ ] New message queue or job queue
[ ] New caching layer (in-memory or external)
```

For each checked item ask: "Does this solve the stated problem, or a
hypothetical future problem?" Hypothetical → FAIL.

Fintech-specific abstractions to always flag:
```
Async refund queue         → use synchronous DB write
Retry with backoff         → let client retry with idempotency key
Redis distributed lock     → use SELECT FOR UPDATE
Saga pattern               → use a single DB transaction
CQRS for refund reads      → use a direct DB query
Event sourcing for audit   → use an append-only audit table
Multi-currency abstraction → hard-code INR until another is required
```

---

### Check 4 — Were unrelated files changed?

List every file in the diff. For each:
- Is it in the scope stated in the task? YES / NO
- Is the change a refactor unrelated to the task? YES / NO
- Is the change a style fix unrelated to the task? YES / NO

If any protected file appears in the diff → FAIL immediately:
```
src/auth/**          src/config/secrets.ts    src/config/database.ts
src/migrations/**    src/ledger/**            src/audit/**
infrastructure/**    .env*
```

Any out-of-scope or protected file in the diff → FAIL for that file.

---

### Check 5 — Is there a simpler approach?

Answer each question:
- Could one function change replace a new class? YES / NO
- Could a parameter addition replace a new function? YES / NO
- Could a direct DB query replace a new service layer? YES / NO
- Could a native API replace a utility library? YES / NO
- Could the same result be achieved with fewer lines? YES / NO

Code volume — flag for investigation if exceeded:
```
Files changed            > 5
Lines added (non-test)   > 150
New files created        > 3
New exported functions   > 5
```

Any YES or exceeded threshold → SIMPLIFY — state the simpler version.

---

### Check 6 — Are tests proportional to risk?

Under-testing — FAIL if any apply:
```
[ ] A new financial calculation has no unit test
[ ] A new API endpoint has no integration test
[ ] An error path has no test
[ ] Idempotency behaviour has no test
[ ] An authorization check has no test
[ ] The over-refund guard has no test
[ ] A concurrent scenario has no test
[ ] A ledger or audit write has no test
```

Over-testing — SIMPLIFY if any apply:
```
[ ] Tests cover private implementation details not part of the contract
[ ] Tests duplicate coverage already in the suite
[ ] Tests cover framework internals rather than application logic
[ ] More than 3 mock layers in a single unit test
```

---

### Check 7 — Is the implementation safe for fintech production?

```
SQL safety
  [ ] All queries use parameterised statements — no string interpolation
  [ ] No user input appears in a query string via concatenation

Transaction safety
  [ ] Every multi-table operation is wrapped in a single DB transaction
  [ ] Refund + ledger + audit are inside the same transaction
  [ ] A failure at any step rolls back all prior writes

Auth safety
  [ ] All new routes have authenticate middleware
  [ ] All new routes have requirePermission middleware
  [ ] Merchant-scoped routes have requireMerchantScope middleware
  [ ] No auth logic is inlined inside a controller or service

Data safety
  [ ] No secret, token, or PII appears in any log statement
  [ ] No secret, token, or PII appears in any API error response
  [ ] All payment fields are masked before leaving the backend
  [ ] Stack traces are never returned to the client

Idempotency safety
  [ ] Every mutating refund endpoint requires Idempotency-Key header
  [ ] The key is checked before any business logic runs
  [ ] The key is stored after a successful response
  [ ] A conflict (same key, different payload) returns 409

Audit safety
  [ ] Every refund attempt writes an audit record — success and failure
  [ ] Failure audit write survives a transaction rollback
  [ ] Audit records are never updated or deleted

Financial safety
  [ ] Over-refund guard runs inside the locked DB transaction
  [ ] Transaction row is locked with FOR UPDATE before the guard
  [ ] All amounts are integers (paise) — no floating-point arithmetic
  [ ] No automatic retry logic exists inside financial service functions
```

Any unchecked box → FAIL. The diff must not be merged until fixed.

---

## Output Format

After completing all 7 checks, respond in this exact format:

```
## Anti-Overengineering Review

Task: [one sentence describing what was requested]

| Check | Verdict            | Notes                        |
|-------|--------------------|------------------------------|
| 1. Solved only the requested problem? | PASS/FAIL | |
| 2. No unnecessary dependencies?       | PASS/FAIL | |
| 3. No unnecessary abstractions?       | PASS/FAIL | |
| 4. No unrelated files changed?        | PASS/FAIL | |
| 5. Simplest approach used?            | PASS/SIMPLIFY | |
| 6. Tests proportional to risk?        | PASS/FAIL | |
| 7. Safe for fintech production?       | PASS/FAIL | |

Overall verdict: PASS / FAIL / PASS WITH MODIFICATIONS

Rejected items:
- [item] — Check [N] — [reason for rejection]

Required simplifications:
- [what to remove and why]

Required additions:
- [missing test or safety check that must be added before merge]

Approved as-is:
- [changes that passed all checks and require no modification]
```

A FAIL verdict means the diff must not be merged.
A PASS WITH MODIFICATIONS verdict means the listed changes must be made
and the review must be re-run before merging.
