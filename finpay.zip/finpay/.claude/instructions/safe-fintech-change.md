# Claude Instruction: Safe Fintech Change
## Load this file at the start of any session that touches payment, refund,
## ledger, wallet, merchant, admin, or financial-data code.

You are working on a production fintech codebase. Every change you make
can affect real money. Apply this protocol completely before writing any code.

---

## Mandatory 7-Step Protocol

### Step 1 — Inspect relevant files before editing
Before suggesting any code:
- Read the target source file in full. Do not skim.
- Read its test file in full.
- Read `docs/business-rules.md` and identify every Rule ID that applies.
- Read `src/types/index.ts` to confirm data shapes.
- Tell me: which files you read, which lines need to change, and which Rule IDs apply.

If you have not read a file, say "I need to read [file] before I can proceed."
Do not generate code for a file you have not read.

### Step 2 — Summarise current behaviour
Before proposing any change, write:
- What the current code does today.
- Which tables and services it reads from and writes to.
- Which business rules it currently enforces.
- What is missing or incorrect that the task requires fixing.

If the existing code already handles the request, say so and ask for clarification.

### Step 3 — Propose the smallest safe change
State in one paragraph exactly what will change — naming specific files,
functions, and line ranges. Nothing else. Answer these before writing code:
- Can this be one function change instead of a new class? If yes, do that.
- Can this be done without a new file? If yes, do not create one.
- Can this be done without a new npm package? If yes, do not add one.
- Can this be done without a schema change? If yes, do not alter the schema.
- Can this be done without new infrastructure? If yes, do not add any.

### Step 4 — Identify risks
Before writing code, label every risk:
```
[RISK] Description — which scenario triggers it.
[ACCEPTED RISK] Description — justification for accepting it.
```
Categories to check: financial correctness, SQL injection, auth bypass,
partial writes, idempotency gaps, PII exposure, API contract breakage.

If any [RISK] is unresolved, stop and ask me. Do not proceed past an unresolved risk.

### Step 5 — List tests
Before writing the implementation, list every test case the change requires:
```
Unit:        [function] — [scenario] — [expected result]
Integration: [METHOD /path] — [scenario] — [HTTP status]
Must keep:   [existing test that must not be deleted or weakened]
```
For any refund change, the minimum test list is:
- Full refund on SUCCESS transaction → 201
- Partial refund → 201
- Non-SUCCESS transaction → 422 REFUND_INELIGIBLE
- Amount = 0 → 400 INVALID_AMOUNT
- Over-refund → 422 OVER_REFUND
- Same idempotency key + same payload → 200 (replay)
- Same idempotency key + different payload → 409 CONFLICT
- Missing permission → 403 FORBIDDEN
- Out-of-scope merchant → 403 MERCHANT_SCOPE_VIOLATION
- Audit record written on success
- Audit record written on failure
- Ledger reversal written on success

### Step 6 — State assumptions
Every assumption must be labelled. An unlabelled assumption is a bug.
```
[ASSUMPTION] What I assumed.
             What breaks if this is wrong.
             How you can verify it.
```
If you cannot write a clear [ASSUMPTION] statement, that means you are guessing.
Stop and ask instead of guessing.

### Step 7 — Avoid guessing gate
Before showing me any code, verify every item:
- Every rule I implemented has a Rule ID in `docs/business-rules.md`. ✓/✗
- I did not infer any rule from a variable name, column name, or pattern. ✓/✗
- Every file I modified was listed in Step 1. ✓/✗
- I did not add any dependency, table, or infrastructure not stated in Step 3. ✓/✗
- Every assumption is labelled [ASSUMPTION]. ✓/✗
- Every risk is labelled [RISK]. ✓/✗
- I have not used "should", "probably", or "might" for any security-critical statement. ✓/✗

If any item is ✗ — fix it before showing me the code.

---

## Non-Negotiable Code Patterns

```typescript
// SQL — always parameterised, never interpolated
await db.query('SELECT * FROM transactions WHERE id = $1 FOR UPDATE', [id]);

// Financial writes — always atomic
await withTransaction(async (client) => {
  await createRefund(client, payload);          // refund
  await ledgerService.createReversal(client);   // ledger
  await auditLogger.record(client, audit);      // audit
  // All three commit together or all three roll back
});

// Auth — always middleware, never inline
router.post('/refunds',
  authenticate,
  requirePermission('refund:create'),
  requireMerchantScope(),
  refundController.createRefund
);

// Data — always masked before response
return res.json(maskSensitiveData(transaction));

// Errors — always AppError, never plain Error
throw new AppError('REFUND_INELIGIBLE', 'Only SUCCESS transactions can be refunded', 422);
```

## Files You Must Never Modify Without My Explicit Instruction
```
src/auth/**             src/config/secrets.ts    src/config/database.ts
src/migrations/**       src/ledger/**            src/audit/**
infrastructure/**       .env*                    *.pem  *.key
```
If a task appears to require one of these files, stop and tell me:
"This task requires modifying a protected file. Please confirm."
