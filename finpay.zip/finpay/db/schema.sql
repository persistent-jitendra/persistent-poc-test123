-- FinPay Admin Refund Module — Database Schema
-- All tables are append-only for financial records (no UPDATE/DELETE on ledger/audit)
-- Run order: 1 → 2 → 3 → 4 → 5 → 6

-- ─────────────────────────────────────────────────────────────────────────────
-- 1. TRANSACTIONS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE transactions (
  id               VARCHAR(50)      PRIMARY KEY,                  -- e.g. TXN-10001
  user_id          VARCHAR(50)      NOT NULL,
  merchant_id      VARCHAR(50)      NOT NULL,
  amount           BIGINT           NOT NULL CHECK (amount > 0),  -- paise
  currency         CHAR(3)          NOT NULL DEFAULT 'INR',
  status           VARCHAR(20)      NOT NULL
                     CHECK (status IN ('PENDING','SUCCESS','FAILED','REVERSED')),
  payment_method   VARCHAR(20)      NOT NULL
                     CHECK (payment_method IN ('UPI','CARD','NETBANKING','WALLET')),
  payment_ref      VARCHAR(255),    -- raw value — masked before API response
  created_at       TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ      NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_transactions_merchant  ON transactions (merchant_id);
CREATE INDEX idx_transactions_user      ON transactions (user_id);
CREATE INDEX idx_transactions_status    ON transactions (status);

-- ─────────────────────────────────────────────────────────────────────────────
-- 2. REFUNDS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE refunds (
  id               VARCHAR(50)      PRIMARY KEY,                  -- e.g. RFD-00001
  transaction_id   VARCHAR(50)      NOT NULL REFERENCES transactions(id),
  amount           BIGINT           NOT NULL CHECK (amount > 0),  -- paise
  currency         CHAR(3)          NOT NULL DEFAULT 'INR',
  status           VARCHAR(20)      NOT NULL DEFAULT 'PENDING'
                     CHECK (status IN ('PENDING','SUCCESS','FAILED')),
  reason           TEXT,
  initiated_by     VARCHAR(50)      NOT NULL,                     -- actor user_id
  idempotency_key  VARCHAR(100)     NOT NULL,
  created_at       TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ      NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_refunds_transaction    ON refunds (transaction_id);
CREATE INDEX idx_refunds_initiated_by  ON refunds (initiated_by);
CREATE INDEX idx_refunds_status        ON refunds (status);

-- Prevent over-refund at DB level:
-- Total refunded per transaction must never exceed the original amount.
-- This constraint is enforced in application logic AND the service layer.
-- (Enforced via application-level check in refundService before INSERT)

-- ─────────────────────────────────────────────────────────────────────────────
-- 3. IDEMPOTENCY KEYS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE idempotency_keys (
  key              VARCHAR(100)     PRIMARY KEY,
  payload_hash     VARCHAR(64)      NOT NULL,   -- SHA-256 of request body
  response_status  INT              NOT NULL,
  response_body    JSONB            NOT NULL,
  created_at       TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  expires_at       TIMESTAMPTZ      NOT NULL
                     DEFAULT NOW() + INTERVAL '24 hours'
);

CREATE INDEX idx_idempotency_expires ON idempotency_keys (expires_at);

-- ─────────────────────────────────────────────────────────────────────────────
-- 4. REFUND AUDIT  (append-only — no UPDATE or DELETE ever)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE refund_audit (
  id               BIGSERIAL        PRIMARY KEY,
  actor_id         VARCHAR(50)      NOT NULL,
  transaction_id   VARCHAR(50)      NOT NULL,
  refund_id        VARCHAR(50),                  -- NULL if refund was never created
  amount           BIGINT           NOT NULL,
  currency         CHAR(3)          NOT NULL DEFAULT 'INR',
  outcome          VARCHAR(20)      NOT NULL
                     CHECK (outcome IN ('SUCCESS','FAILED','CONFLICT','INELIGIBLE','FORBIDDEN')),
  failure_reason   TEXT,
  ip_address       INET,
  idempotency_key  VARCHAR(100),
  created_at       TIMESTAMPTZ      NOT NULL DEFAULT NOW()
);

-- Protect audit immutability via rule (PostgreSQL)
CREATE RULE no_update_refund_audit AS ON UPDATE TO refund_audit DO INSTEAD NOTHING;
CREATE RULE no_delete_refund_audit AS ON DELETE TO refund_audit DO INSTEAD NOTHING;

CREATE INDEX idx_audit_transaction ON refund_audit (transaction_id);
CREATE INDEX idx_audit_actor       ON refund_audit (actor_id);
CREATE INDEX idx_audit_created_at  ON refund_audit (created_at DESC);

-- ─────────────────────────────────────────────────────────────────────────────
-- 5. LEDGER ENTRIES  (append-only — no UPDATE or DELETE ever)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE ledger_entries (
  id               BIGSERIAL        PRIMARY KEY,
  entry_type       VARCHAR(30)      NOT NULL
                     CHECK (entry_type IN ('PAYMENT','REFUND_REVERSAL')),
  transaction_id   VARCHAR(50)      NOT NULL REFERENCES transactions(id),
  refund_id        VARCHAR(50)      REFERENCES refunds(id),
  amount           BIGINT           NOT NULL,   -- negative for reversals
  currency         CHAR(3)          NOT NULL DEFAULT 'INR',
  merchant_id      VARCHAR(50)      NOT NULL,
  created_at       TIMESTAMPTZ      NOT NULL DEFAULT NOW()
);

CREATE RULE no_update_ledger AS ON UPDATE TO ledger_entries DO INSTEAD NOTHING;
CREATE RULE no_delete_ledger AS ON DELETE TO ledger_entries DO INSTEAD NOTHING;

CREATE INDEX idx_ledger_transaction ON ledger_entries (transaction_id);
CREATE INDEX idx_ledger_merchant    ON ledger_entries (merchant_id);

-- ─────────────────────────────────────────────────────────────────────────────
-- 6. ADMIN USERS & PERMISSIONS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE admin_users (
  id                    VARCHAR(50)   PRIMARY KEY,
  email                 VARCHAR(255)  NOT NULL UNIQUE,
  role                  VARCHAR(20)   NOT NULL CHECK (role IN ('admin','support')),
  permissions           TEXT[]        NOT NULL DEFAULT '{}',
  -- e.g. ARRAY['refund:read','refund:create']
  allowed_merchant_ids  TEXT[]        NOT NULL DEFAULT '{}',
  -- empty array means NO merchant access
  is_active             BOOLEAN       NOT NULL DEFAULT TRUE,
  created_at            TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_admin_users_role ON admin_users (role);
