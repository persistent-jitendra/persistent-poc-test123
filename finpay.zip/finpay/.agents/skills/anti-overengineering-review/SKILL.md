# SKILL: Anti-Overengineering Review
**Version:** 2.0
**Category:** fintech / code-review / ai-safety
**Applies to:** Any AI-generated plan, diff, or code change in a fintech codebase

---

## Purpose
AI models frequently over-engineer solutions by adding abstractions, services,
queues, caches, and dependencies that were never requested. In a fintech
codebase this creates unnecessary complexity, hidden failure modes, increased
attack surface, and compliance risk.

This skill is a mandatory 7-check review to catch and reject over-engineered
AI output before it enters the codebase.

Run this review **after** AI generates code and **before** you accept any diff.

---

## When to Use This Skill
- After any AI generates a new service, module, or feature
- When a PR contains more files changed than the task required
- When new `package.json` entries appear that were not requested
- When an AI suggests adding infrastructure (queues, caches, workers)
- When generated code introduces new abstractions not present elsewhere
- Before any AI-generated diff is merged into a fintech codebase
- Whenever an AI justifies its output with words like "scalable", "extensible",
  "future-proof", or "enterprise pattern"

---

## The 7-Check Review

Run every check in order. Each check produces a PASS, FAIL, or SIMPLIFY verdict.
A single FAIL blocks the diff from being accepted.

---

### Check 1 — Did the change solve only the requested problem?

State the original task requirement in one sentence.
Then answer the following question:

**"Does every file, function, class, table, and package in this diff exist
because the stated requirement cannot be met without it?"**

```
Required by task:    YES / NO   for each added file
Required by task:    YES / NO   for each new function
Required by task:    YES / NO   for each new class or service
Required by task:    YES / NO   for each new database table or column
```

VERDICT:
- All YES → PASS
- Any NO  → FAIL — remove the item and re-review

**Phrases that automatically mean NO:**
> "for scalability" / "for extensibility" / "future-proof" /
> "in case you need" / "following enterprise patterns" / "to prepare for"

These justify future requirements. Build for the current requirement only.

---

### Check 2 — Were new dependencies added unnecessarily?

Run `git diff package.json`. For every new entry:

```
Package: [name]
  Was it explicitly requested in the task?          YES / NO
  Does a package already in the project cover this? YES / NO
  Can native Node.js / browser APIs replace it?     YES / NO
  Is it a dev dependency used only in tests?        YES / NO

VERDICT: ACCEPT / REJECT
```

**Auto-reject list — these are never acceptable without explicit instruction:**

| Package | Why Rejected |
|---|---|
| `redis` / `ioredis` | Idempotency belongs in PostgreSQL, not a cache |
| `bull` / `bullmq` / `kafkajs` | No async job queue was requested |
| `winston` / `pino` | Use the existing logger |
| `zod` / `joi` / `yup` | Use the existing validator |
| `lodash` | Use native JS/TS |
| `moment` / `dayjs` | Use native `Date` or the existing utility |
| `typeorm` / `prisma` / `knex` | Use the existing DB layer |
| `passport` / `express-jwt` | Use the existing auth middleware |

VERDICT:
- No new packages → PASS
- Accepted package with clear justification → PASS WITH NOTE
- Any auto-reject package → FAIL

---

### Check 3 — Were new services or abstractions added unnecessarily?

Check whether the diff introduces any of the following that were not present
in the codebase before:

```
New abstractions:
  [ ] Repository class or data-access layer
  [ ] Factory or Builder pattern
  [ ] Event Emitter, Observer, or Pub/Sub
  [ ] Strategy or Policy pattern class
  [ ] Generic base class with a single concrete implementation
  [ ] Interface with only one implementation
  [ ] Feature-flag or configuration-driven behaviour system
  [ ] New microservice or separately deployable unit
  [ ] Message queue, job queue, or background worker
  [ ] Caching layer (in-memory or external)
```

For each box checked, answer:
> "Does this abstraction solve the problem stated in the task, or does it
> solve a hypothetical problem that may arise in the future?"

- Solves the stated problem → PASS (with justification)
- Solves a hypothetical problem → FAIL — remove the abstraction

**Fintech-specific patterns to always reject at first implementation:**

| Pattern | Correct Alternative |
|---|---|
| Async refund queue | Synchronous DB write — simpler and fully auditable |
| Retry with backoff inside service | Let client retry with idempotency key |
| Distributed lock (Redis) | PostgreSQL `SELECT FOR UPDATE` |
| Saga pattern for refund flow | Single atomic DB transaction |
| CQRS for refund reads | Direct DB query — no read scale problem yet |
| Event sourcing for audit | Append-only audit table |
| Multi-currency abstraction | Hard-code INR until another currency is required |

VERDICT:
- No new unrequested abstractions → PASS
- Any unrequested abstraction present → FAIL

---

### Check 4 — Were unrelated files changed?

Run `git diff --stat`. For every file in the diff:

```
File: [path]
  Is this file in the task scope stated in the prompt?   YES / NO
  Was this file mentioned as needing a change?           YES / NO
  Is the change a refactor unrelated to the task?        YES / NO
  Is the change a style fix unrelated to the task?       YES / NO
```

**Protected files — must appear in no diff unless explicitly requested:**
```
src/auth/**
src/config/secrets.ts
src/config/database.ts
src/migrations/**
src/ledger/**
src/audit/**
infrastructure/**
.env*
```

If any protected file appears in the diff:
→ **FAIL immediately.** Do not review further. Reject the entire diff.

If an unprotected but out-of-scope file appears:
→ **FAIL for that file.** Remove those changes and re-review.

VERDICT:
- All changed files are in task scope → PASS
- Any out-of-scope or protected file changed → FAIL

---

### Check 5 — Is there a simpler approach?

For the core logic of the change, ask:

```
5a. Could this be solved by modifying one function instead of
    creating a new class?                               YES / NO

5b. Could this be solved by adding a parameter to an existing
    function instead of creating a new one?             YES / NO

5c. Could this be solved with a direct DB query instead of
    a new service layer?                                YES / NO

5d. Could this be solved with a native language feature
    instead of a utility library?                       YES / NO

5e. Could this be solved with fewer lines of code while
    being equally readable and safe?                    YES / NO
```

Code volume thresholds — investigate if exceeded:

| Metric | Acceptable | Investigate |
|---|---|---|
| Files changed | ≤ 5 | > 5 |
| Lines added (non-test) | ≤ 150 | > 150 |
| New files created | ≤ 3 | > 3 |
| New exported functions | ≤ 5 | > 5 |

For each YES answer above, or each exceeded threshold:
→ Identify the simpler approach and require AI to use it.

VERDICT:
- No simpler approach exists → PASS
- A simpler approach exists → SIMPLIFY — require the smaller version

---

### Check 6 — Are tests proportional to risk?

Tests must be neither under-written nor over-written.

**Under-testing (FAIL if any apply):**
```
  [ ] A new financial calculation has no unit test
  [ ] A new API endpoint has no integration test
  [ ] An error path has no test
  [ ] The idempotency behaviour has no test
  [ ] The authorization check has no test
  [ ] The over-refund guard has no test
  [ ] A concurrent scenario has no test
```

**Over-testing (SIMPLIFY if any apply):**
```
  [ ] Tests are written for private implementation details
      that should not be exposed
  [ ] Tests duplicate coverage that already exists in the suite
  [ ] Tests cover framework behaviour (e.g. Express routing)
      rather than application logic
  [ ] More than 3 mocking layers are used for a single unit test
```

**Test-to-risk mapping for this codebase:**

| Change Type | Minimum Test Coverage Required |
|---|---|
| New refund rule | Unit test for pass + every fail case |
| New API endpoint | Integration test for happy path + all error codes |
| Auth middleware change | Test for each permission and scope scenario |
| DB schema change | Migration test + query test |
| Masking logic change | Unit test for each field type + null case |
| Idempotency change | Same-key-same-payload + same-key-diff-payload |

VERDICT:
- Tests exist and match risk → PASS
- Missing tests for financial / auth / idempotency paths → FAIL
- Tests exist but cover wrong layer → SIMPLIFY

---

### Check 7 — Is the implementation safe for fintech production code?

This is the final gate. Run the full safety checklist:

```
SQL SAFETY
  [ ] All queries use parameterised statements ($1, $2, ...)
  [ ] No user input is interpolated into a query string
  [ ] No raw SQL is constructed via string concatenation

TRANSACTION SAFETY
  [ ] Every operation that touches more than one table is wrapped
      in a single DB transaction
  [ ] A failure at any step rolls back all prior writes in that transaction
  [ ] Audit and ledger writes are inside the same transaction as the refund

AUTHORIZATION SAFETY
  [ ] All new routes have authenticate middleware
  [ ] All new routes have requirePermission middleware
  [ ] All merchant-scoped routes have requireMerchantScope middleware
  [ ] No auth logic is inlined inside a controller

DATA SAFETY
  [ ] No secret, token, or PII appears in any log statement
  [ ] No secret, token, or PII appears in any error message returned to the client
  [ ] All payment fields are masked before leaving the backend
  [ ] Stack traces are never returned to the client

IDEMPOTENCY SAFETY
  [ ] Every mutating refund endpoint requires an Idempotency-Key header
  [ ] The key is checked before any business logic runs
  [ ] The key is stored after a successful response
  [ ] A conflict (same key, different payload) returns 409

AUDIT SAFETY
  [ ] Every refund attempt writes an audit record — success and failure
  [ ] The failure audit write survives a transaction rollback
  [ ] Audit records are never updated or deleted

FINANCIAL SAFETY
  [ ] The over-refund guard runs inside the locked DB transaction
  [ ] The transaction row is locked with FOR UPDATE before the check
  [ ] Amounts are integers (paise) — no floating-point arithmetic
  [ ] No retry logic exists inside financial service functions
```

VERDICT:
- All boxes checked → PASS
- Any unchecked box → FAIL — the diff must not be merged

---

## Review Output Format

After completing all 7 checks, produce this summary:

```
## Anti-Overengineering Review — Result

Task reviewed: [one-sentence description of what was requested]

| Check | Verdict | Notes |
|---|---|---|
| 1. Solved only requested problem? | PASS / FAIL | |
| 2. No unnecessary dependencies?   | PASS / FAIL | |
| 3. No unnecessary abstractions?   | PASS / FAIL | |
| 4. No unrelated files changed?    | PASS / FAIL | |
| 5. Simplest approach used?        | PASS / SIMPLIFY | |
| 6. Tests proportional to risk?    | PASS / FAIL | |
| 7. Safe for fintech production?   | PASS / FAIL | |

### Overall Verdict: PASS / FAIL / PASS WITH MODIFICATIONS

### Rejected Items
- [item] — Check [N] — [reason]

### Required Simplifications
- [what to remove or simplify and why]

### Required Additions
- [any missing test or safety check that must be added]

### Approved as-is
- [changes that passed all checks and require no modification]
```

A diff with any FAIL verdict must not be merged.
A PASS WITH MODIFICATIONS diff may only be merged after the modifications
are made and the review is re-run.
