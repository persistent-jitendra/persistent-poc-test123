# SKILL: Safe Fintech Change
**Version:** 2.0
**Category:** fintech / code-safety
**Applies to:** Any code change touching payment, refund, wallet, ledger,
merchant, admin, or financial-data flows in a fintech codebase

---

## Purpose
This skill defines a mandatory 7-step protocol for making any change inside a
fintech codebase safely. It prevents AI from guessing business logic, modifying
code it has not read, introducing security vulnerabilities, or creating
compliance gaps.

Apply this skill for every change that touches:
- Refund or payment flows
- Wallet or balance operations
- Ledger or financial record writes
- Merchant data or merchant-scoped access
- Admin or support user actions
- Authorization or permission logic
- Any data that is masked, encrypted, or PII-classified

---

## When to Use This Skill

Activate this skill whenever a task involves any of the following areas:

| Area | Examples |
|---|---|
| Payment flows | charge, capture, settle, reverse |
| Refund flows | full refund, partial refund, over-refund guard |
| Wallet / balance | credit, debit, balance check |
| Ledger | entry creation, reversal, reconciliation |
| Merchant scope | merchant-scoped queries, cross-merchant access |
| Admin / support actions | any operation initiated by internal users |
| Authorization | permission checks, role validation, scope enforcement |
| Financial data | any field representing money, account, or payment identity |

---

## The 7-Step Protocol

Execute every step in order. Do not skip steps. Do not start writing code
before Step 3 is complete.

---

### Step 1 — Inspect Relevant Files Before Editing

**Rule: Never edit a file you have not read in full.**

```
For every file the task will touch:

  1a. Read the target source file completely.
      → Understand the existing function signatures, data shapes, and patterns.

  1b. Read the corresponding test file.
      → Understand what is already tested and what the expected behaviour is.

  1c. Read docs/business-rules.md for the relevant rule area.
      → Find the exact rule IDs that apply. Write them down.

  1d. Read any related type definitions (src/types/index.ts).
      → Confirm you are working with the correct data shapes.

  1e. Read the API contract in docs/api/ if one exists.
      → Confirm the endpoint shape, required headers, and error codes.
```

**Output of this step:**
A list of every file read, and the specific lines or functions that need to change.

If a required file does not exist yet, say so explicitly before proceeding.

---

### Step 2 — Summarise Current Behaviour

**Rule: State what the code does today before proposing any change.**

Write a plain-language summary in this format:

```
Current behaviour:
  - The function [name] in [file] currently does [X].
  - It is called by [callers].
  - It reads from [tables/services].
  - It writes to [tables/services].
  - It enforces [rules] today.
  - It does NOT currently enforce [gaps, if any].

Gap or problem:
  - The requested change is needed because [reason].
  - The specific behaviour that must change is [description].
```

Do not move to Step 3 until this summary is written.
If the summary reveals that the existing code already handles the request,
say so and ask for clarification before continuing.

---

### Step 3 — Propose the Smallest Safe Change

**Rule: Solve the stated problem. Not a future version of it.**

Before writing any code, answer these questions:

```
3a. Can this be solved by changing one function instead of three?
    If yes → change only that function.

3b. Can this be solved by adding a parameter instead of a new class?
    If yes → add the parameter.

3c. Can this be solved without a new file?
    If yes → do not create a new file.

3d. Can this be solved without a new npm package?
    If yes → do not add a package.

3e. Can this be solved without a new database table or column?
    If yes → do not alter the schema.

3f. Can this be solved without a new service, queue, or cache?
    If yes → do not add infrastructure.
```

**Output of this step:**
A one-paragraph description of exactly what will change, naming the specific
files, functions, and lines affected. Nothing else.

If the minimal change is larger than expected, explain why before proceeding.

---

### Step 4 — Identify Risks

**Rule: State every risk before writing code. Never discover risks after.**

For every proposed change, evaluate:

```
FINANCIAL RISK
  [ ] Could this change cause money to be moved incorrectly?
  [ ] Could this change allow a refund to exceed the original amount?
  [ ] Could this change cause a ledger entry to be skipped?
  [ ] Could this change allow a duplicate payment or refund?

SECURITY RISK
  [ ] Could this change expose a SQL injection vector?
  [ ] Could this change bypass an authorization check?
  [ ] Could this change expose PII, tokens, or payment data in a response?
  [ ] Could this change allow cross-merchant data access?

DATA INTEGRITY RISK
  [ ] Could this change produce a partial write (refund without ledger entry)?
  [ ] Could this change break an existing audit trail?
  [ ] Could this change make a previously idempotent operation non-idempotent?

COMPATIBILITY RISK
  [ ] Could this change break an existing API contract?
  [ ] Could this change break an existing test?
  [ ] Does this change require a database migration?
```

**Output of this step:**
A labelled list:
```
[RISK] Description of risk and which scenario triggers it.
[RISK] ...
[ACCEPTED RISK] Risk that is known and acceptable, with justification.
```

If any RISK is unresolved, stop and ask the developer before proceeding.

---

### Step 5 — List Tests

**Rule: State the tests before writing the implementation.**

For every change, list the specific test cases that must exist after the
change is merged. Use this format:

```
Unit tests required:
  ✓ [function name] — [what it tests] — expected result
  ✓ ...

Integration tests required:
  ✓ [HTTP method + path] — [scenario] — expected HTTP status + body
  ✓ ...

Tests that must NOT be deleted or weakened:
  ✓ [existing test name or description]
  ✓ ...
```

Minimum test coverage for any refund-related change:

```
  ✓ Happy path — full refund on SUCCESS transaction — 201
  ✓ Happy path — partial refund — 201
  ✓ Error — non-SUCCESS transaction — 422 REFUND_INELIGIBLE
  ✓ Error — amount = 0 — 400 INVALID_AMOUNT
  ✓ Error — over-refund — 422 OVER_REFUND
  ✓ Error — unsupported currency — 422 UNSUPPORTED_CURRENCY
  ✓ Idempotency — same key + same payload — 200 (original response)
  ✓ Idempotency — same key + different payload — 409 CONFLICT
  ✓ Auth — missing permission — 403 FORBIDDEN
  ✓ Auth — out-of-scope merchant — 403 MERCHANT_SCOPE_VIOLATION
  ✓ Audit — success path writes audit record
  ✓ Audit — failure path writes audit record
  ✓ Ledger — success path writes ledger reversal entry
  ✓ Concurrency — two simultaneous requests do not over-refund
```

Do not mark a change as complete until every listed test passes.

---

### Step 6 — State Assumptions

**Rule: Every assumption must be labelled. Unlabelled assumptions are bugs.**

Before presenting code, list every assumption made during Steps 1–5.
Use this format:

```
[ASSUMPTION] The idempotency middleware is already registered globally
             on the Express router. If it is not, the refund endpoint
             will accept requests without an Idempotency-Key header.

[ASSUMPTION] The JWT secret is available as process.env.JWT_SECRET.
             If this variable is missing at runtime, authentication
             will throw an unhandled error.

[ASSUMPTION] All amounts in the database are stored in paise (integer).
             If any amount is stored as rupees (float), the over-refund
             guard will produce incorrect results.
```

For each assumption, state:
- What you assumed
- What would go wrong if the assumption is incorrect
- How the developer can verify the assumption

If you cannot state an assumption clearly, that means you are guessing.
Stop and ask instead.

---

### Step 7 — Avoid Guessing

**Rule: If it is not documented, do not implement it.**

This step is a gate, not an action. Before presenting the final code,
answer every question below. If any answer is “I assumed” or “I inferred,”
go back to the relevant step.

```
Business logic gate:
  [ ] Every business rule I implemented has a Rule ID in docs/business-rules.md.
  [ ] I did not infer any rule from a variable name, column name, or similar system.
  [ ] I did not implement a rule that “makes sense” but is not documented.

Security gate:
  [ ] I did not assume the frontend validates anything that the backend does not also validate.
  [ ] I did not assume an auth check exists somewhere else in the stack.
  [ ] I did not assume sensitive data is masked at a layer I did not inspect.

Scope gate:
  [ ] Every file I modified was listed in Step 1.
  [ ] I did not modify any file outside the stated task scope.
  [ ] I did not add any dependency, table, or infrastructure not listed in Step 3.

Clarity gate:
  [ ] Every assumption is labelled [ASSUMPTION] in my output.
  [ ] Every risk is labelled [RISK] in my output.
  [ ] I have not used the words "should," "probably," or "might" to describe
      the behaviour of security-critical code.
```

If any checkbox is unchecked, resolve it before presenting code.

---

## Output Template

After completing all 7 steps, present results in this format:

```
## Safe Fintech Change — Output

### Step 1: Files Inspected
- [file path] — [what was noted]

### Step 2: Current Behaviour
[plain-language summary]

### Step 3: Proposed Change
[one-paragraph minimal change description]

### Step 4: Risks
[RISK] ...
[ACCEPTED RISK] ...

### Step 5: Tests Required
Unit:
  ✓ ...
Integration:
  ✓ ...

### Step 6: Assumptions
[ASSUMPTION] ...

### Step 7: Guessing Check
[ ] All rules traced to docs/business-rules.md
[ ] All files within stated scope
[ ] All assumptions labelled

---
[Generated code follows here]
```

---

## Anti-Patterns This Skill Prevents

| Anti-Pattern | Caught At Step |
|---|---|
| Editing a file without reading it | Step 1 |
| Implementing a rule not in business-rules.md | Step 7 |
| Proposing a new service when a function change is enough | Step 3 |
| Missing a SQL injection vector | Step 4 |
| Skipping audit log on error path | Step 4 + Step 5 |
| Not listing concurrency test | Step 5 |
| Assuming idempotency middleware is wired in | Step 6 |
| Writing “probably safe” in a financial context | Step 7 |
