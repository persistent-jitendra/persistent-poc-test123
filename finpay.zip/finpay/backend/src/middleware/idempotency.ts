// FinPay — Idempotency Middleware
// Rules: ID-001..ID-005 in docs/business-rules.md
// Must be applied to POST /refunds before the controller runs.

import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { pool } from '../db';
import { Errors } from '../errors/AppError';
import { sendError } from '../utils/responseFormatter';
import { UUID_V4_REGEX, IDEMPOTENCY_KEY_TTL_HOURS } from '../refunds/refund.constants';
import { IdempotencyRecord } from '../types';

function hashPayload(body: unknown): string {
  return crypto
    .createHash('sha256')
    .update(JSON.stringify(body))
    .digest('hex');
}

export function idempotency() {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    // Rule ID-001 — key header is mandatory
    const key = req.headers['idempotency-key'] as string | undefined;
    if (!key) {
      sendError(res, Errors.missingIdempotencyKey());
      return;
    }

    // Rule ID-002 — must be UUID v4
    if (!UUID_V4_REGEX.test(key)) {
      sendError(res, Errors.invalidIdempotencyKey());
      return;
    }

    const payloadHash = hashPayload(req.body);

    try {
      // Check existing record
      const existing = await pool.query<IdempotencyRecord>(
        `SELECT * FROM idempotency_keys
         WHERE key = $1 AND expires_at > NOW()`,
        [key]
      );

      if (existing.rowCount && existing.rowCount > 0) {
        const record = existing.rows[0];

        // Rule ID-004 — same key, different payload → 409
        if (record.payload_hash !== payloadHash) {
          sendError(res, Errors.idempotencyConflict());
          return;
        }

        // Rule ID-003 — same key, same payload → return original response
        res.status(record.response_status).json(record.response_body);
        return;
      }

      // Key not seen before — attach context for the controller to store after success
      (req as Request & { idempotencyKey: string; payloadHash: string }).idempotencyKey = key;
      (req as Request & { idempotencyKey: string; payloadHash: string }).payloadHash = payloadHash;

      // Wrap res.json so we can capture the response body and persist the key
      const originalJson = res.json.bind(res);
      res.json = function (body: unknown) {
        // Only store on success responses (2xx)
        if (res.statusCode >= 200 && res.statusCode < 300) {
          const ttl = IDEMPOTENCY_KEY_TTL_HOURS;
          pool.query(
            `INSERT INTO idempotency_keys (key, payload_hash, response_status, response_body, expires_at)
             VALUES ($1, $2, $3, $4, NOW() + INTERVAL '${ttl} hours')
             ON CONFLICT (key) DO NOTHING`,
            [key, payloadHash, res.statusCode, JSON.stringify(body)]
          ).catch((err: Error) => {
            console.error('[Idempotency] Failed to persist key:', err.message);
          });
        }
        return originalJson(body);
      };

      next();
    } catch {
      sendError(res, Errors.internalError());
    }
  };
}
