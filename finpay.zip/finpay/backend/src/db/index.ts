// FinPay — Database Client
// Single pg Pool instance shared across the application.
// Connection config loaded exclusively from environment variables — never hardcoded.

import { Pool, PoolClient } from 'pg';

const pool = new Pool({
  host:     process.env.DB_HOST,
  port:     Number(process.env.DB_PORT ?? 5432),
  database: process.env.DB_NAME,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  ssl:      process.env.DB_SSL === 'true' ? { rejectUnauthorized: true } : false,
  max:      Number(process.env.DB_POOL_MAX ?? 10),
});

pool.on('error', (err) => {
  // Log connection errors without exposing credentials
  console.error('[DB] Unexpected pool error:', err.message);
});

export { pool };

// ─── Transaction wrapper ──────────────────────────────────────────────────────
// Rule: multi-table financial operations must be atomic (refund + ledger + audit).
// Always use this wrapper — never manage BEGIN/COMMIT/ROLLBACK manually.

export async function withTransaction<T>(
  fn: (client: PoolClient) => Promise<T>
): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}
