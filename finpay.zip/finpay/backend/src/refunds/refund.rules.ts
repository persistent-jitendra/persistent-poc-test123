// FinPay — Refund Business Rules Enforcement
// Every function here maps to a rule ID in docs/business-rules.md.
// Do not add validation logic here without a corresponding rule.

import { Transaction, Refund } from '../types';
import { Errors } from '../errors/AppError';
import { SUPPORTED_CURRENCIES, REFUNDABLE_STATUSES } from './refund.constants';

// Rule RE-001 — Only SUCCESS transactions can be refunded
export function assertTransactionIsRefundable(txn: Transaction): void {
  if (!REFUNDABLE_STATUSES.includes(txn.status as typeof REFUNDABLE_STATUSES[number])) {
    throw Errors.refundIneligible(
      `Transaction status '${txn.status}' is not eligible for refund. Only SUCCESS transactions can be refunded.`
    );
  }
}

// Rule RE-002 — Only INR is supported
export function assertSupportedCurrency(currency: string): void {
  if (!SUPPORTED_CURRENCIES.includes(currency as typeof SUPPORTED_CURRENCIES[number])) {
    throw Errors.unsupportedCurrency(currency);
  }
}

// Rule RA-001 — Refund amount must be > 0
export function assertAmountIsPositive(amount: number): void {
  if (!Number.isInteger(amount) || amount <= 0) {
    throw Errors.invalidAmount('Refund amount must be a positive integer (in paise).');
  }
}

// Rule RA-002 + RA-003 + RA-004 — Over-refund guard
// Calculates total already refunded and ensures the new amount does not exceed the original.
export function assertNoOverRefund(
  transaction: Transaction,
  existingRefunds: Refund[],
  requestedAmount: number
): void {
  const totalRefunded = existingRefunds
    .filter((r) => r.status === 'SUCCESS')
    .reduce((sum, r) => sum + r.amount, 0);

  if (totalRefunded + requestedAmount > transaction.amount) {
    throw Errors.overRefund(transaction.amount, totalRefunded, requestedAmount);
  }
}

// Composite eligibility check — call this once before creating a refund
export function assertRefundEligibility(
  transaction: Transaction,
  existingRefunds: Refund[],
  requestedAmount: number,
  currency: string
): void {
  assertTransactionIsRefundable(transaction);    // RE-001
  assertSupportedCurrency(currency);             // RE-002
  assertAmountIsPositive(requestedAmount);       // RA-001
  assertNoOverRefund(transaction, existingRefunds, requestedAmount); // RA-002..RA-004
}
