// FinPay — Refund Controller
// Routes handled:
//   POST   /transactions/:transactionId/refunds  → createRefund
//   GET    /transactions/:transactionId/refunds  → listRefunds
//   GET    /refunds/:refundId                    → getRefund
// Auth:    authenticate + requirePermission + requireMerchantScope (applied in router)

import { Request, Response } from 'express';
import { AppError } from '../errors/AppError';
import { sendSuccess, sendError, sendInternalError } from '../utils/responseFormatter';
import { refundService } from './refundService';
import { AuthenticatedRequest } from '../auth/requirePermission';
import { CreateRefundPayload, RefundResponse } from '../types';

function toRefundResponse(refund: import('../types').Refund): RefundResponse {
  return {
    id:             refund.id,
    transaction_id: refund.transaction_id,
    amount:         refund.amount,
    currency:       refund.currency,
    status:         refund.status,
    reason:         refund.reason,
    initiated_by:   refund.initiated_by,
    created_at:     refund.created_at,
  };
}

export const refundController = {

  // POST /transactions/:transactionId/refunds
  async createRefund(req: Request, res: Response): Promise<void> {
    const actor  = (req as unknown as AuthenticatedRequest).user;
    const ipAddr = req.ip ?? null;
    const idempotencyKey = req.headers['idempotency-key'] as string;

    const payload: CreateRefundPayload = {
      transaction_id: req.params.transactionId,
      amount:         req.body.amount,
      currency:       req.body.currency,
      reason:         req.body.reason,
    };

    try {
      const refund = await refundService.createRefund(
        payload,
        actor.id,
        idempotencyKey,
        ipAddr
      );
      sendSuccess(res, toRefundResponse(refund), 201);
    } catch (err) {
      // Rule AU-001 — audit even on failure
      if (err instanceof AppError) {
        await refundService.recordFailedAttempt({
          actorId:        actor.id,
          transactionId:  payload.transaction_id,
          amount:         payload.amount ?? 0,
          currency:       payload.currency ?? 'INR',
          outcome:
            err.code === 'REFUND_INELIGIBLE'        ? 'INELIGIBLE'
            : err.code === 'IDEMPOTENCY_CONFLICT'   ? 'CONFLICT'
            : err.code === 'FORBIDDEN' || err.code === 'MERCHANT_SCOPE_VIOLATION' ? 'FORBIDDEN'
            : 'FAILED',
          failureReason:  err.message,
          ipAddress:      ipAddr,
          idempotencyKey: idempotencyKey ?? null,
        }).catch(() => { /* audit failure must not mask original error */ });

        sendError(res, err);
        return;
      }
      sendInternalError(res);
    }
  },

  // GET /transactions/:transactionId/refunds
  async listRefunds(req: Request, res: Response): Promise<void> {
    try {
      const { transactionId } = req.params;
      const refunds = await refundService.listRefundsByTransaction(transactionId);
      sendSuccess(res, refunds.map(toRefundResponse));
    } catch (err) {
      if (err instanceof AppError) { sendError(res, err); return; }
      sendInternalError(res);
    }
  },

  // GET /refunds/:refundId
  async getRefund(req: Request, res: Response): Promise<void> {
    try {
      const { refundId } = req.params;
      const refund = await refundService.getRefundById(refundId);
      sendSuccess(res, toRefundResponse(refund));
    } catch (err) {
      if (err instanceof AppError) { sendError(res, err); return; }
      sendInternalError(res);
    }
  },
};
