// FinPay — Refund Service
// Orchestrates the full refund creation flow.
// All business rule checks delegate to refund.rules.ts.
// All DB writes are atomic via withTransaction().

import { PoolClient } from 'pg';
import { pool, withTransaction } from '../db';
import { CreateRefundPayload, Refund, Transaction } from '../types';
import { assertRefundEligibility } from './refund.rules';
import { auditLogger } from '../audit/auditLogger';
import { ledgerService } from '../ledger/ledgerService';
import { Errors } from '../errors/AppError';
import { REFUND_ID_PREFIX } from './refund.constants';
import crypto from 'crypto';

// ─── Helpers ─────────────────────────────────────────────────────────────────

function generateRefundId(): string {
  return `${REFUND_ID_PREFIX}${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
}

async function getTransaction(client: PoolClient, id: string): Promise<Transaction> {
  const result = await client.query<Transaction>(
    'SELECT * FROM transactions WHERE id = $1',
    [id]
  );
  if (!result.rowCount || result.rowCount === 0) {
    throw Errors.transactionNotFound(id);
  }
  return result.rows[0];
}

async function getExistingRefunds(client: PoolClient, transactionId: string): Promise<Refund[]> {
  const result = await client.query<Refund>(
    `SELECT * FROM refunds WHERE transaction_id = $1`,
    [transactionId]
  );
  return result.rows;
}

// ─── Public API ───────────────────────────────────────────────────────────────

export const refundService = {

  // Create a refund — fully atomic (refund + ledger + audit in one transaction)
  async createRefund(
    payload: CreateRefundPayload,
    actorId: string,
    idempotencyKey: string,
    ipAddress: string | null
  ): Promise<Refund> {
    return withTransaction(async (client) => {
      // 1. Fetch transaction (inside tx for consistent read)
      const transaction = await getTransaction(client, payload.transaction_id);

      // 2. Fetch existing refunds for over-refund guard
      const existingRefunds = await getExistingRefunds(client, payload.transaction_id);

      // 3. Assert all business rules (throws AppError on any violation)
      assertRefundEligibility(
        transaction,
        existingRefunds,
        payload.amount,
        payload.currency
      );

      // 4. Create refund record
      const refundId = generateRefundId();
      const refundResult = await client.query<Refund>(
        `INSERT INTO refunds
           (id, transaction_id, amount, currency, status, reason, initiated_by, idempotency_key)
         VALUES ($1,$2,$3,$4,'SUCCESS',$5,$6,$7)
         RETURNING *`,
        [
          refundId,
          payload.transaction_id,
          payload.amount,
          payload.currency,
          payload.reason ?? null,
          actorId,
          idempotencyKey,
        ]
      );
      const refund = refundResult.rows[0];

      // 5. Write ledger reversal entry (Rule LE-001..LE-005)
      await ledgerService.createReversal(client, {
        transaction_id: transaction.id,
        refund_id:      refund.id,
        amount:         refund.amount,
        currency:       refund.currency,
        merchant_id:    transaction.merchant_id,
      });

      // 6. Write audit record — success path (Rule AU-001..AU-004)
      await auditLogger.record(client, {
        actor_id:        actorId,
        transaction_id:  transaction.id,
        refund_id:       refund.id,
        amount:          refund.amount,
        currency:        refund.currency,
        outcome:         'SUCCESS',
        failure_reason:  null,
        ip_address:      ipAddress,
        idempotency_key: idempotencyKey,
      });

      return refund;
    });
  },

  // Get a single refund by ID
  async getRefundById(refundId: string): Promise<Refund> {
    const result = await pool.query<Refund>(
      'SELECT * FROM refunds WHERE id = $1',
      [refundId]
    );
    if (!result.rowCount || result.rowCount === 0) {
      throw Errors.refundNotFound(refundId);
    }
    return result.rows[0];
  },

  // List all refunds for a transaction — Rule FE-005: ordered by created_at DESC
  async listRefundsByTransaction(transactionId: string): Promise<Refund[]> {
    const result = await pool.query<Refund>(
      `SELECT * FROM refunds
       WHERE transaction_id = $1
       ORDER BY created_at DESC`,
      [transactionId]
    );
    return result.rows;
  },

  // Sum of all successful refunds for a transaction (used for masking + over-refund guard)
  async getTotalRefunded(transactionId: string): Promise<number> {
    const result = await pool.query<{ total: string }>(
      `SELECT COALESCE(SUM(amount), 0) AS total
       FROM refunds
       WHERE transaction_id = $1 AND status = 'SUCCESS'`,
      [transactionId]
    );
    return Number(result.rows[0].total);
  },

  // Write a failed-attempt audit record — called from controller catch block
  async recordFailedAttempt(
    payload: {
      actorId: string;
      transactionId: string;
      amount: number;
      currency: string;
      outcome: 'FAILED' | 'INELIGIBLE' | 'CONFLICT' | 'FORBIDDEN';
      failureReason: string;
      ipAddress: string | null;
      idempotencyKey: string | null;
    }
  ): Promise<void> {
    // Rule AU-001 — audit even on failure; use a non-transactional write
    // because the main transaction was already rolled back
    const client = await pool.connect();
    try {
      await auditLogger.record(client, {
        actor_id:        payload.actorId,
        transaction_id:  payload.transactionId,
        refund_id:       null,
        amount:          payload.amount,
        currency:        payload.currency,
        outcome:         payload.outcome,
        failure_reason:  payload.failureReason,
        ip_address:      payload.ipAddress,
        idempotency_key: payload.idempotencyKey,
      });
    } finally {
      client.release();
    }
  },
};
