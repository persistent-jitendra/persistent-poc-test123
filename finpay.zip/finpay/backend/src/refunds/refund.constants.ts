// FinPay — Refund Constants
// All values here are derived directly from docs/business-rules.md.
// Do not change these values without a corresponding rule update.

// Rule RE-002 — Only INR is supported
export const SUPPORTED_CURRENCIES = ['INR'] as const;

// Rule RE-001 — Only SUCCESS transactions can be refunded
export const REFUNDABLE_STATUSES = ['SUCCESS'] as const;

// Rule LE-003 — Ledger entry type for refund reversals
export const LEDGER_ENTRY_TYPE_REVERSAL = 'REFUND_REVERSAL' as const;

// Rule ID-005 — Idempotency key TTL
export const IDEMPOTENCY_KEY_TTL_HOURS = 24;

// Rule ID-002 — UUID v4 pattern
export const UUID_V4_REGEX =
  /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

// Refund ID prefix
export const REFUND_ID_PREFIX = 'RFD-';
