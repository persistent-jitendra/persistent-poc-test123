// FinPay — Express Application Entry Point
// Global error handler never exposes stack traces or internal messages.

import express, { Request, Response, NextFunction } from 'express';
import helmet from 'helmet';
import routes from './routes';
import { AppError } from './errors/AppError';
import { sendError, sendInternalError } from './utils/responseFormatter';

const app = express();

// ─── Security headers ─────────────────────────────────────────────────────────
app.use(helmet());

// ─── Body parsing ─────────────────────────────────────────────────────────────
app.use(express.json({ limit: '16kb' }));

// ─── API routes ───────────────────────────────────────────────────────────────
app.use('/api/v1', routes);

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok' }));

// ─── Global error handler ─────────────────────────────────────────────────────
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  if (err instanceof AppError) {
    sendError(res, err);
    return;
  }
  // Never expose internal error detail to client
  console.error('[Unhandled]', err);
  sendInternalError(res);
});

export default app;
