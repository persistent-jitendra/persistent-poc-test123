// FinPay — Response Formatter
// All controllers must use these helpers — never build raw response objects inline.
// Stack traces are never included in responses.

import { Response } from 'express';
import { AppError } from '../errors/AppError';
import { ApiResponse } from '../types';

export function sendSuccess<T>(res: Response, data: T, statusCode = 200): void {
  const body: ApiResponse<T> = { data };
  res.status(statusCode).json(body);
}

export function sendError(res: Response, error: AppError): void {
  const body: ApiResponse<never> = {
    error: {
      code: error.code,
      message: error.message,
      ...(error.details ? { details: error.details } : {}),
    },
  };
  res.status(error.statusCode).json(body);
}

export function sendInternalError(res: Response): void {
  res.status(500).json({
    error: {
      code: 'INTERNAL_ERROR',
      message: 'An unexpected error occurred. Please try again.',
    },
  });
}
