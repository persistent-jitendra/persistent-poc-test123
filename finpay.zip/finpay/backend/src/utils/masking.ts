// FinPay — Data Masking Utility
// Rules: DP-001..DP-005 in docs/business-rules.md
// All API responses that include payment data must pass through maskSensitiveData().
// Never implement custom masking outside this file.

import { Transaction, TransactionResponse } from '../types';

// ─── Individual field maskers ────────────────────────────────────────────────

// Rule DP-001: UPI VPA — show first 2 chars + domain only
// e.g. "abcdef@okaxis" → "ab****@okaxis"
export function maskUpiVpa(vpa: string): string {
  const atIndex = vpa.indexOf('@');
  if (atIndex === -1) return '****';
  const local = vpa.slice(0, atIndex);
  const domain = vpa.slice(atIndex);
  const visible = local.slice(0, 2);
  return `${visible}****${domain}`;
}

// Rule DP-002: Bank account — show last 4 digits only
// e.g. "123456789012" → "****9012"
export function maskBankAccount(account: string): string {
  if (account.length <= 4) return '****';
  return `****${account.slice(-4)}`;
}

// Rule DP-003: Card number — show last 4 digits only
// e.g. "4111111111111111" → "****1111"
export function maskCardNumber(card: string): string {
  const digits = card.replace(/\s/g, '');
  if (digits.length <= 4) return '****';
  return `****${digits.slice(-4)}`;
}

// ─── Payment ref masker — routes to the right masker by payment method ────────

export function maskPaymentRef(
  paymentRef: string | null,
  paymentMethod: string
): string | null {
  if (!paymentRef) return null;
  switch (paymentMethod) {
    case 'UPI':        return maskUpiVpa(paymentRef);
    case 'CARD':       return maskCardNumber(paymentRef);
    case 'NETBANKING': return maskBankAccount(paymentRef);
    case 'WALLET':     return `****${paymentRef.slice(-4)}`;
    default:           return '****';
  }
}

// ─── Full transaction masker ──────────────────────────────────────────────────

// Produces a TransactionResponse safe for frontend consumption.
// Accepts pre-computed refund totals (fetched by the service layer).
export function maskTransaction(
  txn: Transaction,
  totalRefunded: number
): TransactionResponse {
  const remaining = txn.amount - totalRefunded;
  return {
    id:                         txn.id,
    user_id:                    txn.user_id,
    merchant_id:                txn.merchant_id,
    amount:                     txn.amount,
    currency:                   txn.currency,
    status:                     txn.status,
    payment_method:             txn.payment_method,
    payment_ref_masked:         maskPaymentRef(txn.payment_ref, txn.payment_method),
    created_at:                 txn.created_at,
    is_refundable:              txn.status === 'SUCCESS' && remaining > 0,
    total_refunded:             totalRefunded,
    remaining_refundable_amount: remaining > 0 ? remaining : 0,
  };
}

// ─── Generic sensitive-data stripper for logs ─────────────────────────────────
// Rule DP-005: Sensitive fields must not appear in logs.

const SENSITIVE_KEYS = new Set([
  'payment_ref', 'card_number', 'cvv', 'vpa', 'account_number',
  'ifsc', 'password', 'token', 'secret', 'authorization',
]);

export function stripSensitiveFields(obj: Record<string, unknown>): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (SENSITIVE_KEYS.has(key.toLowerCase())) {
      result[key] = '[REDACTED]';
    } else if (value && typeof value === 'object' && !Array.isArray(value)) {
      result[key] = stripSensitiveFields(value as Record<string, unknown>);
    } else {
      result[key] = value;
    }
  }
  return result;
}
