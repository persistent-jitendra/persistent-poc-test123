// FinPay Admin Refund Module — Shared Types
// Do not add fields here without a corresponding business rule in docs/business-rules.md

export type TransactionStatus = 'PENDING' | 'SUCCESS' | 'FAILED' | 'REVERSED';
export type PaymentMethod = 'UPI' | 'CARD' | 'NETBANKING' | 'WALLET';
export type RefundStatus = 'PENDING' | 'SUCCESS' | 'FAILED';
export type LedgerEntryType = 'PAYMENT' | 'REFUND_REVERSAL';
export type AuditOutcome = 'SUCCESS' | 'FAILED' | 'CONFLICT' | 'INELIGIBLE' | 'FORBIDDEN';
export type UserRole = 'admin' | 'support';

// ─── Transaction ─────────────────────────────────────────────────────────────

export interface Transaction {
  id: string;
  user_id: string;
  merchant_id: string;
  amount: number;         // paise
  currency: string;
  status: TransactionStatus;
  payment_method: PaymentMethod;
  payment_ref: string | null;   // raw — always masked before leaving backend
  created_at: string;
  updated_at: string;
}

// Shape returned to the frontend — sensitive fields masked (Rule DP-001..DP-004)
export interface TransactionResponse {
  id: string;
  user_id: string;
  merchant_id: string;
  amount: number;
  currency: string;
  status: TransactionStatus;
  payment_method: PaymentMethod;
  payment_ref_masked: string | null;
  created_at: string;
  is_refundable: boolean;
  total_refunded: number;
  remaining_refundable_amount: number;
}

// ─── Refund ───────────────────────────────────────────────────────────────────

export interface Refund {
  id: string;
  transaction_id: string;
  amount: number;         // paise
  currency: string;
  status: RefundStatus;
  reason: string | null;
  initiated_by: string;
  idempotency_key: string;
  created_at: string;
  updated_at: string;
}

export interface CreateRefundPayload {
  transaction_id: string;
  amount: number;
  currency: string;
  reason?: string;
}

export interface RefundResponse {
  id: string;
  transaction_id: string;
  amount: number;
  currency: string;
  status: RefundStatus;
  reason: string | null;
  initiated_by: string;
  created_at: string;
}

// ─── Idempotency ──────────────────────────────────────────────────────────────

export interface IdempotencyRecord {
  key: string;
  payload_hash: string;
  response_status: number;
  response_body: Record<string, unknown>;
  created_at: string;
  expires_at: string;
}

// ─── Audit ────────────────────────────────────────────────────────────────────

export interface AuditRecord {
  actor_id: string;
  transaction_id: string;
  refund_id: string | null;
  amount: number;
  currency: string;
  outcome: AuditOutcome;
  failure_reason: string | null;
  ip_address: string | null;
  idempotency_key: string | null;
}

// ─── Ledger ───────────────────────────────────────────────────────────────────

export interface LedgerEntry {
  entry_type: LedgerEntryType;
  transaction_id: string;
  refund_id: string;
  amount: number;       // negative for reversals (Rule LE-001)
  currency: string;
  merchant_id: string;
}

// ─── Auth / Admin User ────────────────────────────────────────────────────────

export interface AdminUser {
  id: string;
  email: string;
  role: UserRole;
  permissions: string[];
  allowed_merchant_ids: string[];
  is_active: boolean;
}

// Attached to req by JWT middleware
export interface AuthenticatedRequest extends Request {
  user: AdminUser;
  ip: string;
}

// ─── API ──────────────────────────────────────────────────────────────────────

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}

export interface ApiResponse<T> {
  data?: T;
  error?: ApiError;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    total: number;
    page: number;
    limit: number;
  };
}
