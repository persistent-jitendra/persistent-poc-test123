// FinPay — Ledger Service
// Rules: LE-001..LE-005 in docs/business-rules.md
// Creates reversal entries for successful refunds.
// Must be called inside the same DB transaction as the refund write (Rule LE-005).
// Ledger entries are immutable — never update or delete them.

import { PoolClient } from 'pg';
import { LedgerEntry } from '../types';
import { LEDGER_ENTRY_TYPE_REVERSAL } from '../refunds/refund.constants';

export const ledgerService = {
  async createReversal(client: PoolClient, entry: Omit<LedgerEntry, 'entry_type'>): Promise<void> {
    // Rule LE-003 — entry type is always REFUND_REVERSAL
    // Rule LE-001 — amount stored as negative to represent money leaving the merchant
    await client.query(
      `INSERT INTO ledger_entries
         (entry_type, transaction_id, refund_id, amount, currency, merchant_id)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [
        LEDGER_ENTRY_TYPE_REVERSAL,
        entry.transaction_id,
        entry.refund_id,
        -Math.abs(entry.amount),   // always negative for reversals
        entry.currency,
        entry.merchant_id,
      ]
    );
  },
};
