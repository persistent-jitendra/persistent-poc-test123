// FinPay — Audit Logger
// Rules: AU-001..AU-004 in docs/business-rules.md
// Every refund attempt (success or failure) must call auditLogger.record().
// Audit records are immutable — never update or delete them.
// Must be called inside the same DB transaction as the refund write (Rule AU-004).

import { PoolClient } from 'pg';
import { AuditRecord } from '../types';

export const auditLogger = {
  async record(client: PoolClient, entry: AuditRecord): Promise<void> {
    // Rule AU-002 — required fields enforced by type
    await client.query(
      `INSERT INTO refund_audit
         (actor_id, transaction_id, refund_id, amount, currency,
          outcome, failure_reason, ip_address, idempotency_key)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [
        entry.actor_id,
        entry.transaction_id,
        entry.refund_id ?? null,
        entry.amount,
        entry.currency,
        entry.outcome,
        entry.failure_reason ?? null,
        entry.ip_address ?? null,
        entry.idempotency_key ?? null,
      ]
    );
  },
};
