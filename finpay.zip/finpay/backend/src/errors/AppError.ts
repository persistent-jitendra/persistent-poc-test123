// FinPay — AppError
// Single error class for all application-level errors.
// Never throw plain Error in business logic — always use AppError.
// Stack traces are never exposed to API responses.

export class AppError extends Error {
  public readonly code: string;
  public readonly statusCode: number;
  public readonly details?: Record<string, unknown>;

  constructor(code: string, message: string, statusCode: number, details?: Record<string, unknown>) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.statusCode = statusCode;
    this.details = details;
    Error.captureStackTrace(this, this.constructor);
  }
}

// ─── Named error factories (map to business rules) ───────────────────────────

export const Errors = {
  // Eligibility — RE-001..RE-004
  refundIneligible: (reason: string) =>
    new AppError('REFUND_INELIGIBLE', reason, 422),

  // Amount — RA-001..RA-004
  invalidAmount: (msg: string) =>
    new AppError('INVALID_AMOUNT', msg, 400),

  overRefund: (original: number, alreadyRefunded: number, requested: number) =>
    new AppError(
      'OVER_REFUND',
      `Refund of ${requested} would exceed original amount. Already refunded: ${alreadyRefunded}, original: ${original}`,
      422,
      { original, already_refunded: alreadyRefunded, requested }
    ),

  // Currency — RE-002
  unsupportedCurrency: (currency: string) =>
    new AppError('UNSUPPORTED_CURRENCY', `Currency '${currency}' is not supported. Only INR is accepted.`, 422),

  // Idempotency — ID-001..ID-004
  missingIdempotencyKey: () =>
    new AppError('MISSING_IDEMPOTENCY_KEY', 'Idempotency-Key header is required.', 400),

  invalidIdempotencyKey: () =>
    new AppError('INVALID_IDEMPOTENCY_KEY', 'Idempotency-Key must be a valid UUID v4.', 400),

  idempotencyConflict: () =>
    new AppError('IDEMPOTENCY_CONFLICT', 'Idempotency-Key has been used with a different request payload.', 409),

  // Authorization — AZ-001..AZ-005
  forbidden: (msg = 'You do not have permission to perform this action.') =>
    new AppError('FORBIDDEN', msg, 403),

  merchantScopeViolation: () =>
    new AppError('MERCHANT_SCOPE_VIOLATION', 'You are not authorised to access this merchant\'s transactions.', 403),

  // Not found
  transactionNotFound: (id: string) =>
    new AppError('TRANSACTION_NOT_FOUND', `Transaction '${id}' was not found.`, 404),

  refundNotFound: (id: string) =>
    new AppError('REFUND_NOT_FOUND', `Refund '${id}' was not found.`, 404),

  // Generic
  internalError: () =>
    new AppError('INTERNAL_ERROR', 'An unexpected error occurred. Please try again.', 500),
};
