// FinPay — Permission Middleware
// Rules: AZ-001, AZ-002, AZ-003
// Every route that touches refund data must use this middleware.
// Never inline permission checks inside controllers.

import { Request, Response, NextFunction } from 'express';
import { Errors } from '../errors/AppError';
import { sendError } from '../utils/responseFormatter';
import { AdminUser } from '../types';

export interface AuthenticatedRequest extends Request {
  user: AdminUser;
}

// Validates JWT and attaches user to req.user
// In production this verifies the JWT signature using process.env.JWT_SECRET
export function authenticate(req: Request, res: Response, next: NextFunction): void {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      sendError(res, Errors.forbidden('Missing or invalid Authorization header.'));
      return;
    }

    const token = authHeader.slice(7);
    // Dynamically require jwt to keep this file testable without the module
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const jwt = require('jsonwebtoken');
    const secret = process.env.JWT_SECRET;
    if (!secret) throw new Error('JWT_SECRET is not configured.');

    const decoded = jwt.verify(token, secret) as AdminUser;

    // Rule AZ-001 — only admin/support roles
    if (decoded.role !== 'admin' && decoded.role !== 'support') {
      sendError(res, Errors.forbidden('Insufficient role.'));
      return;
    }

    if (!decoded.is_active) {
      sendError(res, Errors.forbidden('Account is inactive.'));
      return;
    }

    (req as AuthenticatedRequest).user = decoded;
    next();
  } catch {
    // Never expose JWT error detail to the client
    sendError(res, Errors.forbidden('Authentication failed.'));
  }
}

// Rule AZ-002 / AZ-003 — permission gate
// Usage: requirePermission('refund:create')
export function requirePermission(permission: string) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const user = (req as AuthenticatedRequest).user;
    if (!user) {
      sendError(res, Errors.forbidden());
      return;
    }
    if (!user.permissions.includes(permission)) {
      sendError(res, Errors.forbidden(`Permission '${permission}' is required.`));
      return;
    }
    next();
  };
}
