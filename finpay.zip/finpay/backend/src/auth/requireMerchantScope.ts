// FinPay — Merchant Scope Middleware
// Rule: AZ-004, AZ-005
// Prevents an admin from accessing transactions outside their allowed merchant list.
// Must be applied to every route that takes a transaction_id or merchant_id parameter.

import { Request, Response, NextFunction } from 'express';
import { Errors } from '../errors/AppError';
import { sendError } from '../utils/responseFormatter';
import { AuthenticatedRequest } from './requirePermission';
import { pool } from '../db';

export function requireMerchantScope() {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    const user = (req as AuthenticatedRequest).user;
    if (!user) {
      sendError(res, Errors.forbidden());
      return;
    }

    // Rule AZ-004: empty allowed_merchant_ids means NO access
    if (!user.allowed_merchant_ids || user.allowed_merchant_ids.length === 0) {
      sendError(res, Errors.merchantScopeViolation());
      return;
    }

    // Resolve transaction_id from route params or body
    const transactionId: string | undefined =
      req.params.transactionId ?? req.params.id ?? req.body?.transaction_id;

    if (!transactionId) {
      // No transaction to scope-check — pass through (route handler will validate)
      next();
      return;
    }

    try {
      const result = await pool.query<{ merchant_id: string }>(
        'SELECT merchant_id FROM transactions WHERE id = $1',
        [transactionId]
      );

      if (result.rowCount === 0) {
        // Let the controller return the 404 — don't leak existence info here
        next();
        return;
      }

      const { merchant_id } = result.rows[0];

      if (!user.allowed_merchant_ids.includes(merchant_id)) {
        sendError(res, Errors.merchantScopeViolation());
        return;
      }

      next();
    } catch {
      sendError(res, Errors.internalError());
    }
  };
}
