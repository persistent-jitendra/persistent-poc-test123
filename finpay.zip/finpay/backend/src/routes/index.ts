// FinPay — Route Definitions
// Every refund route is protected by three middleware layers (in order):
//   1. authenticate        — valid JWT, active admin/support user
//   2. requirePermission   — correct permission for the operation
//   3. requireMerchantScope — transaction belongs to user's allowed merchants

import { Router } from 'express';
import { authenticate, requirePermission } from '../auth/requirePermission';
import { requireMerchantScope } from '../auth/requireMerchantScope';
import { idempotency } from '../middleware/idempotency';
import { transactionController } from '../transactions/transactionController';
import { refundController } from '../refunds/refundController';

const router = Router();

// ─── Transaction routes ───────────────────────────────────────────────────────

// GET /transactions/:transactionId
// Returns masked transaction with refund eligibility metadata
router.get(
  '/transactions/:transactionId',
  authenticate,
  requirePermission('refund:read'),
  requireMerchantScope(),
  transactionController.getById
);

// ─── Refund routes ────────────────────────────────────────────────────────────

// POST /transactions/:transactionId/refunds
// Initiates a full or partial refund — idempotency enforced
router.post(
  '/transactions/:transactionId/refunds',
  authenticate,
  requirePermission('refund:create'),
  requireMerchantScope(),
  idempotency(),
  refundController.createRefund
);

// GET /transactions/:transactionId/refunds
// Lists all refunds for a transaction (reverse chronological — Rule FE-005)
router.get(
  '/transactions/:transactionId/refunds',
  authenticate,
  requirePermission('refund:read'),
  requireMerchantScope(),
  refundController.listRefunds
);

// GET /refunds/:refundId
// Fetch a single refund by ID
router.get(
  '/refunds/:refundId',
  authenticate,
  requirePermission('refund:read'),
  refundController.getRefund
);

export default router;
