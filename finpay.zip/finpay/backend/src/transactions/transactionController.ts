// FinPay — Transaction Controller
// Handles: GET /transactions/:id
// Auth: authenticate + requirePermission('refund:read') + requireMerchantScope()

import { Request, Response } from 'express';
import { pool } from '../db';
import { Transaction } from '../types';
import { refundService } from '../refunds/refundService';
import { maskTransaction } from '../utils/masking';
import { sendSuccess, sendError, sendInternalError } from '../utils/responseFormatter';
import { Errors } from '../errors/AppError';
import { AppError } from '../errors/AppError';

export const transactionController = {
  async getById(req: Request, res: Response): Promise<void> {
    try {
      const { transactionId } = req.params;

      const result = await pool.query<Transaction>(
        'SELECT * FROM transactions WHERE id = $1',
        [transactionId]
      );

      if (!result.rowCount || result.rowCount === 0) {
        sendError(res, Errors.transactionNotFound(transactionId));
        return;
      }

      const txn = result.rows[0];
      const totalRefunded = await refundService.getTotalRefunded(txn.id);

      // Rule DP-001..DP-004 — mask before sending
      sendSuccess(res, maskTransaction(txn, totalRefunded));
    } catch (err) {
      if (err instanceof AppError) { sendError(res, err); return; }
      sendInternalError(res);
    }
  },
};
