// FinPay — Unit Tests: refund.rules.ts
// Verifies every business rule assertion in isolation.
// No DB, no network — pure function tests.

import {
  assertTransactionIsRefundable,
  assertSupportedCurrency,
  assertAmountIsPositive,
  assertNoOverRefund,
  assertRefundEligibility,
} from '../../src/refunds/refund.rules';
import { AppError } from '../../src/errors/AppError';
import { Transaction, Refund } from '../../src/types';

// ─── Fixtures ─────────────────────────────────────────────────────────────────

const baseTxn: Transaction = {
  id: 'TXN-10001',
  user_id: 'USER-501',
  merchant_id: 'MER-900',
  amount: 5000,
  currency: 'INR',
  status: 'SUCCESS',
  payment_method: 'UPI',
  payment_ref: 'ab****@okaxis',
  created_at: '2026-06-10T10:30:00Z',
  updated_at: '2026-06-10T10:30:00Z',
};

const successRefund = (amount: number): Refund => ({
  id: 'RFD-001',
  transaction_id: 'TXN-10001',
  amount,
  currency: 'INR',
  status: 'SUCCESS',
  reason: null,
  initiated_by: 'ADMIN-001',
  idempotency_key: 'key-001',
  created_at: '2026-06-10T11:00:00Z',
  updated_at: '2026-06-10T11:00:00Z',
});

// ─── RE-001: Only SUCCESS transactions can be refunded ────────────────────────

describe('assertTransactionIsRefundable', () => {
  test('passes for SUCCESS status', () => {
    expect(() => assertTransactionIsRefundable(baseTxn)).not.toThrow();
  });

  test.each(['PENDING', 'FAILED', 'REVERSED'] as const)(
    'throws REFUND_INELIGIBLE for status %s',
    (status) => {
      const txn = { ...baseTxn, status };
      expect(() => assertTransactionIsRefundable(txn)).toThrow(
        expect.objectContaining({ code: 'REFUND_INELIGIBLE', statusCode: 422 })
      );
    }
  );
});

// ─── RE-002: Only INR is supported ───────────────────────────────────────────

describe('assertSupportedCurrency', () => {
  test('passes for INR', () => {
    expect(() => assertSupportedCurrency('INR')).not.toThrow();
  });

  test.each(['USD', 'EUR', 'GBP', 'AED'])(
    'throws UNSUPPORTED_CURRENCY for %s',
    (currency) => {
      expect(() => assertSupportedCurrency(currency)).toThrow(
        expect.objectContaining({ code: 'UNSUPPORTED_CURRENCY', statusCode: 422 })
      );
    }
  );
});

// ─── RA-001: Refund amount must be > 0 ───────────────────────────────────────

describe('assertAmountIsPositive', () => {
  test('passes for a positive integer', () => {
    expect(() => assertAmountIsPositive(1)).not.toThrow();
    expect(() => assertAmountIsPositive(5000)).not.toThrow();
  });

  test('throws INVALID_AMOUNT for zero', () => {
    expect(() => assertAmountIsPositive(0)).toThrow(
      expect.objectContaining({ code: 'INVALID_AMOUNT' })
    );
  });

  test('throws INVALID_AMOUNT for negative amount', () => {
    expect(() => assertAmountIsPositive(-100)).toThrow(
      expect.objectContaining({ code: 'INVALID_AMOUNT' })
    );
  });

  test('throws INVALID_AMOUNT for non-integer (float)', () => {
    expect(() => assertAmountIsPositive(10.5)).toThrow(
      expect.objectContaining({ code: 'INVALID_AMOUNT' })
    );
  });
});

// ─── RA-002..RA-004: Over-refund guard ───────────────────────────────────────

describe('assertNoOverRefund', () => {
  test('passes when no prior refunds and amount equals original', () => {
    expect(() => assertNoOverRefund(baseTxn, [], 5000)).not.toThrow();
  });

  test('passes for valid partial refund with no prior refunds', () => {
    expect(() => assertNoOverRefund(baseTxn, [], 2000)).not.toThrow();
  });

  test('passes for second partial refund within limit (RA-003)', () => {
    const existing = [successRefund(2000)];
    expect(() => assertNoOverRefund(baseTxn, existing, 3000)).not.toThrow();
  });

  test('throws OVER_REFUND when amount alone exceeds original', () => {
    expect(() => assertNoOverRefund(baseTxn, [], 6000)).toThrow(
      expect.objectContaining({ code: 'OVER_REFUND', statusCode: 422 })
    );
  });

  test('throws OVER_REFUND when cumulative refunds would exceed original (RA-004)', () => {
    const existing = [successRefund(3000)];
    expect(() => assertNoOverRefund(baseTxn, existing, 3000)).toThrow(
      expect.objectContaining({ code: 'OVER_REFUND', statusCode: 422 })
    );
  });

  test('ignores FAILED refunds in cumulative total', () => {
    const failedRefund: Refund = { ...successRefund(3000), status: 'FAILED' };
    // Failed refund should not count toward total — full 5000 still available
    expect(() => assertNoOverRefund(baseTxn, [failedRefund], 5000)).not.toThrow();
  });
});

// ─── Composite: assertRefundEligibility ──────────────────────────────────────

describe('assertRefundEligibility', () => {
  test('passes for a valid full refund', () => {
    expect(() =>
      assertRefundEligibility(baseTxn, [], 5000, 'INR')
    ).not.toThrow();
  });

  test('throws if transaction is not SUCCESS', () => {
    const txn = { ...baseTxn, status: 'FAILED' as const };
    expect(() =>
      assertRefundEligibility(txn, [], 1000, 'INR')
    ).toThrow(expect.objectContaining({ code: 'REFUND_INELIGIBLE' }));
  });

  test('throws if currency is not INR', () => {
    expect(() =>
      assertRefundEligibility(baseTxn, [], 1000, 'USD')
    ).toThrow(expect.objectContaining({ code: 'UNSUPPORTED_CURRENCY' }));
  });

  test('throws if amount is zero', () => {
    expect(() =>
      assertRefundEligibility(baseTxn, [], 0, 'INR')
    ).toThrow(expect.objectContaining({ code: 'INVALID_AMOUNT' }));
  });

  test('throws if over-refund', () => {
    expect(() =>
      assertRefundEligibility(baseTxn, [successRefund(5000)], 1, 'INR')
    ).toThrow(expect.objectContaining({ code: 'OVER_REFUND' }));
  });
});
