// FinPay — Idempotency Tests
// Covers: same key + same payload, same key + different payload (409),
//         missing key, invalid key format

import request from 'supertest';
import { v4 as uuidv4 } from 'uuid';
import crypto from 'crypto';
import app from '../../src/app';

jest.mock('../../src/db', () => ({
  pool: { query: jest.fn(), connect: jest.fn() },
  withTransaction: jest.fn(),
}));
jest.mock('jsonwebtoken', () => ({ verify: jest.fn() }));

import { pool } from '../../src/db';
import jwt from 'jsonwebtoken';

const mockPool = pool as jest.Mocked<typeof pool>;
const mockJwt  = jwt  as jest.Mocked<typeof jwt>;

const adminUser = {
  id: 'ADMIN-001', email: 'admin@finpay.test', role: 'admin',
  permissions: ['refund:read', 'refund:create'],
  allowed_merchant_ids: ['MER-900'], is_active: true,
};

const BODY        = { amount: 5000, currency: 'INR' };
const VALID_KEY   = uuidv4();
const AUTH_HEADER = { Authorization: 'Bearer token' };

function hashBody(body: unknown): string {
  return crypto.createHash('sha256').update(JSON.stringify(body)).digest('hex');
}

function setupAuth() { (mockJwt.verify as jest.Mock).mockReturnValue(adminUser); }

function setupMerchantScope() {
  (mockPool.query as jest.Mock).mockResolvedValueOnce({
    rowCount: 1, rows: [{ merchant_id: 'MER-900' }],
  });
}

beforeEach(() => jest.clearAllMocks());

// ─── 10. Same key + same payload → returns original response ─────────────────
describe('Idempotency — same key + same payload returns same response', () => {
  test('200 — returns the stored response on exact replay', async () => {
    setupAuth();
    setupMerchantScope();

    const storedResponse = {
      data: {
        id: 'RFD-STORED', transaction_id: 'TXN-10001',
        amount: 5000, currency: 'INR', status: 'SUCCESS',
        reason: null, initiated_by: 'ADMIN-001',
        created_at: '2026-06-10T11:00:00Z',
      },
    };

    // Idempotency lookup — key found, hash matches
    (mockPool.query as jest.Mock).mockResolvedValueOnce({
      rowCount: 1,
      rows: [{
        key: VALID_KEY,
        payload_hash: hashBody(BODY),
        response_status: 201,
        response_body: storedResponse,
        expires_at: new Date(Date.now() + 86_400_000).toISOString(),
      }],
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', VALID_KEY)
      .send(BODY);

    // Returns the original stored response — no new refund created
    expect([200, 201]).toContain(res.status);
    expect(res.body.data.id).toBe('RFD-STORED');
  });

  test('controller (withTransaction) is NOT called on idempotency replay', async () => {
    const { withTransaction } = require('../../src/db');
    setupAuth();
    setupMerchantScope();

    (mockPool.query as jest.Mock).mockResolvedValueOnce({
      rowCount: 1,
      rows: [{
        key: VALID_KEY,
        payload_hash: hashBody(BODY),
        response_status: 201,
        response_body: { data: { id: 'RFD-CACHED' } },
        expires_at: new Date(Date.now() + 86_400_000).toISOString(),
      }],
    });

    await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', VALID_KEY)
      .send(BODY);

    // Business logic must not execute on a replay
    expect(withTransaction).not.toHaveBeenCalled();
  });

  test('expired idempotency key is treated as new (no match)', async () => {
    const { withTransaction } = require('../../src/db');
    setupAuth();
    setupMerchantScope();

    // Query returns 0 rows because expires_at < NOW() filters it out
    (mockPool.query as jest.Mock).mockResolvedValueOnce({ rowCount: 0, rows: [] });

    // Simulate the service being called fresh
    withTransaction.mockImplementationOnce(async (fn: Function) => {
      const client = { query: jest.fn() };
      client.query
        .mockResolvedValueOnce({ rowCount: 1, rows: [{
          id: 'TXN-10001', merchant_id: 'MER-900', amount: 5000,
          currency: 'INR', status: 'SUCCESS', payment_method: 'UPI',
          payment_ref: null, user_id: 'USER-501', created_at: '', updated_at: '',
        }]})
        .mockResolvedValueOnce({ rowCount: 0, rows: [] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [{
          id: 'RFD-NEW', transaction_id: 'TXN-10001', amount: 5000,
          currency: 'INR', status: 'SUCCESS', reason: null,
          initiated_by: 'ADMIN-001', idempotency_key: VALID_KEY,
          created_at: '', updated_at: '',
        }]})
        .mockResolvedValueOnce({ rowCount: 1, rows: [] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [] });
      return fn(client);
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', VALID_KEY)
      .send(BODY);

    expect(res.status).toBe(201);
    expect(withTransaction).toHaveBeenCalledTimes(1);
  });
});

// ─── 11. Same key + different payload → 409 Conflict ─────────────────────────
describe('Idempotency conflict — same key + different payload returns 409', () => {
  test('409 IDEMPOTENCY_CONFLICT when payload hash differs', async () => {
    setupAuth();
    setupMerchantScope();

    // Stored hash was for amount=5000; we are sending amount=3000 now
    (mockPool.query as jest.Mock).mockResolvedValueOnce({
      rowCount: 1,
      rows: [{
        key: VALID_KEY,
        payload_hash: hashBody({ amount: 5000, currency: 'INR' }),
        response_status: 201,
        response_body: {},
        expires_at: new Date(Date.now() + 86_400_000).toISOString(),
      }],
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', VALID_KEY)
      .send({ amount: 3000, currency: 'INR' }); // different payload

    expect(res.status).toBe(409);
    expect(res.body.error.code).toBe('IDEMPOTENCY_CONFLICT');
  });

  test('409 when only the reason field differs', async () => {
    setupAuth();
    setupMerchantScope();

    (mockPool.query as jest.Mock).mockResolvedValueOnce({
      rowCount: 1,
      rows: [{
        key: VALID_KEY,
        payload_hash: hashBody({ amount: 5000, currency: 'INR', reason: 'original reason' }),
        response_status: 201,
        response_body: {},
        expires_at: new Date(Date.now() + 86_400_000).toISOString(),
      }],
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', VALID_KEY)
      .send({ amount: 5000, currency: 'INR', reason: 'different reason' });

    expect(res.status).toBe(409);
    expect(res.body.error.code).toBe('IDEMPOTENCY_CONFLICT');
  });

  test('400 MISSING_IDEMPOTENCY_KEY when header is absent', async () => {
    setupAuth();
    setupMerchantScope();

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      // No Idempotency-Key header
      .send(BODY);

    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('MISSING_IDEMPOTENCY_KEY');
  });

  test('400 INVALID_IDEMPOTENCY_KEY when key is not UUID v4', async () => {
    setupAuth();
    setupMerchantScope();

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', 'not-a-uuid')
      .send(BODY);

    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('INVALID_IDEMPOTENCY_KEY');
  });
});
