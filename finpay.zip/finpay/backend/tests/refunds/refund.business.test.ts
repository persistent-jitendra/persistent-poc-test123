// FinPay — Business Rule Tests
// Covers: status check, amount validation, partial refunds, over-refund guard

import request from 'supertest';
import { v4 as uuidv4 } from 'uuid';
import app from '../../src/app';

jest.mock('../../src/db', () => ({
  pool: { query: jest.fn(), connect: jest.fn() },
  withTransaction: jest.fn(),
}));
jest.mock('jsonwebtoken', () => ({ verify: jest.fn() }));

import { pool, withTransaction } from '../../src/db';
import jwt from 'jsonwebtoken';

const mockPool    = pool            as jest.Mocked<typeof pool>;
const mockWithTxn = withTransaction as jest.MockedFunction<typeof withTransaction>;
const mockJwt     = jwt             as jest.Mocked<typeof jwt>;

const adminUser = {
  id: 'ADMIN-001', email: 'admin@finpay.test', role: 'admin',
  permissions: ['refund:read', 'refund:create'],
  allowed_merchant_ids: ['MER-900'], is_active: true,
};

const baseTxn = {
  id: 'TXN-10001', user_id: 'USER-501', merchant_id: 'MER-900',
  amount: 5000, currency: 'INR', status: 'SUCCESS',
  payment_method: 'UPI', payment_ref: 'ab@okaxis',
  created_at: '2026-06-10T10:30:00Z', updated_at: '2026-06-10T10:30:00Z',
};

const AUTH = { Authorization: 'Bearer token' };

function setupAuth(user = adminUser) {
  (mockJwt.verify as jest.Mock).mockReturnValue(user);
}

function setupMerchantScope(merchantId = 'MER-900') {
  (mockPool.query as jest.Mock).mockResolvedValueOnce({
    rowCount: 1, rows: [{ merchant_id: merchantId }],
  });
}

function setupIdempotencyMiss() {
  (mockPool.query as jest.Mock).mockResolvedValueOnce({ rowCount: 0, rows: [] });
}

function setupAuditWrite() {
  (mockPool.connect as jest.Mock).mockResolvedValue({
    query: jest.fn().mockResolvedValue({}),
    release: jest.fn(),
  });
}

function setupTxnInTransaction(txn = baseTxn, refunds: unknown[] = []) {
  mockWithTxn.mockImplementationOnce(async (fn: Function) => {
    const client = { query: jest.fn() };
    client.query
      .mockResolvedValueOnce({ rowCount: 1, rows: [txn] })      // transaction fetch
      .mockResolvedValueOnce({ rowCount: refunds.length, rows: refunds }); // existing refunds
    return fn(client);
  });
}

beforeEach(() => jest.clearAllMocks());

// ─── 4. Status — FAILED transaction cannot be refunded ────────────────────────
describe('Status check — only SUCCESS transactions are refundable', () => {
  test.each(['PENDING', 'FAILED', 'REVERSED'] as const)(
    '422 REFUND_INELIGIBLE for status %s',
    async (status) => {
      setupAuth();
      setupMerchantScope();
      setupIdempotencyMiss();
      setupTxnInTransaction({ ...baseTxn, status });
      setupAuditWrite();

      const res = await request(app)
        .post('/api/v1/transactions/TXN-10001/refunds')
        .set(AUTH).set('Idempotency-Key', uuidv4())
        .send({ amount: 5000, currency: 'INR' });

      expect(res.status).toBe(422);
      expect(res.body.error.code).toBe('REFUND_INELIGIBLE');
      expect(res.body.error.message).toMatch(status);
    }
  );

  test('201 — SUCCESS transaction IS refundable', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();

    const refund = { ...baseTxn, id: 'RFD-001', status: 'SUCCESS',
      transaction_id: 'TXN-10001', reason: null,
      initiated_by: 'ADMIN-001', idempotency_key: 'k1' };

    mockWithTxn.mockImplementationOnce(async (fn: Function) => {
      const client = { query: jest.fn() };
      client.query
        .mockResolvedValueOnce({ rowCount: 1, rows: [baseTxn] })
        .mockResolvedValueOnce({ rowCount: 0, rows: [] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [refund] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [] })  // ledger
        .mockResolvedValueOnce({ rowCount: 1, rows: [] }); // audit
      return fn(client);
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: 5000, currency: 'INR' });

    expect(res.status).toBe(201);
  });
});

// ─── 5. Amount — zero refund is rejected ─────────────────────────────────────
describe('Amount — zero refund is rejected', () => {
  test('400 INVALID_AMOUNT for amount = 0', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();
    setupTxnInTransaction();
    setupAuditWrite();

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: 0, currency: 'INR' });

    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('INVALID_AMOUNT');
  });
});

// ─── 6. Amount — negative refund is rejected ──────────────────────────────────
describe('Amount — negative refund is rejected', () => {
  test('400 INVALID_AMOUNT for amount = -100', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();
    setupTxnInTransaction();
    setupAuditWrite();

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: -100, currency: 'INR' });

    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('INVALID_AMOUNT');
  });

  test('400 INVALID_AMOUNT for non-integer float amount', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();
    setupTxnInTransaction();
    setupAuditWrite();

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: 49.99, currency: 'INR' });

    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('INVALID_AMOUNT');
  });
});

// ─── 7. Amount — refund greater than transaction amount is rejected ────────────
describe('Amount — refund exceeding transaction amount is rejected', () => {
  test('422 OVER_REFUND when amount > original transaction amount', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();
    // baseTxn.amount = 5000; requesting 6000
    setupTxnInTransaction(baseTxn, []);
    setupAuditWrite();

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: 6000, currency: 'INR' });

    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe('OVER_REFUND');
    expect(res.body.error.details).toMatchObject({
      original: 5000,
      requested: 6000,
    });
  });
});

// ─── 8. Partial refund — multiple partial refunds are allowed ─────────────────
describe('Partial refund — multiple partials allowed within limit', () => {
  const makeSuccessRefund = (amount: number) => ({
    id: 'RFD-001', transaction_id: 'TXN-10001', amount,
    currency: 'INR', status: 'SUCCESS', reason: null,
    initiated_by: 'ADMIN-001', idempotency_key: 'k1',
    created_at: '', updated_at: '',
  });

  test('201 — first partial refund (₹2000 of ₹5000)', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();

    const refundRow = makeSuccessRefund(2000);
    mockWithTxn.mockImplementationOnce(async (fn: Function) => {
      const client = { query: jest.fn() };
      client.query
        .mockResolvedValueOnce({ rowCount: 1, rows: [baseTxn] })
        .mockResolvedValueOnce({ rowCount: 0, rows: [] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [{ ...refundRow, id: 'RFD-001' }] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [] });
      return fn(client);
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: 2000, currency: 'INR' });

    expect(res.status).toBe(201);
    expect(res.body.data.amount).toBe(2000);
  });

  test('201 — second partial refund bringing total to ₹5000 (exact limit)', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();

    // First refund of ₹2000 already exists
    const existing = [makeSuccessRefund(2000)];

    mockWithTxn.mockImplementationOnce(async (fn: Function) => {
      const client = { query: jest.fn() };
      client.query
        .mockResolvedValueOnce({ rowCount: 1, rows: [baseTxn] })
        .mockResolvedValueOnce({ rowCount: 1, rows: existing })
        // ₹2000 already refunded + ₹3000 new = ₹5000 = exactly original → allowed
        .mockResolvedValueOnce({ rowCount: 1, rows: [{ ...makeSuccessRefund(3000), id: 'RFD-002' }] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [] });
      return fn(client);
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: 3000, currency: 'INR' });

    expect(res.status).toBe(201);
    expect(res.body.data.amount).toBe(3000);
  });

  test('FAILED refunds do not count toward the cumulative total', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();

    // A previous attempt failed — should not reduce available amount
    const failedRefund = { ...makeSuccessRefund(5000), status: 'FAILED' };

    mockWithTxn.mockImplementationOnce(async (fn: Function) => {
      const client = { query: jest.fn() };
      client.query
        .mockResolvedValueOnce({ rowCount: 1, rows: [baseTxn] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [failedRefund] })
        // Full ₹5000 still available despite the failed attempt
        .mockResolvedValueOnce({ rowCount: 1, rows: [{ ...makeSuccessRefund(5000), id: 'RFD-002' }] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [] });
      return fn(client);
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: 5000, currency: 'INR' });

    expect(res.status).toBe(201);
  });
});

// ─── 9. Over-refund — total cannot exceed original amount ─────────────────────
describe('Over-refund — cumulative total cannot exceed original amount', () => {
  test('422 OVER_REFUND when existing refunds + new amount would exceed original', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();
    setupAuditWrite();

    // ₹3000 already refunded; requesting another ₹3000 (total would be ₹6000 > ₹5000)
    const alreadyRefunded = [{
      id: 'RFD-001', transaction_id: 'TXN-10001', amount: 3000,
      currency: 'INR', status: 'SUCCESS', reason: null,
      initiated_by: 'ADMIN-001', idempotency_key: 'k1',
      created_at: '', updated_at: '',
    }];

    setupTxnInTransaction(baseTxn, alreadyRefunded);

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: 3000, currency: 'INR' });

    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe('OVER_REFUND');
    expect(res.body.error.details).toMatchObject({
      original: 5000,
      already_refunded: 3000,
      requested: 3000,
    });
  });

  test('422 OVER_REFUND when transaction already fully refunded (1 paise requested)', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();
    setupAuditWrite();

    const fullyRefunded = [{
      id: 'RFD-001', transaction_id: 'TXN-10001', amount: 5000,
      currency: 'INR', status: 'SUCCESS', reason: null,
      initiated_by: 'ADMIN-001', idempotency_key: 'k1',
      created_at: '', updated_at: '',
    }];

    setupTxnInTransaction(baseTxn, fullyRefunded);

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: 1, currency: 'INR' });

    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe('OVER_REFUND');
  });
});
