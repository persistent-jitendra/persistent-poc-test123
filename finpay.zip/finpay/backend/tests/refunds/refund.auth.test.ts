// FinPay — Authentication & Authorization Tests
// Covers: unauthenticated access, missing permission, merchant scope violation

import request from 'supertest';
import { v4 as uuidv4 } from 'uuid';
import app from '../../src/app';

jest.mock('../../src/db', () => ({
  pool: { query: jest.fn(), connect: jest.fn() },
  withTransaction: jest.fn(),
}));
jest.mock('jsonwebtoken', () => ({ verify: jest.fn() }));

import { pool } from '../../src/db';
import jwt from 'jsonwebtoken';

const mockPool = pool as jest.Mocked<typeof pool>;
const mockJwt  = jwt  as jest.Mocked<typeof jwt>;

const VALID_KEY   = uuidv4();
const AUTH_HEADER = { Authorization: 'Bearer token' };
const BODY        = { amount: 5000, currency: 'INR' };

const adminUser = {
  id: 'ADMIN-001', email: 'admin@finpay.test', role: 'admin',
  permissions: ['refund:read', 'refund:create'],
  allowed_merchant_ids: ['MER-900'], is_active: true,
};

beforeEach(() => jest.clearAllMocks());

// ─── 1. Unauthenticated user cannot refund ────────────────────────────────────
describe('Authentication — unauthenticated user cannot refund', () => {
  test('403 when Authorization header is missing', async () => {
    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set('Idempotency-Key', VALID_KEY)
      .send(BODY);

    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('FORBIDDEN');
  });

  test('403 when Authorization header has no Bearer prefix', async () => {
    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set('Authorization', 'Basic dXNlcjpwYXNz')
      .set('Idempotency-Key', VALID_KEY)
      .send(BODY);

    expect(res.status).toBe(403);
  });

  test('403 when JWT signature is invalid', async () => {
    (mockJwt.verify as jest.Mock).mockImplementation(() => {
      throw new Error('invalid signature');
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', VALID_KEY)
      .send(BODY);

    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('FORBIDDEN');
  });

  test('403 when JWT belongs to an inactive user', async () => {
    (mockJwt.verify as jest.Mock).mockReturnValue({ ...adminUser, is_active: false });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', VALID_KEY)
      .send(BODY);

    expect(res.status).toBe(403);
  });

  test('403 when role is neither admin nor support', async () => {
    (mockJwt.verify as jest.Mock).mockReturnValue({
      ...adminUser, role: 'customer',
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', VALID_KEY)
      .send(BODY);

    expect(res.status).toBe(403);
  });
});

// ─── 2. Authorization — user without refund permission cannot refund ──────────
describe('Authorization — missing refund:create permission', () => {
  test('403 when user has only refund:read permission', async () => {
    (mockJwt.verify as jest.Mock).mockReturnValue({
      ...adminUser, permissions: ['refund:read'],
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', VALID_KEY)
      .send(BODY);

    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('FORBIDDEN');
    expect(res.body.error.message).toMatch(/refund:create/);
  });

  test('403 when user has no permissions at all', async () => {
    (mockJwt.verify as jest.Mock).mockReturnValue({
      ...adminUser, permissions: [],
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', VALID_KEY)
      .send(BODY);

    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('FORBIDDEN');
  });

  test('200 — GET refund list allowed with only refund:read', async () => {
    (mockJwt.verify as jest.Mock).mockReturnValue({
      ...adminUser, permissions: ['refund:read'],
    });

    // Merchant scope check
    (mockPool.query as jest.Mock).mockResolvedValueOnce({
      rowCount: 1, rows: [{ merchant_id: 'MER-900' }],
    });
    // Refund list query
    (mockPool.query as jest.Mock).mockResolvedValueOnce({ rowCount: 0, rows: [] });

    const res = await request(app)
      .get('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER);

    expect(res.status).toBe(200);
  });
});

// ─── 3. Merchant scope — Admin A cannot refund Merchant B's transaction ────────
describe('Merchant scope — cross-merchant access is blocked', () => {
  test('403 when transaction belongs to a merchant outside allowed_merchant_ids', async () => {
    // Admin is only allowed for MER-900
    (mockJwt.verify as jest.Mock).mockReturnValue({
      ...adminUser, allowed_merchant_ids: ['MER-900'],
    });

    // Transaction belongs to MER-111 (different merchant)
    (mockPool.query as jest.Mock).mockResolvedValueOnce({
      rowCount: 1, rows: [{ merchant_id: 'MER-111' }],
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-OTHER/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', VALID_KEY)
      .send(BODY);

    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('MERCHANT_SCOPE_VIOLATION');
  });

  test('403 when admin has empty allowed_merchant_ids list', async () => {
    (mockJwt.verify as jest.Mock).mockReturnValue({
      ...adminUser, allowed_merchant_ids: [],
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', VALID_KEY)
      .send(BODY);

    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('MERCHANT_SCOPE_VIOLATION');
  });

  test('201 when transaction belongs to an allowed merchant', async () => {
    const { withTransaction } = require('../../src/db');
    (mockJwt.verify as jest.Mock).mockReturnValue(adminUser);

    // Merchant scope check — MER-900 is allowed
    (mockPool.query as jest.Mock).mockResolvedValueOnce({
      rowCount: 1, rows: [{ merchant_id: 'MER-900' }],
    });
    // Idempotency — no existing key
    (mockPool.query as jest.Mock).mockResolvedValueOnce({ rowCount: 0, rows: [] });

    const createdRefund = {
      id: 'RFD-001', transaction_id: 'TXN-10001', amount: 5000,
      currency: 'INR', status: 'SUCCESS', reason: null,
      initiated_by: 'ADMIN-001', idempotency_key: VALID_KEY,
      created_at: new Date().toISOString(), updated_at: new Date().toISOString(),
    };

    withTransaction.mockImplementationOnce(async (fn: Function) => {
      const client = { query: jest.fn() };
      client.query
        .mockResolvedValueOnce({ rowCount: 1, rows: [{
          id: 'TXN-10001', user_id: 'USER-501', merchant_id: 'MER-900',
          amount: 5000, currency: 'INR', status: 'SUCCESS',
          payment_method: 'UPI', payment_ref: 'ab@okaxis',
          created_at: '', updated_at: '',
        }]})
        .mockResolvedValueOnce({ rowCount: 0, rows: [] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [createdRefund] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [] });
      return fn(client);
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH_HEADER)
      .set('Idempotency-Key', VALID_KEY)
      .send(BODY);

    expect(res.status).toBe(201);
    expect(res.body.data.id).toBe('RFD-001');
  });
});
