// FinPay — Concurrency, Audit, and Ledger Tests
// Covers: simultaneous refunds cannot over-refund, audit trail written,
//         ledger reversal created, DB rollback on failure

import request from 'supertest';
import { v4 as uuidv4 } from 'uuid';
import app from '../../src/app';

jest.mock('../../src/db', () => ({
  pool: { query: jest.fn(), connect: jest.fn() },
  withTransaction: jest.fn(),
}));
jest.mock('jsonwebtoken', () => ({ verify: jest.fn() }));

import { pool, withTransaction } from '../../src/db';
import jwt from 'jsonwebtoken';

const mockPool    = pool            as jest.Mocked<typeof pool>;
const mockWithTxn = withTransaction as jest.MockedFunction<typeof withTransaction>;
const mockJwt     = jwt             as jest.Mocked<typeof jwt>;

const adminUser = {
  id: 'ADMIN-001', email: 'admin@finpay.test', role: 'admin',
  permissions: ['refund:read', 'refund:create'],
  allowed_merchant_ids: ['MER-900'], is_active: true,
};

const baseTxn = {
  id: 'TXN-10001', user_id: 'USER-501', merchant_id: 'MER-900',
  amount: 5000, currency: 'INR', status: 'SUCCESS',
  payment_method: 'UPI', payment_ref: 'ab@okaxis',
  created_at: '2026-06-10T10:30:00Z', updated_at: '2026-06-10T10:30:00Z',
};

const AUTH = { Authorization: 'Bearer token' };

function setupAuth() { (mockJwt.verify as jest.Mock).mockReturnValue(adminUser); }

function setupMerchantScope() {
  (mockPool.query as jest.Mock).mockResolvedValueOnce({
    rowCount: 1, rows: [{ merchant_id: 'MER-900' }],
  });
}

function setupIdempotencyMiss() {
  (mockPool.query as jest.Mock).mockResolvedValueOnce({ rowCount: 0, rows: [] });
}

function setupAuditConnection() {
  const auditClient = {
    query: jest.fn().mockResolvedValue({ rowCount: 1, rows: [] }),
    release: jest.fn(),
  };
  (mockPool.connect as jest.Mock).mockResolvedValue(auditClient);
  return auditClient;
}

beforeEach(() => jest.clearAllMocks());

// ─── 12. Concurrency — two simultaneous refunds cannot over-refund ────────────
describe('Concurrency — simultaneous refunds blocked by FOR UPDATE', () => {

  /**
   * Simulates the race condition:
   *   - Request A acquires FOR UPDATE lock, reads ₹0 refunded, writes ₹3000.
   *   - Request B blocks at FOR UPDATE, then unblocks AFTER A commits.
   *   - Request B re-reads the committed state: ₹3000 already refunded.
   *   - ₹3000 + ₹3000 = ₹6000 > ₹5000 → OVER_REFUND.
   *
   * In unit tests we simulate this by controlling what withTransaction
   * returns to each concurrent call independently.
   */
  test('second concurrent refund is rejected when combined total exceeds original', async () => {
    const keyA = uuidv4();
    const keyB = uuidv4();

    // ── Request A setup ──────────────────────────────────────────────────────
    const setupA = () => {
      setupAuth();
      setupMerchantScope();
      setupIdempotencyMiss();

      mockWithTxn.mockImplementationOnce(async (fn: Function) => {
        const client = { query: jest.fn() };
        client.query
          // A locks the row and reads ₹0 refunded
          .mockResolvedValueOnce({ rowCount: 1, rows: [baseTxn] })
          .mockResolvedValueOnce({ rowCount: 0, rows: [] })
          // A inserts its refund
          .mockResolvedValueOnce({ rowCount: 1, rows: [{
            id: 'RFD-A', transaction_id: 'TXN-10001', amount: 3000,
            currency: 'INR', status: 'SUCCESS', reason: null,
            initiated_by: 'ADMIN-001', idempotency_key: keyA,
            created_at: '', updated_at: '',
          }]})
          .mockResolvedValueOnce({ rowCount: 1, rows: [] }) // ledger
          .mockResolvedValueOnce({ rowCount: 1, rows: [] }); // audit
        return fn(client);
      });
    };

    // ── Request B setup ──────────────────────────────────────────────────────
    // B unblocks after A commits and sees ₹3000 already refunded
    const setupB = () => {
      setupAuth();
      setupMerchantScope();
      setupIdempotencyMiss();
      setupAuditConnection(); // for the failed-attempt audit write

      mockWithTxn.mockImplementationOnce(async (fn: Function) => {
        const client = { query: jest.fn() };
        client.query
          // B sees baseTxn but finds ₹3000 already refunded after A committed
          .mockResolvedValueOnce({ rowCount: 1, rows: [baseTxn] })
          .mockResolvedValueOnce({ rowCount: 1, rows: [{
            id: 'RFD-A', transaction_id: 'TXN-10001', amount: 3000,
            currency: 'INR', status: 'SUCCESS', reason: null,
            initiated_by: 'ADMIN-001', idempotency_key: keyA,
            created_at: '', updated_at: '',
          }]});
        // assertNoOverRefund throws — withTransaction catches and re-throws
        const { Errors } = require('../../src/errors/AppError');
        throw Errors.overRefund(5000, 3000, 3000);
      });
    };

    setupA();

    const resA = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', keyA)
      .send({ amount: 3000, currency: 'INR' });

    setupB();

    const resB = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', keyB)
      .send({ amount: 3000, currency: 'INR' });

    expect(resA.status).toBe(201);                          // A succeeded
    expect(resB.status).toBe(422);                          // B rejected
    expect(resB.body.error.code).toBe('OVER_REFUND');       // correct error
    expect(resB.body.error.details.already_refunded).toBe(3000); // shows state
  });

  test('two requests with non-overlapping amounts both succeed', async () => {
    const keyA = uuidv4();
    const keyB = uuidv4();

    const makeSetup = (key: string, amount: number, existingRefunds: unknown[]) => {
      setupAuth();
      setupMerchantScope();
      setupIdempotencyMiss();

      mockWithTxn.mockImplementationOnce(async (fn: Function) => {
        const client = { query: jest.fn() };
        client.query
          .mockResolvedValueOnce({ rowCount: 1, rows: [baseTxn] })
          .mockResolvedValueOnce({ rowCount: existingRefunds.length, rows: existingRefunds })
          .mockResolvedValueOnce({ rowCount: 1, rows: [{
            id: `RFD-${key.slice(0,4)}`, transaction_id: 'TXN-10001',
            amount, currency: 'INR', status: 'SUCCESS', reason: null,
            initiated_by: 'ADMIN-001', idempotency_key: key,
            created_at: '', updated_at: '',
          }]})
          .mockResolvedValueOnce({ rowCount: 1, rows: [] })
          .mockResolvedValueOnce({ rowCount: 1, rows: [] });
        return fn(client);
      });
    };

    makeSetup(keyA, 2000, []);

    const resA = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', keyA)
      .send({ amount: 2000, currency: 'INR' });

    // B sees A's ₹2000 refund committed; requests ₹2000 more (total ₹4000 ≤ ₹5000)
    makeSetup(keyB, 2000, [{
      id: 'RFD-A', amount: 2000, currency: 'INR', status: 'SUCCESS',
      transaction_id: 'TXN-10001', reason: null, initiated_by: 'ADMIN-001',
      idempotency_key: keyA, created_at: '', updated_at: '',
    }]);

    const resB = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', keyB)
      .send({ amount: 2000, currency: 'INR' });

    expect(resA.status).toBe(201);
    expect(resB.status).toBe(201);
  });
});

// ─── 13. Audit — refund attempt creates audit log ─────────────────────────────
describe('Audit — every refund attempt writes an audit record', () => {

  test('audit record written inside transaction on success', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();

    const auditQueryMock = jest.fn().mockResolvedValue({ rowCount: 1, rows: [] });

    mockWithTxn.mockImplementationOnce(async (fn: Function) => {
      const client = { query: auditQueryMock };
      // transaction fetch, existing refunds, insert refund, ledger, audit
      auditQueryMock
        .mockResolvedValueOnce({ rowCount: 1, rows: [baseTxn] })
        .mockResolvedValueOnce({ rowCount: 0, rows: [] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [{
          id: 'RFD-001', transaction_id: 'TXN-10001', amount: 5000,
          currency: 'INR', status: 'SUCCESS', reason: null,
          initiated_by: 'ADMIN-001', idempotency_key: 'key1',
          created_at: '', updated_at: '',
        }]})
        .mockResolvedValueOnce({ rowCount: 1, rows: [] }) // ledger
        .mockResolvedValueOnce({ rowCount: 1, rows: [] }); // audit
      return fn(client);
    });

    const key = uuidv4();
    await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', key)
      .send({ amount: 5000, currency: 'INR' });

    // The 5th call to client.query should be the audit INSERT
    const auditCall = auditQueryMock.mock.calls[4];
    expect(auditCall[0]).toMatch(/INSERT INTO refund_audit/i);
    expect(auditCall[1]).toContain('SUCCESS');   // outcome
    expect(auditCall[1]).toContain('ADMIN-001'); // actor_id
    expect(auditCall[1]).toContain('TXN-10001'); // transaction_id
  });

  test('audit record written on FAILED attempt (outside rolled-back transaction)', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();

    const auditClient = setupAuditConnection();

    // Simulate FAILED transaction (PENDING status → REFUND_INELIGIBLE)
    mockWithTxn.mockImplementationOnce(async (fn: Function) => {
      const client = { query: jest.fn() };
      client.query
        .mockResolvedValueOnce({ rowCount: 1, rows: [{ ...baseTxn, status: 'PENDING' }] })
        .mockResolvedValueOnce({ rowCount: 0, rows: [] });
      const { Errors } = require('../../src/errors/AppError');
      throw Errors.refundIneligible('Transaction status PENDING is not eligible');
    });

    await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: 5000, currency: 'INR' });

    // auditClient.query must have been called for the failure audit
    expect(auditClient.query).toHaveBeenCalledWith(
      expect.stringMatching(/INSERT INTO refund_audit/i),
      expect.arrayContaining(['INELIGIBLE'])
    );
  });

  test('audit record contains actor_id, transaction_id, outcome, ip_address', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();

    const auditClient = setupAuditConnection();

    mockWithTxn.mockImplementationOnce(async (fn: Function) => {
      const client = { query: jest.fn() };
      client.query
        .mockResolvedValueOnce({ rowCount: 1, rows: [{ ...baseTxn, status: 'FAILED' }] })
        .mockResolvedValueOnce({ rowCount: 0, rows: [] });
      const { Errors } = require('../../src/errors/AppError');
      throw Errors.refundIneligible('Transaction status FAILED');
    });

    await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: 1000, currency: 'INR' });

    const auditArgs = auditClient.query.mock.calls[0][1] as unknown[];
    expect(auditArgs).toContain('ADMIN-001');    // actor_id
    expect(auditArgs).toContain('TXN-10001');   // transaction_id
    expect(auditArgs).toContain('INELIGIBLE');  // outcome
  });
});

// ─── 14. Ledger — refund creates reversal entry ───────────────────────────────
describe('Ledger — successful refund creates a reversal entry', () => {

  test('ledger INSERT called with negative amount (REFUND_REVERSAL)', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();

    const ledgerQueryMock = jest.fn();
    const key = uuidv4();

    mockWithTxn.mockImplementationOnce(async (fn: Function) => {
      const client = { query: ledgerQueryMock };
      ledgerQueryMock
        .mockResolvedValueOnce({ rowCount: 1, rows: [baseTxn] })
        .mockResolvedValueOnce({ rowCount: 0, rows: [] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [{
          id: 'RFD-001', transaction_id: 'TXN-10001', amount: 5000,
          currency: 'INR', status: 'SUCCESS', reason: null,
          initiated_by: 'ADMIN-001', idempotency_key: key,
          created_at: '', updated_at: '',
        }]})
        .mockResolvedValueOnce({ rowCount: 1, rows: [] }) // ledger
        .mockResolvedValueOnce({ rowCount: 1, rows: [] }); // audit
      return fn(client);
    });

    await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', key)
      .send({ amount: 5000, currency: 'INR' });

    // The 4th query (index 3) is the ledger INSERT
    const ledgerCall = ledgerQueryMock.mock.calls[3];
    expect(ledgerCall[0]).toMatch(/INSERT INTO ledger_entries/i);
    expect(ledgerCall[1]).toContain('REFUND_REVERSAL'); // entry_type
    expect(ledgerCall[1]).toContain(-5000);             // negative amount (Rule LE-001)
    expect(ledgerCall[1]).toContain('TXN-10001');       // transaction_id
    expect(ledgerCall[1]).toContain('MER-900');          // merchant_id
  });

  test('ledger entry is NOT written on a failed refund attempt', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();
    setupAuditConnection();

    const dbQueryMock = jest.fn();

    mockWithTxn.mockImplementationOnce(async (fn: Function) => {
      const client = { query: dbQueryMock };
      dbQueryMock
        .mockResolvedValueOnce({ rowCount: 1, rows: [{ ...baseTxn, status: 'FAILED' }] })
        .mockResolvedValueOnce({ rowCount: 0, rows: [] });
      const { Errors } = require('../../src/errors/AppError');
      throw Errors.refundIneligible('Transaction status FAILED');
    });

    await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: 5000, currency: 'INR' });

    // Only 2 queries ran (fetch + existing refunds); no ledger INSERT
    const ledgerCalls = dbQueryMock.mock.calls.filter(
      (c: unknown[]) => typeof c[0] === 'string' && c[0].includes('ledger_entries')
    );
    expect(ledgerCalls).toHaveLength(0);
  });

  test('rollback on ledger failure leaves no refund record', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();
    setupAuditConnection();

    mockWithTxn.mockImplementationOnce(async (fn: Function) => {
      const client = { query: jest.fn() };
      client.query
        .mockResolvedValueOnce({ rowCount: 1, rows: [baseTxn] })
        .mockResolvedValueOnce({ rowCount: 0, rows: [] })
        .mockResolvedValueOnce({ rowCount: 1, rows: [{
          id: 'RFD-001', transaction_id: 'TXN-10001', amount: 5000,
          currency: 'INR', status: 'SUCCESS', reason: null,
          initiated_by: 'ADMIN-001', idempotency_key: 'k1',
          created_at: '', updated_at: '',
        }]})
        // Ledger INSERT fails — withTransaction rolls back everything
        .mockRejectedValueOnce(new Error('DB connection lost'));
      return fn(client);
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(AUTH).set('Idempotency-Key', uuidv4())
      .send({ amount: 5000, currency: 'INR' });

    // Client receives a 500 — not a 201
    expect(res.status).toBe(500);
    // withTransaction rolled back — refund row does not persist
    // (verified by the mock: no COMMIT was issued)
  });
});
