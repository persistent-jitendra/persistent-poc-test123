// FinPay — Integration Tests: Refund Controller
// Tests the full request → middleware → controller → service stack.
// DB calls are mocked so tests are fast and isolated from PostgreSQL.

import request from 'supertest';
import { v4 as uuidv4 } from 'uuid';
import app from '../../src/app';

// ─── Mocks ────────────────────────────────────────────────────────────────────

// Mock the DB pool so no real PostgreSQL connection is needed
jest.mock('../../src/db', () => ({
  pool: {
    query: jest.fn(),
    connect: jest.fn(),
  },
  withTransaction: jest.fn(),
}));

// Mock JWT verification — we control what the "decoded" user looks like
jest.mock('jsonwebtoken', () => ({
  verify: jest.fn(),
}));

import { pool, withTransaction } from '../../src/db';
import jwt from 'jsonwebtoken';

const mockPool    = pool as jest.Mocked<typeof pool>;
const mockWithTxn = withTransaction as jest.MockedFunction<typeof withTransaction>;
const mockJwt     = jwt as jest.Mocked<typeof jwt>;

// ─── Shared test data ─────────────────────────────────────────────────────────

const adminUser = {
  id: 'ADMIN-001',
  email: 'admin@finpay.test',
  role: 'admin',
  permissions: ['refund:read', 'refund:create'],
  allowed_merchant_ids: ['MER-900'],
  is_active: true,
};

const successTxn = {
  id: 'TXN-10001',
  user_id: 'USER-501',
  merchant_id: 'MER-900',
  amount: 5000,
  currency: 'INR',
  status: 'SUCCESS',
  payment_method: 'UPI',
  payment_ref: 'abcdef@okaxis',
  created_at: '2026-06-10T10:30:00Z',
  updated_at: '2026-06-10T10:30:00Z',
};

const validIdempotencyKey = uuidv4();
const authHeader = { Authorization: 'Bearer valid.token.here' };

function setupAuth(user = adminUser) {
  (mockJwt.verify as jest.Mock).mockReturnValue(user);
}

function setupMerchantScope(merchantId = 'MER-900') {
  // First pool.query call in requireMerchantScope — returns merchant_id
  (mockPool.query as jest.Mock).mockResolvedValueOnce({
    rowCount: 1,
    rows: [{ merchant_id: merchantId }],
  });
}

function setupIdempotencyMiss() {
  // pool.query for idempotency check — no existing key
  (mockPool.query as jest.Mock).mockResolvedValueOnce({ rowCount: 0, rows: [] });
}

function setupTransactionFetch(txn = successTxn) {
  (mockPool.query as jest.Mock).mockResolvedValueOnce({ rowCount: 1, rows: [txn] });
}

function setupExistingRefunds(refunds: unknown[] = []) {
  (mockPool.query as jest.Mock).mockResolvedValueOnce({ rowCount: refunds.length, rows: refunds });
}

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/v1/transactions/:transactionId/refunds
// ─────────────────────────────────────────────────────────────────────────────

describe('POST /api/v1/transactions/:transactionId/refunds', () => {

  beforeEach(() => jest.clearAllMocks());

  // ── Happy path: full refund ────────────────────────────────────────────────

  test('201 — full refund on SUCCESS transaction', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();

    const createdRefund = {
      id: 'RFD-ABC123',
      transaction_id: 'TXN-10001',
      amount: 5000,
      currency: 'INR',
      status: 'SUCCESS',
      reason: null,
      initiated_by: 'ADMIN-001',
      idempotency_key: validIdempotencyKey,
      created_at: '2026-06-10T11:00:00Z',
      updated_at: '2026-06-10T11:00:00Z',
    };

    mockWithTxn.mockImplementationOnce(async (fn) => {
      const fakeClient = { query: jest.fn() };
      // transaction fetch
      fakeClient.query.mockResolvedValueOnce({ rowCount: 1, rows: [successTxn] });
      // existing refunds
      fakeClient.query.mockResolvedValueOnce({ rowCount: 0, rows: [] });
      // insert refund
      fakeClient.query.mockResolvedValueOnce({ rowCount: 1, rows: [createdRefund] });
      // ledger insert
      fakeClient.query.mockResolvedValueOnce({ rowCount: 1, rows: [] });
      // audit insert
      fakeClient.query.mockResolvedValueOnce({ rowCount: 1, rows: [] });
      return fn(fakeClient as never);
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(authHeader)
      .set('Idempotency-Key', validIdempotencyKey)
      .send({ amount: 5000, currency: 'INR' });

    expect(res.status).toBe(201);
    expect(res.body.data.id).toBe('RFD-ABC123');
    expect(res.body.data.amount).toBe(5000);
    expect(res.body.data.status).toBe('SUCCESS');
  });

  // ── Happy path: partial refund ─────────────────────────────────────────────

  test('201 — partial refund is accepted', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();

    const partialRefund = { ...successTxn, amount: 2000, id: 'RFD-PART01' };

    mockWithTxn.mockImplementationOnce(async (fn) => {
      const fakeClient = { query: jest.fn() };
      fakeClient.query.mockResolvedValueOnce({ rowCount: 1, rows: [successTxn] });
      fakeClient.query.mockResolvedValueOnce({ rowCount: 0, rows: [] });
      fakeClient.query.mockResolvedValueOnce({ rowCount: 1, rows: [partialRefund] });
      fakeClient.query.mockResolvedValueOnce({ rowCount: 1, rows: [] });
      fakeClient.query.mockResolvedValueOnce({ rowCount: 1, rows: [] });
      return fn(fakeClient as never);
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(authHeader)
      .set('Idempotency-Key', validIdempotencyKey)
      .send({ amount: 2000, currency: 'INR', reason: 'Partial refund test' });

    expect(res.status).toBe(201);
    expect(res.body.data.amount).toBe(2000);
  });

  // ── Idempotency: duplicate request same payload → 200 ─────────────────────

  test('200 — duplicate idempotency key with same payload returns original response', async () => {
    setupAuth();
    setupMerchantScope();

    const storedResponse = {
      data: { id: 'RFD-STORED', amount: 5000, currency: 'INR', status: 'SUCCESS' },
    };

    // Idempotency check returns an existing record
    (mockPool.query as jest.Mock).mockResolvedValueOnce({
      rowCount: 1,
      rows: [{
        key: validIdempotencyKey,
        payload_hash: expect.any(String),
        response_status: 201,
        response_body: storedResponse,
        expires_at: new Date(Date.now() + 86400000).toISOString(),
      }],
    });

    // We need to simulate same payload hash — mock the crypto hash to match stored
    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(authHeader)
      .set('Idempotency-Key', validIdempotencyKey)
      .send({ amount: 5000, currency: 'INR' });

    // Returns stored response (may be 200 or 201 depending on stored status)
    expect([200, 201]).toContain(res.status);
  });

  // ── Idempotency conflict: same key, different payload → 409 ───────────────

  test('409 — idempotency key reused with different payload', async () => {
    setupAuth();
    setupMerchantScope();

    // Return a stored record with a DIFFERENT payload hash
    (mockPool.query as jest.Mock).mockResolvedValueOnce({
      rowCount: 1,
      rows: [{
        key: validIdempotencyKey,
        payload_hash: 'completelydifferenthash',
        response_status: 201,
        response_body: {},
        expires_at: new Date(Date.now() + 86400000).toISOString(),
      }],
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(authHeader)
      .set('Idempotency-Key', validIdempotencyKey)
      .send({ amount: 1000, currency: 'INR' });

    expect(res.status).toBe(409);
    expect(res.body.error.code).toBe('IDEMPOTENCY_CONFLICT');
  });

  // ── Missing Idempotency-Key → 400 ─────────────────────────────────────────

  test('400 — missing Idempotency-Key header', async () => {
    setupAuth();
    setupMerchantScope();

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(authHeader)
      // deliberately no Idempotency-Key header
      .send({ amount: 5000, currency: 'INR' });

    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('MISSING_IDEMPOTENCY_KEY');
  });

  // ── Non-SUCCESS transaction → 422 ─────────────────────────────────────────

  test('422 — refund on FAILED transaction is rejected', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();

    const failedTxn = { ...successTxn, status: 'FAILED' };

    mockWithTxn.mockImplementationOnce(async (fn) => {
      const fakeClient = { query: jest.fn() };
      fakeClient.query.mockResolvedValueOnce({ rowCount: 1, rows: [failedTxn] });
      fakeClient.query.mockResolvedValueOnce({ rowCount: 0, rows: [] });
      return fn(fakeClient as never);
    });

    // audit write on failure
    (mockPool.connect as jest.Mock).mockResolvedValueOnce({
      query: jest.fn().mockResolvedValue({}),
      release: jest.fn(),
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(authHeader)
      .set('Idempotency-Key', validIdempotencyKey)
      .send({ amount: 5000, currency: 'INR' });

    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe('REFUND_INELIGIBLE');
  });

  // ── Over-refund → 422 ─────────────────────────────────────────────────────

  test('422 — refund amount exceeds remaining refundable amount', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();

    const alreadyRefunded = [
      { id: 'RFD-001', amount: 5000, currency: 'INR', status: 'SUCCESS',
        transaction_id: 'TXN-10001', reason: null, initiated_by: 'ADMIN-001',
        idempotency_key: 'old-key', created_at: '', updated_at: '' },
    ];

    mockWithTxn.mockImplementationOnce(async (fn) => {
      const fakeClient = { query: jest.fn() };
      fakeClient.query.mockResolvedValueOnce({ rowCount: 1, rows: [successTxn] });
      fakeClient.query.mockResolvedValueOnce({ rowCount: 1, rows: alreadyRefunded });
      return fn(fakeClient as never);
    });

    (mockPool.connect as jest.Mock).mockResolvedValueOnce({
      query: jest.fn().mockResolvedValue({}),
      release: jest.fn(),
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(authHeader)
      .set('Idempotency-Key', uuidv4())
      .send({ amount: 1, currency: 'INR' });

    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe('OVER_REFUND');
  });

  // ── Unauthorized role → 403 ───────────────────────────────────────────────

  test('403 — user without refund:create permission is rejected', async () => {
    setupAuth({ ...adminUser, permissions: ['refund:read'] });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(authHeader)
      .set('Idempotency-Key', validIdempotencyKey)
      .send({ amount: 5000, currency: 'INR' });

    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('FORBIDDEN');
  });

  // ── Out-of-scope merchant → 403 ───────────────────────────────────────────

  test('403 — admin accessing transaction outside their merchant scope', async () => {
    setupAuth({ ...adminUser, allowed_merchant_ids: ['MER-111'] });

    // Merchant scope check — transaction belongs to MER-900, not MER-111
    (mockPool.query as jest.Mock).mockResolvedValueOnce({
      rowCount: 1,
      rows: [{ merchant_id: 'MER-900' }],
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(authHeader)
      .set('Idempotency-Key', validIdempotencyKey)
      .send({ amount: 5000, currency: 'INR' });

    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('MERCHANT_SCOPE_VIOLATION');
  });

  // ── Transaction not found → 404 ───────────────────────────────────────────

  test('404 — transaction does not exist', async () => {
    setupAuth();
    // Merchant scope — not found, passes through
    (mockPool.query as jest.Mock).mockResolvedValueOnce({ rowCount: 0, rows: [] });
    setupIdempotencyMiss();

    mockWithTxn.mockImplementationOnce(async (fn) => {
      const fakeClient = { query: jest.fn() };
      fakeClient.query.mockResolvedValueOnce({ rowCount: 0, rows: [] });
      return fn(fakeClient as never);
    });

    (mockPool.connect as jest.Mock).mockResolvedValueOnce({
      query: jest.fn().mockResolvedValue({}),
      release: jest.fn(),
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-NONEXISTENT/refunds')
      .set(authHeader)
      .set('Idempotency-Key', uuidv4())
      .send({ amount: 1000, currency: 'INR' });

    expect(res.status).toBe(404);
    expect(res.body.error.code).toBe('TRANSACTION_NOT_FOUND');
  });

  // ── Unsupported currency → 422 ────────────────────────────────────────────

  test('422 — unsupported currency is rejected', async () => {
    setupAuth();
    setupMerchantScope();
    setupIdempotencyMiss();

    mockWithTxn.mockImplementationOnce(async (fn) => {
      const fakeClient = { query: jest.fn() };
      fakeClient.query.mockResolvedValueOnce({ rowCount: 1, rows: [successTxn] });
      fakeClient.query.mockResolvedValueOnce({ rowCount: 0, rows: [] });
      return fn(fakeClient as never);
    });

    (mockPool.connect as jest.Mock).mockResolvedValueOnce({
      query: jest.fn().mockResolvedValue({}),
      release: jest.fn(),
    });

    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set(authHeader)
      .set('Idempotency-Key', uuidv4())
      .send({ amount: 1000, currency: 'USD' });

    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe('UNSUPPORTED_CURRENCY');
  });

  // ── No auth token → 403 ───────────────────────────────────────────────────

  test('403 — request with no Authorization header is rejected', async () => {
    const res = await request(app)
      .post('/api/v1/transactions/TXN-10001/refunds')
      .set('Idempotency-Key', validIdempotencyKey)
      .send({ amount: 5000, currency: 'INR' });

    expect(res.status).toBe(403);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/v1/transactions/:transactionId/refunds
// ─────────────────────────────────────────────────────────────────────────────

describe('GET /api/v1/transactions/:transactionId/refunds', () => {
  beforeEach(() => jest.clearAllMocks());

  test('200 — returns refund list in reverse chronological order', async () => {
    setupAuth();
    setupMerchantScope();

    const refunds = [
      { id: 'RFD-002', transaction_id: 'TXN-10001', amount: 2000, currency: 'INR',
        status: 'SUCCESS', reason: null, initiated_by: 'ADMIN-001',
        idempotency_key: 'k2', created_at: '2026-06-10T12:00:00Z', updated_at: '' },
      { id: 'RFD-001', transaction_id: 'TXN-10001', amount: 1000, currency: 'INR',
        status: 'SUCCESS', reason: null, initiated_by: 'ADMIN-001',
        idempotency_key: 'k1', created_at: '2026-06-10T11:00:00Z', updated_at: '' },
    ];

    (mockPool.query as jest.Mock).mockResolvedValueOnce({ rowCount: 2, rows: refunds });

    const res = await request(app)
      .get('/api/v1/transactions/TXN-10001/refunds')
      .set(authHeader);

    expect(res.status).toBe(200);
    expect(res.body.data).toHaveLength(2);
    // Most recent first (Rule FE-005)
    expect(res.body.data[0].id).toBe('RFD-002');
    expect(res.body.data[1].id).toBe('RFD-001');
  });
});
