// FinPay — Unit Tests: masking.ts
// Verifies every masking rule from docs/business-rules.md (DP-001..DP-004).

import {
  maskUpiVpa,
  maskCardNumber,
  maskBankAccount,
  maskPaymentRef,
  maskTransaction,
  stripSensitiveFields,
} from '../../src/utils/masking';
import { Transaction } from '../../src/types';

const baseTxn: Transaction = {
  id: 'TXN-10001',
  user_id: 'USER-501',
  merchant_id: 'MER-900',
  amount: 5000,
  currency: 'INR',
  status: 'SUCCESS',
  payment_method: 'UPI',
  payment_ref: 'abcdef@okaxis',
  created_at: '2026-06-10T10:30:00Z',
  updated_at: '2026-06-10T10:30:00Z',
};

// ─── DP-001: UPI VPA masking ──────────────────────────────────────────────────

describe('maskUpiVpa', () => {
  test('masks local part, preserves domain', () => {
    expect(maskUpiVpa('abcdef@okaxis')).toBe('ab****@okaxis');
  });

  test('works for short local part', () => {
    expect(maskUpiVpa('ab@paytm')).toBe('ab****@paytm');
  });

  test('returns **** for VPA with no @ symbol', () => {
    expect(maskUpiVpa('invalidvpa')).toBe('****');
  });
});

// ─── DP-003: Card number masking ─────────────────────────────────────────────

describe('maskCardNumber', () => {
  test('shows only last 4 digits', () => {
    expect(maskCardNumber('4111111111111111')).toBe('****1111');
  });

  test('handles card with spaces', () => {
    expect(maskCardNumber('4111 1111 1111 1111')).toBe('****1111');
  });

  test('returns **** for very short input', () => {
    expect(maskCardNumber('123')).toBe('****');
  });
});

// ─── DP-002: Bank account masking ────────────────────────────────────────────

describe('maskBankAccount', () => {
  test('shows only last 4 digits', () => {
    expect(maskBankAccount('123456789012')).toBe('****9012');
  });

  test('returns **** for short account numbers', () => {
    expect(maskBankAccount('123')).toBe('****');
  });
});

// ─── maskPaymentRef: routes to correct masker by payment method ───────────────

describe('maskPaymentRef', () => {
  test('routes UPI through maskUpiVpa', () => {
    expect(maskPaymentRef('abcdef@okaxis', 'UPI')).toBe('ab****@okaxis');
  });

  test('routes CARD through maskCardNumber', () => {
    expect(maskPaymentRef('4111111111111111', 'CARD')).toBe('****1111');
  });

  test('routes NETBANKING through maskBankAccount', () => {
    expect(maskPaymentRef('123456789012', 'NETBANKING')).toBe('****9012');
  });

  test('returns null for null payment_ref', () => {
    expect(maskPaymentRef(null, 'UPI')).toBeNull();
  });

  test('returns **** for unknown payment method', () => {
    expect(maskPaymentRef('some-ref', 'UNKNOWN')).toBe('****');
  });
});

// ─── maskTransaction: full response shape ─────────────────────────────────────

describe('maskTransaction', () => {
  test('masks payment_ref and computes is_refundable correctly', () => {
    const result = maskTransaction(baseTxn, 0);
    expect(result.payment_ref_masked).toBe('ab****@okaxis');
    expect(result.is_refundable).toBe(true);
    expect(result.total_refunded).toBe(0);
    expect(result.remaining_refundable_amount).toBe(5000);
  });

  test('is_refundable is false when fully refunded', () => {
    const result = maskTransaction(baseTxn, 5000);
    expect(result.is_refundable).toBe(false);
    expect(result.remaining_refundable_amount).toBe(0);
  });

  test('is_refundable is false for non-SUCCESS transaction', () => {
    const txn = { ...baseTxn, status: 'FAILED' as const };
    const result = maskTransaction(txn, 0);
    expect(result.is_refundable).toBe(false);
  });

  test('remaining_refundable_amount never goes below 0', () => {
    // Defensive: even if somehow over-refunded in DB, remaining is clamped to 0
    const result = maskTransaction(baseTxn, 9999);
    expect(result.remaining_refundable_amount).toBe(0);
  });

  test('raw payment_ref is not present in the response', () => {
    const result = maskTransaction(baseTxn, 0);
    expect(result).not.toHaveProperty('payment_ref');
  });
});

// ─── stripSensitiveFields: log safety ────────────────────────────────────────

describe('stripSensitiveFields', () => {
  test('redacts known sensitive keys', () => {
    const input = {
      transaction_id: 'TXN-10001',
      payment_ref: 'abcdef@okaxis',
      token: 'eyJhbGciOi...',
      amount: 5000,
    };
    const result = stripSensitiveFields(input);
    expect(result.transaction_id).toBe('TXN-10001');
    expect(result.payment_ref).toBe('[REDACTED]');
    expect(result.token).toBe('[REDACTED]');
    expect(result.amount).toBe(5000);
  });

  test('recursively redacts nested sensitive fields', () => {
    const input = {
      user: {
        id: 'USER-501',
        password: 'hunter2',
      },
    };
    const result = stripSensitiveFields(input) as { user: Record<string, unknown> };
    expect(result.user.id).toBe('USER-501');
    expect(result.user.password).toBe('[REDACTED]');
  });
});
