import type { Config } from 'jest';

const config: Config = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  rootDir: '.',
  testMatch: ['**/tests/**/*.test.ts'],
  collectCoverageFrom: [
    'src/**/*.ts',
    '!src/server.ts',   // entry point — no logic to test
  ],
  coverageThreshold: {
    global: {
      branches:  80,
      functions: 80,
      lines:     80,
      statements: 80,
    },
  },
};

export default config;
