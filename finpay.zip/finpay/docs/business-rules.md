# Business Rules — FinPay Admin Refund Module
## Source of Truth — Do Not Override Without Product Sign-Off

All business logic in `src/refunds/` must trace back to a rule in this document.
If a rule is not here, it must not be implemented. If a rule here is ambiguous,
raise it with the product owner before writing code.

---

## 1. Refund Eligibility

| Rule ID | Rule | Enforcement |
|---|---|---|
| RE-001 | Only transactions with status `SUCCESS` can be refunded | Backend — checked before any refund is created |
| RE-002 | Only currency `INR` is supported for refunds | Backend — checked at API layer |
| RE-003 | A transaction that has already been fully refunded cannot be refunded again | Backend — over-refund guard |
| RE-004 | Transactions in status `PENDING`, `FAILED`, or `REVERSED` are not eligible | Backend — status check |

---

## 2. Refund Amount Rules

| Rule ID | Rule | Enforcement |
|---|---|---|
| RA-001 | Refund amount must be greater than 0 | Backend — input validation |
| RA-002 | Refund amount cannot exceed the original transaction amount | Backend — amount check |
| RA-003 | Multiple partial refunds are allowed on a single transaction | Backend — cumulative check |
| RA-004 | The total of all refunds on a transaction cannot exceed the original transaction amount | Backend — over-refund guard |
| RA-005 | Refund amount is expressed in the smallest currency unit (paise for INR) | Backend + Frontend |

---

## 3. Idempotency Rules

| Rule ID | Rule | Enforcement |
|---|---|---|
| ID-001 | Every refund creation request must include an `Idempotency-Key` header | Backend — middleware rejects requests without it |
| ID-002 | The `Idempotency-Key` must be a UUID v4 | Backend — format validation |
| ID-003 | If the same key is received with the same payload, return the original stored response with HTTP 200 | Backend — idempotency store lookup |
| ID-004 | If the same key is received with a different payload, return HTTP 409 Conflict | Backend — payload hash comparison |
| ID-005 | Idempotency keys expire after 24 hours | Backend — TTL on idempotency_keys table |

---

## 4. Authorization Rules

| Rule ID | Rule | Enforcement |
|---|---|---|
| AZ-001 | Only users with role `admin` or `support` may access refund endpoints | Backend — JWT role check |
| AZ-002 | Only users with the permission `refund:create` may initiate a refund | Backend — permission middleware |
| AZ-003 | Only users with the permission `refund:read` may view refund details and history | Backend — permission middleware |
| AZ-004 | An admin user may only access transactions belonging to merchants in their `allowed_merchant_ids` list | Backend — merchant scope middleware |
| AZ-005 | A support user may view but not modify transactions outside their scope | Backend — scope check per operation |

---

## 5. Audit Rules

| Rule ID | Rule | Enforcement |
|---|---|---|
| AU-001 | Every refund attempt must create an audit record, regardless of success or failure | Backend — audit logger called in all code paths |
| AU-002 | The audit record must contain: actor_id, transaction_id, refund_id (if created), amount, currency, outcome, failure_reason (if failed), ip_address, created_at | Backend — auditLogger.record() |
| AU-003 | Audit records are immutable — they must never be updated or deleted | Database — no UPDATE/DELETE on refund_audit |
| AU-004 | Audit records must be written within the same database transaction as the refund | Backend — audit write inside trx |

---

## 6. Ledger Rules

| Rule ID | Rule | Enforcement |
|---|---|---|
| LE-001 | A successful refund must create a reversal entry in the `ledger_entries` table | Backend — ledgerService.createReversal() |
| LE-002 | The ledger entry must reference the original transaction ID and the new refund ID | Backend — ledger payload |
| LE-003 | The ledger entry type must be `REFUND_REVERSAL` | Backend — constant from refund.constants.ts |
| LE-004 | Ledger entries are immutable — they must never be updated or deleted | Database — no UPDATE/DELETE on ledger_entries |
| LE-005 | The ledger entry must be written in the same DB transaction as the refund record | Backend — inside trx |

---

## 6. Data Privacy Rules

| Rule ID | Rule | Enforcement |
|---|---|---|
| DP-001 | UPI VPA must be masked in all API responses: show first 2 chars and domain only (e.g., `ab****@okaxis`) | Backend — maskSensitiveData() |
| DP-002 | Bank account numbers must be masked: show last 4 digits only (e.g., `****1234`) | Backend — maskSensitiveData() |
| DP-003 | Card numbers must be masked: show last 4 digits only (e.g., `****5678`) | Backend — maskSensitiveData() |
| DP-004 | User phone numbers must not appear in refund API responses | Backend — excluded from response shape |
| DP-005 | Sensitive fields must not appear in logs | Backend — logger strips sensitive keys |

---

## 7. Frontend Rules

| Rule ID | Rule | Enforcement |
|---|---|---|
| FE-001 | The refund button must be disabled when the API returns `is_refundable: false` | Frontend — button disabled prop |
| FE-002 | Refund eligibility must be computed by the backend, not the frontend | Backend is authoritative |
| FE-003 | The frontend must display the masked payment method, not the raw value | Frontend — render API response as-is |
| FE-004 | Partial refund input must not allow values greater than `remaining_refundable_amount` | Frontend UX only — backend still validates |
| FE-005 | Refund history must be displayed in reverse chronological order | Frontend — sort by created_at DESC |

---

## 8. Transaction Status Reference

| Status | Refundable | Notes |
|---|---|---|
| `SUCCESS` | ✅ Yes | Only eligible status |
| `PENDING` | ❌ No | Payment not yet settled |
| `FAILED` | ❌ No | Payment never completed |
| `REVERSED` | ❌ No | Already reversed at payment level |

---

## Change Log

| Date | Changed By | Rule ID | Change |
|---|---|---|---|
| 2026-06-10 | Product Owner | All | Initial rules definition |
