# Test Plan — FinPay Admin Refund Module
## All 18 Required Test Cases

---

## Test Strategy

| Layer | Tool | Location |
|---|---|---|
| Backend unit | Jest + ts-jest | `backend/tests/refunds/refund.rules.test.ts` |
| Backend integration | Jest + Supertest | `backend/tests/refunds/refund.auth.test.ts` |
| Backend integration | Jest + Supertest | `backend/tests/refunds/refund.business.test.ts` |
| Backend integration | Jest + Supertest | `backend/tests/refunds/refund.idempotency.test.ts` |
| Backend integration | Jest + Supertest | `backend/tests/refunds/refund.concurrency.test.ts` |
| Masking unit | Jest | `backend/tests/utils/masking.test.ts` |
| Frontend component | React Testing Library | `frontend/src/tests/TransactionDetail.test.tsx` |

**Run all backend tests:**
```bash
cd backend && npm test
```

**Run all frontend tests:**
```bash
cd frontend && npm test
```

**Run with coverage:**
```bash
cd backend && npm run test:coverage
```

---

## Test Case 1 — Unauthenticated User Cannot Refund

**Area:** Authentication
**Rule:** AZ-001
**File:** `backend/tests/refunds/refund.auth.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 1a | No Authorization header | `POST /refunds` (no header) | `403 FORBIDDEN` |
| 1b | Wrong auth scheme | `Authorization: Basic ...` | `403 FORBIDDEN` |
| 1c | Invalid JWT signature | Tampered token | `403 FORBIDDEN` |
| 1d | Inactive user account | Valid JWT, `is_active: false` | `403 FORBIDDEN` |
| 1e | Wrong role | Valid JWT, `role: 'customer'` | `403 FORBIDDEN` |

**Verification:** Stack trace must never appear in the 403 response body.

---

## Test Case 2 — User Without Refund Permission Cannot Refund

**Area:** Authorization
**Rule:** AZ-002
**File:** `backend/tests/refunds/refund.auth.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 2a | Has `refund:read` only | POST with valid JWT | `403 FORBIDDEN` |
| 2b | Empty permissions array | POST with valid JWT | `403 FORBIDDEN` |
| 2c | Has `refund:create` | POST with valid JWT | Proceeds to next check |
| 2d | GET refunds with `refund:read` | GET with valid JWT | `200 OK` |

**Verification:** Error message must include the missing permission name.

---

## Test Case 3 — Admin for Merchant A Cannot Refund Merchant B Transaction

**Area:** Merchant scope
**Rule:** AZ-004
**File:** `backend/tests/refunds/refund.auth.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 3a | Admin scoped to MER-900, transaction belongs to MER-111 | POST | `403 MERCHANT_SCOPE_VIOLATION` |
| 3b | Admin has empty `allowed_merchant_ids` | POST | `403 MERCHANT_SCOPE_VIOLATION` |
| 3c | Admin scoped to MER-900, transaction belongs to MER-900 | POST | Proceeds (201) |

**Verification:** Response must not reveal which merchant the transaction belongs to.

---

## Test Case 4 — Failed Transaction Cannot Be Refunded

**Area:** Status check
**Rule:** RE-001
**File:** `backend/tests/refunds/refund.business.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 4a | `status: FAILED` | POST | `422 REFUND_INELIGIBLE` |
| 4b | `status: PENDING` | POST | `422 REFUND_INELIGIBLE` |
| 4c | `status: REVERSED` | POST | `422 REFUND_INELIGIBLE` |
| 4d | `status: SUCCESS` | POST | `201 Created` |

**Verification:** Error message must include the actual transaction status.

---

## Test Case 5 — Zero Refund Is Rejected

**Area:** Amount validation
**Rule:** RA-001
**File:** `backend/tests/refunds/refund.business.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 5a | `amount: 0` | POST | `400 INVALID_AMOUNT` |

**Verification:** Backend rejects this regardless of frontend input cap.

---

## Test Case 6 — Negative Refund Is Rejected

**Area:** Amount validation
**Rule:** RA-001
**File:** `backend/tests/refunds/refund.business.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 6a | `amount: -100` | POST | `400 INVALID_AMOUNT` |
| 6b | `amount: -0.01` | POST | `400 INVALID_AMOUNT` |
| 6c | `amount: 49.99` (float) | POST | `400 INVALID_AMOUNT` |

**Verification:** All amount validation is backend-enforced. Frontend `min` attribute is UX only.

---

## Test Case 7 — Refund Greater Than Transaction Amount Is Rejected

**Area:** Amount limit
**Rule:** RA-002
**File:** `backend/tests/refunds/refund.business.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 7a | `amount: 6000`, original: `5000` | POST | `422 OVER_REFUND` |
| 7b | `amount: 5001`, original: `5000` | POST | `422 OVER_REFUND` |
| 7c | `amount: 5000`, original: `5000` | POST | `201 Created` (exact is allowed) |

**Verification:** Response `details` must include `original`, `already_refunded`, `requested`.

---

## Test Case 8 — Multiple Partial Refunds Are Allowed

**Area:** Partial refund
**Rule:** RA-003
**File:** `backend/tests/refunds/refund.business.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 8a | First partial: `amount: 2000`, original: `5000` | POST | `201 Created` |
| 8b | Second partial: `amount: 3000`, prior: `2000` | POST | `201 Created` |
| 8c | FAILED prior refund does not reduce available amount | POST `5000` with a prior FAILED `5000` | `201 Created` |

**Verification:** Sum of successful refunds equals total_refunded in subsequent GET.

---

## Test Case 9 — Total Refunded Cannot Exceed Original Amount

**Area:** Over-refund guard
**Rule:** RA-004
**File:** `backend/tests/refunds/refund.business.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 9a | ₹3000 already refunded, requesting ₹3000 more | POST | `422 OVER_REFUND` |
| 9b | Fully refunded (`total = original`), requesting ₹1 | POST | `422 OVER_REFUND` |
| 9c | ₹2000 refunded, requesting ₹2000 (total = ₹4000 < ₹5000) | POST | `201 Created` |

**Verification:** Guard runs inside the `FOR UPDATE` locked transaction on committed data.

---

## Test Case 10 — Same Key + Same Payload Returns Same Response

**Area:** Idempotency
**Rule:** ID-003
**File:** `backend/tests/refunds/refund.idempotency.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 10a | Key exists, hash matches | POST with same key + same body | `200/201` — stored response returned |
| 10b | Replay does not call `withTransaction` | Same key + same body | `withTransaction` not called |
| 10c | Expired key treated as new | Key past 24h TTL | `withTransaction` called fresh |

**Verification:** `withTransaction` must not be called on a replay. Only one refund row in DB.

---

## Test Case 11 — Same Key + Different Payload Returns 409

**Area:** Idempotency conflict
**Rule:** ID-004
**File:** `backend/tests/refunds/refund.idempotency.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 11a | Same key, different amount | POST | `409 IDEMPOTENCY_CONFLICT` |
| 11b | Same key, different reason | POST | `409 IDEMPOTENCY_CONFLICT` |
| 11c | Missing key header | POST (no header) | `400 MISSING_IDEMPOTENCY_KEY` |
| 11d | Key not UUID v4 | `Idempotency-Key: not-a-uuid` | `400 INVALID_IDEMPOTENCY_KEY` |

**Verification:** 409 must be returned before any business logic runs.

---

## Test Case 12 — Two Simultaneous Refunds Cannot Over-Refund

**Area:** Concurrency
**Rule:** RA-004 + DB locking
**File:** `backend/tests/refunds/refund.concurrency.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 12a | A: ₹3000, B: ₹3000, original: ₹5000 (simultaneous) | 2 × POST | A: `201`, B: `422 OVER_REFUND` |
| 12b | A: ₹2000, B: ₹2000, original: ₹5000 (sequential reads) | 2 × POST | Both `201` (₹4000 ≤ ₹5000) |

**Mechanism being tested:**
```
Request A: SELECT FOR UPDATE → reads ₹0 → inserts ₹3000 → COMMIT → releases lock
Request B: SELECT FOR UPDATE (was blocked) → reads ₹3000 committed → ₹3000 + ₹3000 > ₹5000 → OVER_REFUND
```

**Verification:** Total refunded in DB after both requests = ₹3000, not ₹6000.

**Production verification note:** For true concurrent testing in CI, use a real PostgreSQL
instance with two simultaneous connections rather than mocked clients. The mock tests
simulate the post-lock state correctly but do not exercise the actual lock acquisition.

---

## Test Case 13 — Refund Attempt Creates Audit Log

**Area:** Audit trail
**Rule:** AU-001, AU-002
**File:** `backend/tests/refunds/refund.concurrency.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 13a | Successful refund | POST → 201 | Audit record written inside same transaction |
| 13b | Failed refund (ineligible) | POST → 422 | Audit record written outside rolled-back transaction |
| 13c | Audit fields present | Any attempt | `actor_id`, `transaction_id`, `outcome`, `ip_address` all non-null |

**Verification:**
- Success audit: 5th DB query inside `withTransaction` is `INSERT INTO refund_audit`.
- Failure audit: `pool.connect()` called separately after rollback; `INSERT INTO refund_audit` with outcome `INELIGIBLE`/`FAILED`.

---

## Test Case 14 — Refund Creates Reversal/Ledger Entry

**Area:** Ledger
**Rule:** LE-001..LE-005
**File:** `backend/tests/refunds/refund.concurrency.test.ts`

| # | Scenario | Input | Expected |
|---|---|---|---|
| 14a | Successful refund | POST → 201 | `INSERT INTO ledger_entries` with `REFUND_REVERSAL` and negative amount |
| 14b | Failed refund | POST → 422 | No ledger INSERT |
| 14c | Ledger INSERT fails | DB error mid-transaction | Full rollback — no refund row, no ledger row |

**Verification:**
- Ledger amount = `-5000` (negative — Rule LE-001).
- Ledger `entry_type = 'REFUND_REVERSAL'` (Rule LE-003).
- Ledger and refund written in same `withTransaction` call (Rule LE-005).

---

## Test Case 15 — Refund Button Disabled When Not Eligible

**Area:** Frontend
**Rule:** FE-001, FE-002
**File:** `frontend/src/tests/TransactionDetail.test.tsx`

| # | Scenario | Backend response | Expected UI |
|---|---|---|---|
| 15a | Eligible transaction | `is_refundable: true` | Button enabled |
| 15b | Ineligible (FAILED) | `is_refundable: false` | Button disabled + `aria-disabled="true"` |
| 15c | Fully refunded | `is_refundable: false` | Button disabled |
| 15d | No permission | `canCreateRefund: false` | Button not rendered at all |
| 15e | Ineligible reason shown | `is_refundable: false` | Status message visible |

**Key assertion:** `is_refundable` comes from the API response. The frontend never
computes eligibility from `status` or amount fields directly.

---

## Test Case 16 — Double-Submit Is Prevented

**Area:** Frontend
**File:** `frontend/src/tests/TransactionDetail.test.tsx`

| # | Scenario | Action | Expected |
|---|---|---|---|
| 16a | Click submit once | Single click | API called once, button disabled immediately |
| 16b | Click submit twice rapidly | Double click | API called exactly once |
| 16c | Click three times | Triple click | API called exactly once |
| 16d | Close during in-flight request | Click × while submitting | Close button disabled |
| 16e | Loading indicator | Submit in-flight | "Processing…" text + spinner visible |

**Mechanism:** `useRefund` hook sets `state.status = 'submitting'` before the API call.
`if (state.status === 'submitting') return;` blocks all subsequent calls. Button is
`disabled={isSubmitting}`.

---

## Test Case 17 — Error State Is Shown Clearly

**Area:** Frontend
**File:** `frontend/src/tests/TransactionDetail.test.tsx`

| # | Scenario | API Response | Expected UI |
|---|---|---|---|
| 17a | Backend returns OVER_REFUND | `{ error: { code, message } }` | Alert with code + message visible |
| 17b | Network failure | `fetch` throws | User-friendly error message (not stack trace) |
| 17c | Transaction fetch fails | API error on page load | Page-level alert with error code |
| 17d | Alert accessible | Any error | `role="alert"` present for screen readers |
| 17e | UX validation: amount = 0 | Frontend guard fires | Warning shown, API not called |
| 17f | Success state | 201 refund created | "Refund Initiated" + refund ID shown |

**Key assertions:**
- Raw error messages from the backend are displayed with their error code.
- Stack traces never appear in the UI.
- `role="alert"` ensures screen readers announce the error.

---

## Test Case 18 — Sensitive Data Is Masked

**Area:** Frontend + Masking
**Files:** `frontend/src/tests/TransactionDetail.test.tsx`, `backend/tests/utils/masking.test.ts`

| # | Scenario | Expected |
|---|---|---|
| 18a | UPI VPA displayed | Shows `ab****@okaxis`, not `abcdef@okaxis` |
| 18b | Raw `payment_ref` not in DOM | `abcdef@okaxis` absent from rendered HTML |
| 18c | Refund history table | No raw payment data in any table cell |
| 18d | Masked CSS class | `.masked-value` class applied to masked field |
| 18e | Backend: UPI VPA masking | `maskUpiVpa('abcdef@okaxis')` → `'ab****@okaxis'` |
| 18f | Backend: Card masking | `maskCardNumber('4111111111111111')` → `'****1111'` |
| 18g | Backend: Bank masking | `maskBankAccount('123456789012')` → `'****9012'` |
| 18h | Backend: null payment_ref | `maskPaymentRef(null, 'UPI')` → `null` |
| 18i | Backend: log stripping | `payment_ref` key → `[REDACTED]` in log objects |

**Key assertion:** The frontend renders `payment_ref_masked` from the API response
as-is. It never receives the raw `payment_ref` field — that field is excluded from
all API response shapes.

---

## Coverage Summary

| Area | Test Cases | Files |
|---|---|---|
| Authentication | 5 | `refund.auth.test.ts` |
| Authorization | 4 | `refund.auth.test.ts` |
| Merchant scope | 3 | `refund.auth.test.ts` |
| Status check | 4 | `refund.business.test.ts` |
| Amount (zero) | 1 | `refund.business.test.ts` |
| Amount (negative) | 3 | `refund.business.test.ts` |
| Amount (exceeds) | 3 | `refund.business.test.ts` |
| Partial refund | 3 | `refund.business.test.ts` |
| Over-refund | 3 | `refund.business.test.ts` |
| Idempotency | 3 | `refund.idempotency.test.ts` |
| Idempotency conflict | 4 | `refund.idempotency.test.ts` |
| Concurrency | 2 | `refund.concurrency.test.ts` |
| Audit | 3 | `refund.concurrency.test.ts` |
| Ledger | 3 | `refund.concurrency.test.ts` |
| FE: button disabled | 5 | `TransactionDetail.test.tsx` |
| FE: double-submit | 5 | `TransactionDetail.test.tsx` |
| FE: error state | 6 | `TransactionDetail.test.tsx` |
| FE: masking | 9 | `TransactionDetail.test.tsx` + `masking.test.ts` |
| **Total** | **72** | **6 files** |

---

## CI Gate

All tests must pass before any PR is merged. Add this to `.github/workflows/ci.yml`:

```yaml
jobs:
  test-backend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: cd backend && npm ci && npm test
      - run: cd backend && npm run type-check
      - run: cd backend && npm run lint

  test-frontend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: cd frontend && npm ci && npm test -- --watchAll=false
```
