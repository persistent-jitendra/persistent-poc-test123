# Idempotency and Concurrency Design
## FinPay Admin Refund Module

---

## Scenario 1 — Retry After Timeout (Duplicate Refund)

> A customer made a ₹5,000 payment. Support initiated a ₹5,000 refund.
> The admin UI timed out and retried the request.
> The system must not create two refunds.

### What happens step by step

```
Request 1 (original)
──────────────────────────────────────────────────────────────────
  POST /transactions/TXN-10001/refunds
  Idempotency-Key: 550e8400-e29b-41d4-a716-446655440000
  Body: { amount: 500000, currency: "INR" }  ← paise

  1. Idempotency middleware checks idempotency_keys table.
     → No row found. Key is new.

  2. withTransaction() opens a PostgreSQL transaction.

  3. SELECT * FROM transactions WHERE id = $1
     → status = SUCCESS, amount = 500000

  4. SELECT * FROM refunds WHERE transaction_id = $1
     → 0 rows. Total refunded = 0.

  5. assertRefundEligibility() — all rules pass.

  6. INSERT INTO refunds … RETURNING *
     → refund created, id = RFD-ABC123

  7. INSERT INTO ledger_entries (REFUND_REVERSAL, amount = -500000)

  8. INSERT INTO refund_audit (outcome = SUCCESS)

  9. COMMIT

  10. res.json() is called → idempotency middleware intercepts:
      INSERT INTO idempotency_keys
        (key, payload_hash, response_status=201, response_body={...})
      → key stored.

  Network drops. UI shows timeout.

──────────────────────────────────────────────────────────────────
Request 2 (retry — same Idempotency-Key, same payload)
──────────────────────────────────────────────────────────────────
  POST /transactions/TXN-10001/refunds
  Idempotency-Key: 550e8400-e29b-41d4-a716-446655440000  ← same
  Body: { amount: 500000, currency: "INR" }              ← same

  1. Idempotency middleware checks idempotency_keys table.
     → Row found. payload_hash matches.

  2. Return stored response immediately:
     HTTP 201 { data: { id: "RFD-ABC123", amount: 500000, ... } }

  3. withTransaction() is never called.
  4. No new refund is inserted.
  5. No new ledger entry.
  6. No new audit record.

Result: Support sees the original refund confirmation.
        Only one ₹5,000 refund exists. ✅
```

### Why the retry is safe

The `useRefund` hook generates one UUID v4 `Idempotency-Key` per modal
open and stores it in a `useRef`. Every retry of the same form submission
sends the same key. The key is only rotated when the user explicitly calls
`reset()` — which happens when the modal is closed and reopened.

This means accidental double-clicks, network retries, and browser-level
retries all carry the same key and return the same response without
touching the database a second time.

---

## Scenario 2 — Concurrent Submissions (Race Condition)

> Two admins submit ₹3,000 refunds at the same time for a transaction
> with ₹5,000 remaining.
> The system must not allow total refunds to exceed ₹5,000.

### Why a naive check is not enough

A naive implementation would:
1. Read total refunded (₹0)
2. Check ₹0 + ₹3,000 ≤ ₹5,000 → pass
3. Insert refund

If both requests execute step 1 before either reaches step 3, both see
₹0 already refunded, both pass the check, and both insert — resulting in
₹6,000 refunded on a ₹5,000 transaction.

### How this is prevented — SELECT FOR UPDATE

Inside `withTransaction()`, the transaction fetch uses a pessimistic row
lock:

```sql
SELECT * FROM transactions WHERE id = $1 FOR UPDATE
```

`FOR UPDATE` acquires an exclusive row-level lock on the transaction row.
The second concurrent request that reaches this statement blocks and waits
until the first request either commits or rolls back.

**Timeline with locking:**

```
Time →   Request A (₹3,000)          Request B (₹3,000)
─────────────────────────────────────────────────────────────────────
 T1      BEGIN
 T2      SELECT … FOR UPDATE          BEGIN
         ✅ lock acquired
 T3      SELECT refunds → ₹0          SELECT … FOR UPDATE
         total = ₹0                   ⏳ BLOCKED — waiting for lock
 T4      ₹0 + ₹3,000 ≤ ₹5,000 ✅
 T5      INSERT refund (₹3,000)
         INSERT ledger (-₹3,000)
         INSERT audit (SUCCESS)
 T6      COMMIT
         lock released
 T7                                   ✅ lock acquired
 T8                                   SELECT refunds → ₹3,000
                                      total = ₹3,000
 T9                                   ₹3,000 + ₹3,000 > ₹5,000 ❌
                                      assertNoOverRefund() throws
                                      OVER_REFUND
 T10                                  ROLLBACK
                                      INSERT audit (outcome=FAILED,
                                        reason=OVER_REFUND)
 T11                                  HTTP 422 OVER_REFUND returned

Result: Request A succeeds (₹3,000 refunded). ✅
        Request B rejected (₹5,000 would be exceeded). ✅
        Total refunded = ₹3,000, not ₹6,000. ✅
```

Note that Request B still writes an audit record even though it failed —
this uses a separate non-transactional write after the rollback (Rule AU-001).

---

## 1. Idempotency Key Storage

**Table:** `idempotency_keys`

```sql
CREATE TABLE idempotency_keys (
  key              VARCHAR(100)  PRIMARY KEY,
  payload_hash     VARCHAR(64)   NOT NULL,   -- SHA-256 of request body
  response_status  INT           NOT NULL,
  response_body    JSONB         NOT NULL,
  created_at       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  expires_at       TIMESTAMPTZ   NOT NULL
                     DEFAULT NOW() + INTERVAL '24 hours'
);

CREATE INDEX idx_idempotency_expires ON idempotency_keys (expires_at);
```

**What is stored:**

| Field | Value | Why |
|---|---|---|
| `key` | UUID v4 from `Idempotency-Key` header | Lookup key |
| `payload_hash` | SHA-256 of the raw request body | Detects payload change |
| `response_status` | HTTP status of the original response | Replayed exactly |
| `response_body` | Full JSON response body | Replayed exactly |
| `expires_at` | `NOW() + 24 hours` | Rule ID-005 — keys expire after 24h |

**When it is stored:**

The idempotency middleware wraps `res.json()`. After the controller writes
its response, the middleware intercepts the call and persists the key
only on 2xx responses. This means failed requests (422, 403, etc.) do
not consume an idempotency slot — the caller can fix their payload and
retry freely with the same key.

```typescript
// From src/middleware/idempotency.ts
res.json = function (body: unknown) {
  if (res.statusCode >= 200 && res.statusCode < 300) {
    pool.query(
      `INSERT INTO idempotency_keys
         (key, payload_hash, response_status, response_body, expires_at)
       VALUES ($1, $2, $3, $4, NOW() + INTERVAL '24 hours')
       ON CONFLICT (key) DO NOTHING`,
      [key, payloadHash, res.statusCode, JSON.stringify(body)]
    );
  }
  return originalJson(body);
};
```

`ON CONFLICT DO NOTHING` is a safety net — if two concurrent requests with
the same new key somehow both pass the initial lookup simultaneously, only
one insertion wins. The second request will find the key on its next read.

**Expiry cleanup:** A scheduled job (outside this module's scope) runs:
```sql
DELETE FROM idempotency_keys WHERE expires_at < NOW();
```

---

## 2. Same Key + Same Payload → Return Original Response

**Detection:** SHA-256 hash of the raw request body is compared against
the stored `payload_hash`.

```typescript
function hashPayload(body: unknown): string {
  return crypto
    .createHash('sha256')
    .update(JSON.stringify(body))
    .digest('hex');
}

// In middleware:
if (record.payload_hash === payloadHash) {
  // Rule ID-003
  res.status(record.response_status).json(record.response_body);
  return;
}
```

**What the caller receives:** The exact same HTTP status code and body
as the original response. The caller cannot distinguish a replayed
response from a freshly computed one. This is intentional — idempotency
is transparent.

**Trade-off acknowledged:** SHA-256 of the JSON body means key equality
is sensitive to field ordering in the serialised body. Clients must send
the same JSON structure. This is documented in the API contract and
enforced by the typed `CreateRefundRequest` interface on the frontend.

---

## 3. Same Key + Different Payload → 409 Conflict

**Detection:** Key found in table but `payload_hash` does not match.

```typescript
if (record.payload_hash !== payloadHash) {
  // Rule ID-004
  throw Errors.idempotencyConflict();
  // → HTTP 409 IDEMPOTENCY_CONFLICT
}
```

**Why 409 and not 400:** A 400 would imply the request itself is malformed.
A 409 correctly indicates a state conflict — the key has already been used
with a different intent. The caller must generate a new UUID v4 key if
they want to submit a different refund amount.

**Example that triggers this:**
- Request 1: `Idempotency-Key: abc`, `amount: 5000` → stored, 201
- Request 2: `Idempotency-Key: abc`, `amount: 3000` → 409 Conflict

This protects against a bug where a client reuses a hardcoded or poorly
generated key across different logical operations.

---

## 4. Database Transaction

Every successful refund creation touches three tables atomically:

```typescript
// From src/refunds/refundService.ts
return withTransaction(async (client) => {
  // 1. Fetch + lock transaction row
  const transaction = await getTransaction(client, payload.transaction_id);

  // 2. Read existing refunds for over-refund calculation
  const existingRefunds = await getExistingRefunds(client, payload.transaction_id);

  // 3. Assert all business rules — throws on any violation
  assertRefundEligibility(transaction, existingRefunds, payload.amount, payload.currency);

  // 4. Insert refund record
  const refund = await client.query(`INSERT INTO refunds … RETURNING *`, [...]);

  // 5. Insert ledger reversal entry
  await ledgerService.createReversal(client, { … });

  // 6. Insert audit record
  await auditLogger.record(client, { outcome: 'SUCCESS', … });

  return refund.rows[0];
  // COMMIT — all three writes land together or none do
});
```

**Atomicity guarantee:**

| Step fails at | What happens |
|---|---|
| Before refund INSERT | ROLLBACK — nothing written |
| After refund INSERT, before ledger | ROLLBACK — refund row removed |
| After ledger, before audit | ROLLBACK — both rows removed |
| After all three writes | COMMIT — all three persist |

There is no code path where a refund exists without a corresponding ledger
entry or audit record. This is enforced structurally — not by convention.

**Failed attempts:** When the transaction rolls back, the catch block in
`refundController` calls `refundService.recordFailedAttempt()`, which
opens a new independent connection (not the rolled-back transaction) and
writes the audit record. This ensures Rule AU-001 is met even when the
main transaction fails.

---

## 5. Row Locking — Concurrency Control

**Mechanism:** `SELECT … FOR UPDATE` on the `transactions` row.

```typescript
// In refundService.ts — getTransaction()
const result = await client.query<Transaction>(
  'SELECT * FROM transactions WHERE id = $1 FOR UPDATE',
  [id]
);
```

**What `FOR UPDATE` does:**
- Acquires an exclusive row-level lock on the specific transaction row
- Any other database session that tries to `SELECT … FOR UPDATE` the same
  row will block until the first session commits or rolls back
- Read-only `SELECT` (without `FOR UPDATE`) still proceeds — only writes
  and locked reads are blocked
- The lock is held until the surrounding `BEGIN … COMMIT/ROLLBACK` completes

**Why not application-level locking (Redis distributed lock):**
- Adds an external dependency that can fail independently of the DB
- Creates a failure mode where the lock is held but the DB write fails
- PostgreSQL row locking is already the right tool — it is co-located with
  the data, participates in the same transaction, and releases automatically
  on commit or rollback
- For the current scale (admin-initiated refunds) PostgreSQL locking is
  sufficient and significantly simpler

**Why not an optimistic lock (version column):**
- Optimistic locking requires the caller to retry on conflict
- For a financial operation, a retry loop introduces the risk of
  unintentional duplicate processing if the retry logic has a bug
- Pessimistic locking (FOR UPDATE) blocks the second request and forces
  it to re-read committed data — this is the correct behaviour for a
  money movement

---

## 6. Refund Total Calculation

**Where it runs:** Inside the database transaction, after the row lock
is acquired, before any writes.

```typescript
// In refund.rules.ts
export function assertNoOverRefund(
  transaction: Transaction,
  existingRefunds: Refund[],
  requestedAmount: number
): void {
  const totalRefunded = existingRefunds
    .filter((r) => r.status === 'SUCCESS')    // only count completed refunds
    .reduce((sum, r) => sum + r.amount, 0);

  if (totalRefunded + requestedAmount > transaction.amount) {
    throw Errors.overRefund(transaction.amount, totalRefunded, requestedAmount);
  }
}
```

**Why only `SUCCESS` refunds are counted:**
- `PENDING` refunds do not yet represent settled money movement
- `FAILED` refunds never moved money and must not reduce the available amount

**Why the calculation runs inside the locked transaction:**
Because `FOR UPDATE` on the `transactions` row is held from the point of
the lock until commit, no other session can run the same sequence of
lock → read → write on the same transaction while we hold it. The total
we compute is the true committed total at that instant — not a stale
snapshot from before another concurrent refund was committed.

**What is returned to the frontend:**
```typescript
// In masking.ts — maskTransaction()
remaining_refundable_amount: Math.max(0, txn.amount - totalRefunded)
is_refundable: txn.status === 'SUCCESS' && remaining > 0
```

The frontend receives a pre-computed `remaining_refundable_amount` and
`is_refundable` flag. It never calculates these itself. After every
successful refund the frontend calls `refetch()` to get an updated value
from the backend.

---

## 7. Audit Trail

**Table:** `refund_audit` — append-only, protected by PostgreSQL rules.

```sql
CREATE RULE no_update_refund_audit AS ON UPDATE TO refund_audit DO INSTEAD NOTHING;
CREATE RULE no_delete_refund_audit AS ON DELETE TO refund_audit DO INSTEAD NOTHING;
```

**Every refund attempt writes an audit record — without exception.**

| Scenario | Audit outcome | Written inside main tx? |
|---|---|---|
| Successful refund | `SUCCESS` | Yes — same transaction |
| Over-refund attempt | `FAILED` + `OVER_REFUND` reason | No — separate connection after rollback |
| Ineligible transaction | `INELIGIBLE` | No — separate connection after rollback |
| Idempotency conflict | `CONFLICT` | No — written by middleware before controller runs |
| Forbidden (no permission) | `FORBIDDEN` | No — written by controller catch block |
| Transaction not found | `FAILED` | No — written by controller catch block |

**Fields recorded (Rule AU-002):**

| Field | Example | Purpose |
|---|---|---|
| `actor_id` | `ADMIN-007` | Who initiated the refund |
| `transaction_id` | `TXN-10001` | Which transaction |
| `refund_id` | `RFD-ABC123` or `NULL` | Which refund (null if creation failed) |
| `amount` | `500000` | Amount that was requested |
| `currency` | `INR` | Currency |
| `outcome` | `SUCCESS` / `FAILED` / `INELIGIBLE` / `CONFLICT` / `FORBIDDEN` | What happened |
| `failure_reason` | `OVER_REFUND` | Why it failed (null on success) |
| `ip_address` | `203.0.113.42` | Network source of the request |
| `idempotency_key` | `550e8400-…` | The key used (for tracing retries) |
| `created_at` | `2026-06-10T11:00:00Z` | When it happened |

**Tracing a retry via audit:**
Because `idempotency_key` is stored in the audit record, an engineer can
query all audit rows for a given key and see that Request 2 never created
a new audit row — confirming it was served from the idempotency store and
never reached the business logic layer. This is important for incident
investigation and compliance review.

---

## Summary — Defence in Depth

```
Layer 1 — Frontend (UX only)
  useRefund hook generates one key per modal open.
  Submit button disabled while request is in-flight.
  → Prevents accidental double-clicks.

Layer 2 — Idempotency middleware (before controller)
  Checks idempotency_keys table before any business logic runs.
  Same key + same payload → return stored response immediately.
  Same key + diff payload → 409, no further processing.
  → Prevents retry-induced duplicates regardless of frontend state.

Layer 3 — Database transaction with FOR UPDATE
  Exclusive row lock on the transaction record.
  Over-refund check runs against committed data while lock is held.
  All writes (refund + ledger + audit) are atomic.
  → Prevents concurrent duplicate refunds even without the key.

Layer 4 — Audit trail (all paths)
  Every attempt — success or failure — is recorded immutably.
  Rollback does not prevent the failed-attempt audit write.
  → Full visibility for compliance and incident investigation.
```

Layers 2 and 3 are independent. If idempotency storage fails, the
database lock still prevents over-refund. If the database lock is somehow
not held, the idempotency check has already short-circuited the duplicate
request. Both must fail simultaneously for a duplicate refund to be issued —
which requires both a middleware bug and a database concurrency bug at the
same instant.
