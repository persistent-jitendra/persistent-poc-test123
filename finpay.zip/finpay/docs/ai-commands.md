# AI Commands — FinPay Team Reference
## Quick-start prompts and commands for safe AI use on this codebase

---

## How to Use This Document

Copy any prompt block below directly into your AI tool (Cursor, Claude,
Copilot Chat, etc.). Each prompt is self-contained and loads the correct
context and constraints for its task type.

Every prompt in this document enforces the rules in `AGENTS.md`.
You do not need to re-state those rules — the prompt references the
skill files that contain them.

---

## Command 1 — Safe Fintech Change

**Use when:** Starting any task that touches refunds, payments, ledger,
wallet, merchant scope, authorization, or financial data.

```
Load and apply .agents/skills/safe-fintech-change/SKILL.md before doing anything else.

Project: FinPay Admin Refund Module
Stack: Node.js + Express + PostgreSQL + React + TypeScript
Business rules: docs/business-rules.md (read this before writing any logic)

Task: [describe what needs to change]

Files in scope: [list the specific files]
Files out of scope: everything not listed above

Constraints:
- Do not modify src/auth/, src/ledger/, src/audit/, src/migrations/,
  src/config/secrets.ts, infrastructure/, or any .env file.
- Do not add npm packages.
- Do not add new database tables unless I explicitly ask.
- Do not guess any business rule. If a rule is unclear, ask me.

Complete all 7 steps of the Safe Fintech Change protocol before writing code.
```

---

## Command 2 — Anti-Overengineering Review

**Use when:** AI has generated a diff and you want to verify it before
accepting it.

```
Load and apply .agents/skills/anti-overengineering-review/SKILL.md.

Review the following diff / plan for unnecessary complexity.
Run all 7 checks and produce a verdict for each.

[paste diff or describe the generated plan here]

Original task requirement (one sentence): [state it]

Expected output: the 7-check table with PASS/FAIL/SIMPLIFY per check,
a list of rejected items, a list of required simplifications, and an
overall verdict of PASS / FAIL / PASS WITH MODIFICATIONS.
```

---

## Command 3 — Read Before Edit

**Use when:** Asking AI to modify any existing file.

```
Before suggesting any change to [file path]:
1. Read the file completely.
2. Read its test file at [test file path].
3. Summarise what the current code does in plain language.
4. Identify the specific lines that need to change.
5. Confirm that no other files need to change.

Only then propose the edit. Show me a diff, not a full rewrite.
```

---

## Command 4 — Business Rule Check

**Use when:** AI is about to implement logic that involves eligibility,
amounts, currencies, permissions, or any financial calculation.

```
Before implementing any business logic:
1. Read docs/business-rules.md.
2. Find the exact Rule ID(s) that apply to this task.
3. Quote the rule text verbatim.
4. Confirm that what you are about to implement matches the quoted rule
   exactly — not an interpretation of it.

If no rule exists for what I am asking you to implement, stop and ask me.
Do not implement logic that is not in docs/business-rules.md.
```

---

## Command 5 — Write Tests First

**Use when:** Asking AI to add a new feature or fix a bug in the refund module.

```
Before writing any implementation code, write the test cases first.

For the change: [describe the change]

List every test case in this format:
  Unit:        [function] — [scenario] — [expected result]
  Integration: [METHOD /path] — [scenario] — [HTTP status + response shape]
  Must keep:   [existing tests that must not be deleted]

Minimum required for any refund change:
  - Full refund on SUCCESS transaction → 201
  - Partial refund → 201
  - Non-SUCCESS transaction → 422 REFUND_INELIGIBLE
  - Amount = 0 → 400 INVALID_AMOUNT
  - Over-refund → 422 OVER_REFUND
  - Same idempotency key + same payload → 200 (replay)
  - Same idempotency key + different payload → 409 CONFLICT
  - Missing permission → 403 FORBIDDEN
  - Out-of-scope merchant → 403 MERCHANT_SCOPE_VIOLATION
  - Audit record written on success
  - Audit record written on failure
  - Ledger reversal written on success

Wait for my approval of the test list before writing any implementation.
```

---

## Command 6 — Security Review

**Use when:** Reviewing any AI-generated code that touches the API layer,
database queries, or authentication.

```
Review the following code for security issues specific to a fintech codebase.

Check for:
1. SQL injection — any query where user input is not parameterised ($1, $2)
2. Missing auth — any route without authenticate + requirePermission middleware
3. Missing merchant scope — any transaction access without requireMerchantScope
4. PII in logs — any console.log or logger call that includes payment data,
   tokens, account numbers, VPAs, or user PII
5. Unmasked responses — any API response returning raw payment_ref, card
   numbers, account numbers, or VPAs
6. Missing DB transaction — any operation that writes to more than one table
   without a BEGIN/COMMIT wrapper
7. Missing audit — any refund attempt (success or failure) that does not
   write to refund_audit
8. Stack traces in responses — any catch block that returns err.stack or
   err.message directly to the client

[paste code here]

For each issue found: state the line, the risk, and the correct fix.
```

---

## Command 7 — Explain Without Changing

**Use when:** You want to understand what existing code does before
deciding whether to change it.

```
Read [file path] and explain:
1. What this code does in plain language.
2. Which business rules it enforces (with Rule IDs from docs/business-rules.md).
3. What would break if this code were removed.
4. What edge cases it handles.
5. What it does NOT handle (gaps).

Do not suggest any changes. Do not refactor. Only explain.
```

---

## Command 8 — Diff Review

**Use when:** AI has generated changes and you want a plain-language
summary of what was actually modified.

```
Summarise the following diff in plain language.

For each changed file, state:
- What changed (not how — explain the behaviour, not the syntax)
- Why it changed (which part of the task required it)
- Whether any tests cover the changed behaviour
- Whether the change affects any financial calculation, auth check,
  idempotency flow, audit write, or ledger write

Flag anything that looks like:
- A change outside the task scope
- A removed or weakened test
- A new dependency
- A change to a protected file (auth, ledger, audit, migrations, secrets, infra)

[paste diff here]
```

---

## Command 9 — Assumption Audit

**Use when:** AI has generated code and you want to surface hidden assumptions
before it is merged.

```
Review the following code and list every assumption it makes.

For each assumption:
- State what is assumed
- State what breaks if the assumption is wrong
- State how a developer can verify the assumption

Label each one: [ASSUMPTION]

Also list any place where the code uses "should work", "probably", or
"might" in a comment — these indicate unverified behaviour in a financial
context and must be replaced with a definitive statement or a documented
known risk.

[paste code here]
```

---

## Command 10 — Post-Merge Checklist

**Use when:** An AI-assisted change has been implemented and you are
preparing to merge it.

```
Before I merge this change, verify the following checklist.
Answer YES or NO for each item. If any answer is NO, state what is missing.

Code quality:
  [ ] Every changed file was in the stated task scope
  [ ] No files outside scope were modified
  [ ] No new npm packages were added without approval
  [ ] No new database tables or migrations were added without approval

Security:
  [ ] All SQL uses parameterised queries
  [ ] All new routes have authenticate + requirePermission middleware
  [ ] Merchant-scoped routes have requireMerchantScope middleware
  [ ] No PII, tokens, or secrets in logs or error responses
  [ ] All payment fields masked before API response

Financial integrity:
  [ ] Multi-table writes are inside a DB transaction
  [ ] Over-refund guard runs inside the locked transaction
  [ ] Amounts are integers (paise), not floats

Idempotency and audit:
  [ ] Idempotency-Key required and checked on all mutating refund routes
  [ ] Audit record written on every attempt (success and failure)
  [ ] Failure audit survives transaction rollback
  [ ] Ledger reversal written on success

Tests:
  [ ] All existing tests still pass
  [ ] New tests cover the added code paths
  [ ] Error paths are tested
  [ ] Idempotency scenarios are tested

[paste diff or list of changed files here]
```

---

## Quick Reference — Skill Files

| Skill | File | Use When |
|---|---|---|
| Safe Fintech Change | `.agents/skills/safe-fintech-change/SKILL.md` | Before any financial code change |
| Anti-Overengineering Review | `.agents/skills/anti-overengineering-review/SKILL.md` | After AI generates code |
| Cursor: Safe Fintech | `.cursor/rules/safe-fintech-change.mdc` | Auto-applied in Cursor IDE |
| Cursor: Anti-OE | `.cursor/rules/anti-overengineering.mdc` | Auto-applied in Cursor IDE |
| Claude: Safe Fintech | `.claude/instructions/safe-fintech-change.md` | Load at start of Claude session |
| Claude: Anti-OE | `.claude/instructions/anti-overengineering.md` | Load for diff review in Claude |

## Quick Reference — Key Files AI Must Always Read First

| File | Contains |
|---|---|
| `docs/business-rules.md` | All business rules with Rule IDs — canonical source |
| `AGENTS.md` | Hard rules for all AI agents |
| `CLAUDE.md` | Claude-specific context and architecture patterns |
| `src/types/index.ts` | All shared data types |
| `src/refunds/refund.rules.ts` | Business rule assertion functions |
| `src/refunds/refund.constants.ts` | Rule-derived constants |
