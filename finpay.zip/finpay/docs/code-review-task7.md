# Code Review — Task 7
## AI-Generated Refund Endpoint

### Code Under Review

```typescript
router.post("/api/admin/transactions/:id/refunds", async (req, res) => {
  const transaction = await Transaction.findByPk(req.params.id);
  if (!transaction) {
    return res.status(404).json({ error: "Transaction not found" });
  }
  const refund = await Refund.create({
    transactionId: transaction.id,
    amount: req.body.amount,
    reason: req.body.reason,
    status: "SUCCESS"
  });
  transaction.status = "REFUNDED";
  await transaction.save();
  return res.json(refund);
});
```

---

## 1. What Is Wrong With This Code

Every issue is listed below, grouped by category and mapped to the rule
it violates.

---

### A — Authorization (Critical)

**No authentication middleware.**
There is no `authenticate`, `requirePermission`, or `requireMerchantScope`
call anywhere on this route. Any unauthenticated HTTP client — a browser,
a curl command, an automated script — can POST to this endpoint and
create a refund. This is a complete authorization bypass.

**Rules violated:** AZ-001, AZ-002, AZ-003, AZ-004

**What is missing:**
```typescript
router.post("/api/admin/transactions/:id/refunds",
  authenticate,                           // AZ-001: valid JWT, active user
  requirePermission("refund:create"),     // AZ-002: refund:create permission
  requireMerchantScope(),                 // AZ-004: allowed merchant only
  handler
);
```

---

### B — No Idempotency (Critical)

**No `Idempotency-Key` header check.**
If the client times out and retries, a second refund is created. There is
nothing to detect or prevent this. Two identical requests produce two
`Refund` rows, both with `status: "SUCCESS"`.

**Rules violated:** ID-001, ID-002, ID-003, ID-004

**Impact:** Duplicate refunds are issued. Money is returned twice. This
is the exact scenario described in Task 4.

---

### C — No Business Rule Validation (Critical)

**1. No transaction status check (RE-001)**
The code refunds any transaction regardless of its `status`. A `PENDING`,
`FAILED`, or `REVERSED` transaction will be refunded. Money that was
never successfully collected is returned.

**2. No currency check (RE-002)**
`req.body.currency` is never read or validated. The rule requires INR only.

**3. No amount validation (RA-001)**
`req.body.amount` is written directly to the database without any check.
Zero, negative, and non-integer values are accepted.

**4. No refund limit check (RA-002)**
The refund amount is not compared to the original transaction amount.
A ₹5,000 transaction can be "refunded" ₹500,000.

**5. No over-refund guard (RA-003, RA-004)**
Existing successful refunds are never summed. A transaction can be refunded
an unlimited number of times. Multiple partial refunds can collectively
exceed the original amount.

---

### D — No Atomicity / Data Integrity (Critical)

**Two separate database writes with no transaction wrapper.**

```typescript
// Write 1
const refund = await Refund.create({ ... });

// Write 2 — if this fails, the refund exists but the transaction is not updated
transaction.status = "REFUNDED";
await transaction.save();
```

If `transaction.save()` throws (network issue, constraint violation,
database timeout), the `Refund` row exists in the database with
`status: "SUCCESS"` but the transaction is still in its original state.
The system is now in an inconsistent state: a "successful" refund with
no corresponding transaction status update.

The reverse is also true — if the ORM batches operations differently,
a transaction could be marked `REFUNDED` before the refund row is created.

**Rule violated:** Implied by LE-005 (ledger and refund must be atomic)
and the general principle that financial operations must be all-or-nothing.

---

### E — No Ledger Entry (Critical)

A successful refund must create a reversal entry in `ledger_entries`
(Rule LE-001). This code creates no ledger entry at all. The financial
ledger will be permanently out of balance for every refund processed
through this endpoint. There is no way to reconcile the ledger after the fact
without forensic reconstruction from the `refunds` table.

**Rules violated:** LE-001, LE-002, LE-003, LE-004, LE-005

---

### F — No Audit Trail (Critical)

No audit record is written — for success or failure paths (Rules AU-001,
AU-002). There is no record of:
- Who initiated the refund
- When it was initiated
- From which IP address
- Whether it succeeded or failed
- Why it failed if it did

This is a compliance violation. In a regulated fintech environment, an
unaudited refund operation would fail any financial audit.

**Rules violated:** AU-001, AU-002, AU-003, AU-004

---

### G — Incorrect Status Transition

```typescript
transaction.status = "REFUNDED";
```

`"REFUNDED"` is not a valid transaction status in this system. The allowed
values are `PENDING`, `SUCCESS`, `FAILED`, `REVERSED`. Setting an invalid
status value either silently corrupts the record or throws a database
constraint error depending on whether the column has a `CHECK` constraint.

Additionally, setting status to `REFUNDED` after any refund (including a
partial refund) is semantically wrong. A transaction that has had 10% of
its value refunded is not "REFUNDED" — it is still `SUCCESS` with a
partial refund on record. The remaining refundable amount is tracked
through the sum of the `refunds` table, not through the transaction status.

**Rule violated:** RE-001 (status values are defined)

---

### H — No Input Validation

`req.body.amount` and `req.body.reason` are written directly to the
database without any type check, range check, or sanitisation:

- `amount` could be a string, `null`, `undefined`, a float, negative, or zero.
- `reason` has no length limit — it could be a 10MB payload.
- Neither field is validated against a schema.

While parameterised ORM calls prevent SQL injection, invalid types can
still corrupt records, cause silent truncation, or throw unhandled ORM
errors that leak internal details to the client.

---

### I — Unhandled Errors / No Error Handling

The entire handler is `async` with no `try/catch` and no error handling
middleware referenced. Any thrown error (database connection failure, ORM
validation error, network timeout) will either:

- Crash the process if there is no global error handler, or
- Propagate to Express's default error handler, which may return a 500
  with a stack trace — leaking internal implementation details to the caller.

The error response `{ error: "Transaction not found" }` is also
inconsistent with the structured error format `{ error: { code, message } }`
that the rest of the system uses.

---

### J — Sensitive Data Exposed in Response

```typescript
return res.json(refund);
```

The raw `Refund` ORM object is returned directly. Depending on the ORM's
model definition, this may include internal fields, foreign keys, or
metadata that should not be exposed. More critically, if the `Transaction`
object were similarly returned (as it might be in a "fix" that adds it to
the response), the raw `payment_ref` (UPI VPA, card number, account number)
would be exposed.

**Rules violated:** DP-001, DP-002, DP-003, DP-004

---

## 2. Highest-Risk Issues (Priority Order)

| Priority | Issue | Risk | Financial Impact |
|---|---|---|---|
| 🔴 P0 | No authentication | Any caller can create refunds | Unlimited |
| 🔴 P0 | No idempotency | Retries create duplicate refunds | Per retry |
| 🔴 P0 | No over-refund guard | Single transaction refunded ×N | Unlimited |
| 🔴 P0 | Non-atomic writes | Refund exists without ledger/status update | Ledger corruption |
| 🔴 P0 | No ledger entry | Ledger permanently out of balance | All refunds |
| 🔴 P1 | No status check | FAILED/PENDING transactions refunded | Per transaction |
| 🔴 P1 | No audit trail | No compliance record | All refunds |
| 🟡 P2 | No amount validation | Zero/negative/overlarge amounts accepted | Per bad request |
| 🟡 P2 | Invalid status value | Database corruption or constraint error | Per refund |
| 🟡 P3 | No error handling | Stack traces or crashes exposed | Per error |
| 🟡 P3 | Raw ORM response | Internal data or PII leaked | Per response |

**P0 issues are exploitable immediately by an unauthenticated caller.**
A single curl command against this endpoint with no headers and `amount: 999999999`
in the body would create an unlimited refund on any transaction with no
record of who did it and no way to reverse it cleanly.

---

## 3. What to Fix First

Fix in this order. Do not deploy any version of this code until P0 items
are resolved.

### Fix 1 — Add authentication and authorization (before anything else)

This is the first fix because without it, every other fix is irrelevant.
An unauthenticated endpoint in production is an open door.

```typescript
router.post(
  "/api/admin/transactions/:id/refunds",
  authenticate,                       // validates JWT, checks is_active
  requirePermission("refund:create"), // checks permissions array
  requireMerchantScope(),             // checks allowed_merchant_ids
  refundHandler
);
```

### Fix 2 — Add idempotency middleware

```typescript
router.post(
  "/api/admin/transactions/:id/refunds",
  authenticate,
  requirePermission("refund:create"),
  requireMerchantScope(),
  idempotency(),                      // checks Idempotency-Key header
  refundHandler
);
```

### Fix 3 — Wrap all writes in a single database transaction

```typescript
await withTransaction(async (client) => {
  // All reads and writes happen inside one atomic unit
  const transaction = await getTransactionWithLock(client, id); // FOR UPDATE
  const existingRefunds = await getRefunds(client, id);

  assertRefundEligibility(transaction, existingRefunds, amount, currency);

  const refund = await createRefund(client, { ... });
  await createLedgerEntry(client, { ... });
  await writeAuditRecord(client, { outcome: 'SUCCESS', ... });
  // COMMIT — all three land together or none do
});
```

### Fix 4 — Add all business rule assertions

```typescript
// RE-001: only SUCCESS transactions
assertTransactionIsRefundable(transaction);

// RE-002: only INR
assertSupportedCurrency(req.body.currency);

// RA-001: amount > 0
assertAmountIsPositive(req.body.amount);

// RA-002 + RA-003 + RA-004: no over-refund
assertNoOverRefund(transaction, existingRefunds, req.body.amount);
```

### Fix 5 — Add ledger entry and audit record

```typescript
await ledgerService.createReversal(client, {
  transaction_id: transaction.id,
  refund_id:      refund.id,
  amount:         refund.amount,
  currency:       refund.currency,
  merchant_id:    transaction.merchant_id,
});

await auditLogger.record(client, {
  actor_id:       req.user.id,
  transaction_id: transaction.id,
  refund_id:      refund.id,
  amount:         req.body.amount,
  currency:       req.body.currency,
  outcome:        'SUCCESS',
  ip_address:     req.ip,
  idempotency_key: req.headers['idempotency-key'],
});
```

### Fix 6 — Remove the incorrect status mutation

```typescript
// DELETE this — it is wrong in all cases
transaction.status = "REFUNDED";
await transaction.save();
```

Transaction status is not changed by a refund. The refund is tracked in
the `refunds` table. The `is_refundable` flag and `remaining_refundable_amount`
are computed at read time from the sum of successful refunds.

### Fix 7 — Add error handling and mask the response

```typescript
try {
  // ... handler logic
  return sendSuccess(res, toRefundResponse(refund), 201);
} catch (err) {
  // Write failed-attempt audit (outside the rolled-back transaction)
  await recordFailedAttempt({ ... });

  if (err instanceof AppError) {
    return sendError(res, err);
  }
  return sendInternalError(res); // never expose stack traces
}
```

---

## 4. Tests to Add

The following tests must exist before this endpoint can be considered
production-ready. Without all of them, issues will reach production.

```
AUTHENTICATION
  ✓ No Authorization header → 403
  ✓ Invalid JWT → 403
  ✓ Expired JWT → 403
  ✓ Valid JWT, role = 'customer' → 403
  ✓ Valid JWT, missing refund:create permission → 403
  ✓ Valid JWT, merchant not in allowed_merchant_ids → 403

IDEMPOTENCY
  ✓ Missing Idempotency-Key header → 400 MISSING_IDEMPOTENCY_KEY
  ✓ Idempotency-Key not UUID v4 → 400 INVALID_IDEMPOTENCY_KEY
  ✓ Same key + same payload (duplicate request) → 200 + original response
  ✓ Same key + different payload → 409 IDEMPOTENCY_CONFLICT

BUSINESS RULES
  ✓ Transaction status = PENDING → 422 REFUND_INELIGIBLE
  ✓ Transaction status = FAILED → 422 REFUND_INELIGIBLE
  ✓ Transaction status = REVERSED → 422 REFUND_INELIGIBLE
  ✓ Currency ≠ INR → 422 UNSUPPORTED_CURRENCY
  ✓ Amount = 0 → 400 INVALID_AMOUNT
  ✓ Amount < 0 → 400 INVALID_AMOUNT
  ✓ Amount = float (non-integer paise) → 400 INVALID_AMOUNT
  ✓ Amount > transaction.amount → 422 OVER_REFUND
  ✓ Cumulative refunds exceed transaction.amount → 422 OVER_REFUND
  ✓ Transaction not found → 404 TRANSACTION_NOT_FOUND

HAPPY PATHS
  ✓ Full refund on SUCCESS transaction → 201 + refund object
  ✓ Partial refund → 201 + correct amount
  ✓ Second partial refund within limit → 201
  ✓ Response does not contain raw payment_ref → assert field absent

DATA INTEGRITY
  ✓ Successful refund creates ledger entry with negative amount
  ✓ Successful refund writes audit record (outcome = SUCCESS)
  ✓ Failed refund writes audit record (outcome = INELIGIBLE / FAILED)
  ✓ DB failure mid-write rolls back refund, ledger, and audit as a unit
  ✓ Transaction status is NOT changed to "REFUNDED" after a refund
  ✓ Transaction status IS still SUCCESS after a partial refund

CONCURRENCY
  ✓ Two simultaneous full refunds — only one succeeds, second gets 422 OVER_REFUND
  ✓ Two simultaneous partial refunds totalling > original — second gets 422 OVER_REFUND
```

---

## 5. Would You Approve This Code for Production?

**No. Not in any form. Not with minor modifications. It must be rewritten.**

This is not a code style issue or a missing feature. Every critical safety
system is absent:

| Safety System | Present in Code? |
|---|---|
| Authentication | ❌ None |
| Authorization (permission) | ❌ None |
| Merchant scope enforcement | ❌ None |
| Idempotency | ❌ None |
| Transaction status check | ❌ None |
| Amount validation | ❌ None |
| Over-refund guard | ❌ None |
| Atomic DB transaction | ❌ None |
| Ledger entry | ❌ None |
| Audit trail | ❌ None |
| Error handling | ❌ None |
| Masked response | ❌ None |

This code would allow any unauthenticated caller to issue unlimited refunds
of any amount on any transaction, with no record of who did it, no
financial ledger entry, and no way to detect it happened until a manual
reconciliation revealed the discrepancy.

**In production this would result in:**
- Fraudulent refunds by unauthenticated external actors within minutes of deployment
- Unreconcilable ledger entries for every refund processed
- Compliance failure at the first financial audit
- No ability to investigate incidents (no audit trail)
- Potential regulatory action depending on jurisdiction

---

### Why This Happens and How to Prevent It

AI generated this code by pattern-matching against common Express CRUD
endpoint examples. Those examples do not include financial safety
requirements. The model had no knowledge of:
- The business rules in `docs/business-rules.md`
- The existing middleware in `src/auth/`
- The atomicity requirement for financial writes
- The ledger and audit obligations

**This is exactly the failure mode that the AI workflow in this project
is designed to prevent:**

1. `AGENTS.md` — "Never touch auth, ledger, audit without explicit instruction"
2. `CLAUDE.md` — "Inspect existing code before editing"
3. `.cursor/rules/fintech-development.mdc` — "Auth middleware on all routes"
4. `safe-fintech-change/SKILL.md` — "Step 1: read the existing code first"
5. `anti-overengineering-review/SKILL.md` — "Check 7: safety checklist"
6. `AI_PROMPT_LOG.md` — Documents that this exact pattern was caught and rejected

The correct workflow for this task would have been:
```
1. Load AGENTS.md and docs/business-rules.md before writing any code.
2. Read src/refunds/refundService.ts to understand the existing pattern.
3. Read src/auth/ to find the existing middleware.
4. Propose the smallest change — wire the new route into the existing handler.
5. Run the 7-step Safe Fintech Change protocol before presenting any code.
6. Run the 7-check Anti-Overengineering Review on the output.
```

The result would have been a 5-line route registration using existing,
tested, audited code — not a 15-line handler that reimplements the entire
flow incorrectly from scratch.
